#!/bin/bash
# Powered by AI Charging Controller 4.0

# Define directories
dir="/sys/class/power_supply"
battery="$dir/battery"
bms="$dir/bms"
main="$dir/main"
usb="$dir/usb"
ext="$dir/battery_ext"

# Reads the required files
read_initial_values() {
    temp_cold=$(<"$bms/temp_cold")
    temp_cool=$(<"$bms/temp_cool")
    temp_hot=$(<"$bms/temp_hot")
    temp_warm=$(<"$bms/temp_warm")
    voltage_max=$(<"$usb/voltage_max")
    voltage_min=$(<"$usb/voltage_min")
    current_max_usb=$(<"$usb/current_max")
    hw_current_max=$(<"$usb/hw_current_max")
    input_current_settled=$(<"$usb/input_current_settled")
    constant_charge_current_max_main=$(<"$main/constant_charge_current_max")
    system_temp_level=$(<"$battery/system_temp_level")
    sw_jeita_enabled=$(<"$battery/sw_jeita_enabled")
    input_current_limited=$(<"$battery/input_current_limited")
    input_suspend=$(<"$battery/input_suspend")
    chg_pwr_fcc=$(<"$ext/chg_pwr_fcc")
    chg_pwr_icl=$(<"$ext/chg_pwr_icl")
    max_charge_current=$(<"$ext/max_charge_current")
    constant_charge_current=$(<"$battery/constant_charge_current")
    constant_charge_current_max=$(<"$battery/constant_charge_current_max")
    boost_current=$(<"$usb/boost_current")
}

# Set Permissions
files=(
    "$bms/temp_cold"
    "$bms/temp_cool"
    "$bms/temp_hot"
    "$bms/temp_warm"
    "$usb/voltage_max"
    "$usb/voltage_min"
    "$usb/current_max"
    "$main/current_max"
    "$usb/hw_current_max"
    "$usb/input_current_settled"
    "$main/constant_charge_current_max"
    "$battery/safety_timer_enabled"
    "$battery/system_temp_level"
    "$battery/sw_jeita_enabled"
    "$battery/input_current_limited"
    "$battery/input_suspend"
    "$ext/chg_pwr_fcc"
    "$ext/chg_pwr_icl"
    "$ext/max_charge_current"
    "$battery/constant_charge_current"
    "$battery/constant_charge_current_max"
    "$usb/boost_current"
    "$battery/restricted_charging"
    "$usb/pd_allowed"
    "$dir/allow_hvdcp3"
    "$battery/subsystem/usb/pd_allowed"
    "/sys/kernel/fast_charge/force_fast_charge"
    "/sys/class/qcom-battery/restricted_charging"
)
chmod 0667 "${files[@]}"
read_initial_values

# Charging Control Interface
discharging_executed=false
echo "1" > /sys/kernel/fast_charge/force_fast_charge
echo "0" > /sys/class/qcom-battery/restricted_charging
echo "1" > /sys/class/power_supply/usb/boost_current
echo "0" > /sys/class/power_supply/battery/restricted_charging
echo "1" > /sys/class/power_supply/usb/pd_allowed
echo "1" > /sys/class/power_supply/allow_hvdcp3
echo "1" > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo "0" > /sys/class/power_supply/battery/safety_timer_enabled

# Main Script
while true; do
    cc=$(getprop lynx.cc)
    battery_status=$(<"$battery/status")
    battery_level=$(<"$battery/capacity")
    lynx_fcc=$(getprop lynx.fcc)
    lynx_lcc=$(getprop lynx.lcc)
    lynx_ac=$(getprop lynx.ac)
    lynx_max_ac=$(getprop lynx.max.ac)
    lynx_min_ac=$(getprop lynx.min.ac)
    lynx_mode=$(getprop lynx.mode)
    
    limit_bal=$(awk -v lynx="$lynx_fcc" 'BEGIN {print lynx * 1000000}')
    limit_perf=$(awk -v lynx="$lynx_lcc" 'BEGIN {print lynx * 1000000}')

    case "$cc" in
    1)
        case "$battery_status" in
        "Full")
            if [ "$lynx_ac" -eq "1" ] && [ "$battery_level" -eq 100 ] && ! $discharging_executed; then
                echo "120" > "$bms/temp_cool"
                echo "610" > "$bms/temp_hot"
                echo "590" > "$bms/temp_warm"
                echo "0" > "$bms/temp_cold"
                echo "0" > "$ext/max_charge_current"
                echo "0" > "$battery/constant_charge_current"
                echo "0" > "$battery/constant_charge_current_max"
                echo "0" > "$main/current_max"
                echo "0" > "$main/constant_charge_current_max"
                echo "0" > "$usb/current_max"
                echo "0" > "$usb/hw_current_max"
                echo "0" > "$ext/chg_pwr_fcc"
                echo "0" > "$ext/chg_pwr_icl"
                echo "0" > "$usb/input_current_settled"
                discharging_executed=true
                sleep 1
            elif [ "$lynx_ac" -eq "0" ] && [ "$battery_level" -eq 100 ] && ! $discharging_executed; then
                echo "120" > "$bms/temp_cool"
                echo "610" > "$bms/temp_hot"
                echo "590" > "$bms/temp_warm"
                echo "0" > "$bms/temp_cold"
            fi
            ;;
        "Charging")
            if [ "$lynx_ac" -eq "1" ] && [ "$battery_level" -ge "$lynx_max_ac" ] && ! $discharging_executed; then
                echo "120" > "$bms/temp_cool"
                echo "650" > "$bms/temp_hot"
                echo "610" > "$bms/temp_warm"
                echo "0" > "$bms/temp_cold"
                echo "0" > "$ext/max_charge_current"
                echo "0" > "$battery/constant_charge_current"
                echo "0" > "$battery/constant_charge_current_max"
                echo "0" > "$main/current_max"
                echo "0" > "$main/constant_charge_current_max"
                echo "0" > "$usb/current_max"
                echo "0" > "$usb/hw_current_max"
                echo "0" > "$ext/chg_pwr_fcc"
                echo "0" > "$ext/chg_pwr_icl"
                echo "0" > "$usb/input_current_settled"
                discharging_executed=true
                sleep 1
            else
                case "$lynx_mode" in
                "balance")
                    mode_current_limit="$limit_bal"
                    echo "610" > "$bms/temp_hot"
                    echo "580" > "$bms/temp_warm"
                    ;;
                "performance")
                    mode_current_limit=$((limit_perf == 0 ? limit_bal : limit_perf))
                    echo "810" > "$bms/temp_hot"
                    echo "780" > "$bms/temp_warm"
                    ;;
                *)
                    ;;
                esac

                # Set values
                echo "120" > "$bms/temp_cool"
                echo "0" > "$bms/temp_cold"
                echo "0" > "$battery/system_temp_level"
                echo "$mode_current_limit" > "$ext/max_charge_current"
                echo "$mode_current_limit" > "$battery/constant_charge_current"
                echo "$mode_current_limit" > "$battery/constant_charge_current_max"
                echo "$mode_current_limit" > "$main/current_max"
                echo "$mode_current_limit" > "$main/constant_charge_current_max"
                echo "$mode_current_limit" > "$usb/current_max"
                echo "$mode_current_limit" > "$usb/hw_current_max"
                echo "$mode_current_limit" > "$ext/chg_pwr_fcc"
                echo "$mode_current_limit" > "$ext/chg_pwr_icl"
                echo "$mode_current_limit" > "$usb/input_current_settled"
                discharging_executed=false
            fi
            ;;
        "Not charging")
            if [ "$lynx_ac" -eq "1" ] && [ "$lynx_max_ac" -eq "$lynx_min_ac" ]; then
                lynx_min_ac=$((lynx_min_ac - 3))
                setprop lynx.min.ac "$lynx_min_ac"
            elif [ "$battery_level" -le "$lynx_min_ac" ]; then
                case "$lynx_mode" in
                    "balance")
                        mode_current_limit="$limit_bal"
                        ;;
                    "performance")
                        mode_current_limit=$((limit_perf == 0 ? limit_bal : limit_perf))
                        ;;
                    *)
                        ;;
                esac

                # Set values
                echo "120" > "$bms/temp_cool"
                echo "650" > "$bms/temp_hot"
                echo "610" > "$bms/temp_warm"
                echo "0" > "$bms/temp_cold"
                echo "0" > "$battery/system_temp_level"
                echo "$mode_current_limit" > "$ext/max_charge_current"
                echo "$mode_current_limit" > "$battery/constant_charge_current"
                echo "$mode_current_limit" > "$battery/constant_charge_current_max"
                echo "$mode_current_limit" > "$main/current_max"
                echo "$mode_current_limit" > "$main/constant_charge_current_max"
                echo "$mode_current_limit" > "$usb/current_max"
                echo "$mode_current_limit" > "$usb/hw_current_max"
                echo "$mode_current_limit" > "$ext/chg_pwr_fcc"
                echo "$mode_current_limit" > "$ext/chg_pwr_icl"
                echo "$mode_current_limit" > "$usb/input_current_settled"
                discharging_executed=false
            fi
            ;;
        "Discharging")
            if [ "$battery_level" -le 50 ] && ! $discharging_executed; then
                echo "120" > "$bms/temp_cool"
                echo "650" > "$bms/temp_hot"
                echo "610" > "$bms/temp_warm"
                echo "0" > "$bms/temp_cold"
                discharging_executed=true
                sleep 1
            fi
            ;;
        *)
            ;;
        esac
        ;;
    0)
        echo "$temp_cool" > "$bms/temp_cool"
        echo "$temp_hot" > "$bms/temp_hot"
        echo "$temp_warm" > "$bms/temp_warm"
        echo "$temp_cold" > "$bms/temp_cold"
        echo "$system_temp_level" > "$battery/system_temp_level"
        echo "$sw_jeita_enabled" > "$battery/sw_jeita_enabled"
        echo "$input_current_limited" > "$battery/input_current_limited"
        echo "$input_suspend" > "$battery/input_suspend"
        echo "$boost_current" > "$usb/boost_current"
        echo "$voltage_max" > "$usb/voltage_max"
        echo "$voltage_min" > "$usb/voltage_min"
        echo "$chg_pwr_fcc" > "$ext/chg_pwr_fcc"
        echo "$chg_pwr_icl" > "$ext/chg_pwr_icl"
        echo "$max_charge_current" > "$ext/max_charge_current"
        echo "$constant_charge_current" > "$battery/constant_charge_current"
        echo "$constant_charge_current_max" > "$battery/constant_charge_current_max"
        echo "$constant_charge_current_max_main" > "$main/constant_charge_current_max"
        echo "$current_max_usb" > "$usb/current_max"
        echo "$hw_current_max" > "$usb/hw_current_max"
        echo "$input_current_settled" > "$usb/input_current_settled"
        discharging_executed=true
        sleep 1
        ;;
    *)
        ;;
    esac

done
