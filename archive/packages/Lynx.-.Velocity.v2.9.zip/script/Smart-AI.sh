#!/system/bin/sh
# AI Controller 4.0
# By Noir

# Sync all
sync

# Paths
BASEDIR="/data/adb/modules/Lynx"
RWD="/storage/emulated/0/Lynx"
LOG="$RWD/lynx.log"
MODPROP="$BASEDIR/module.prop"
MSC="$BASEDIR/script"
BAL="$MSC/lynx_balance.sh"
PERF="$MSC/lynx_performance.sh"
APPLIST="$RWD/applist_perf.txt"

# Read Prop Function
read_prop() {
    prop_name="$1"
    sed -nE "s/^$prop_name=(.*)/\1/p" "$MODPROP"
}

# Check and create Lynx directory
mkdir -p "$RWD" || { echo "Failed to create Lynx directory" >> "$LOG"; exit 1; }

# Log info and module
{
printf '\n%s\n' " -------------------- "
printf ' Module info:\n'
printf ' • Name             : %s\n' "$(read_prop 'name')"
printf ' • Version          : %s\n' "$(read_prop 'version')"
printf ' • Owner            : %s\n' "$(read_prop 'author')"
printf ' • Release Date     : %s\n' "$(read_prop 'versionCode' | sed 's/\(....\)\(..\)\(..\)/\3-\2-\1/')"
printf '\n%s\n' ''
printf ' Device info:\n'
printf ' • Brand            : %s\n' "$(getprop ro.product.system.brand)"
printf ' • Device           : %s\n' "$(getprop ro.product.system.model)"
printf ' • Processor        : %s\n' "$(getprop ro.product.board)"
printf ' • Android Version  : %s\n' "$(getprop ro.system.build.version.release)"
printf ' • SDK Version      : %s\n' "$(getprop ro.build.version.sdk)"
printf ' • Architecture     : %s\n' "$(getprop ro.product.cpu.abi)"
printf ' • Kernel Version   : %s\n' "$(uname -r)"
printf '\n%s\n' ''
printf ' Profile Mode:\n'
} >> "$LOG" || { echo "Failed to write module info and device info to log"; exit 1; }

# Check and create applist file
if [ ! -e $RWD/applist_perf.txt ]; then
  cp -f $MSC/applist_perf.txt $RWD
fi

# AI Interface
sed -Ei "s/^description=\[.*\]/description=[ 🤖 Aɪ ɪꜱ ꜱᴛᴀʀᴛᴇᴅ ]/" "$BASEDIR/module.prop"
am start -a android.intent.action.MAIN -e toasttext "🤖 Aɪ ɪꜱ ꜱᴛᴀʀᴛᴇᴅ..." -n bellavita.toast/.MainActivity

# Start AI
setprop lynx.mode notset
    # Applist Funtion
    update_app_list_filter() {
        local app_list_filter="grep -o -e applist.app.add"
        while IFS= read -r applist || [[ -n "$applist" ]]; do
            filter=$(echo "$applist" | awk '!/ /')
            if [[ -n "$filter" ]]; then
            app_list_filter+=" -e "$filter
            fi
        done < "$RWD/applist_perf.txt"
        APP_LIST_FILTER="$app_list_filter"
    }
    # Applist variable
    APP_LIST_FILTER=""
    update_timer=0
    update_interval=60
    while true; do
        # Update Applist with timer
        if [ "$update_timer" -ge "$update_interval" ]; then
            update_app_list_filter
            update_timer=0  # Reset Timer
        fi
        # AI Function 
        window=$(dumpsys window | grep package | eval "$APP_LIST_FILTER" | tail -1)
        if [ -n "$window" ]; then
            [ "$(getprop lynx.mode)" = "performance" ] || sh "$PERF" /dev/null 2>&1 && wait
        else
            [ "$(getprop lynx.mode)" = "balance" ] || sh "$BAL" /dev/null 2>&1 && wait
        fi
        # Time Setter
        ((update_timer++))

        sleep 0.5
    done || { am start -a android.intent.action.MAIN -e toasttext "🛠️ ᴀɪ'ꜱ ʙʀᴏᴋᴇɴ, ɴᴇᴇᴅ ᴛᴏ ꜰɪxɪɴɢ!" -n bellavita.toast/.MainActivity; exit 1; }
