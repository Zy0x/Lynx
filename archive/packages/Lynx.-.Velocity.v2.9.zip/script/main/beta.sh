ufs_folders=( $(find /sys/devices/platform/soc/* -type d | grep ufs) )
for folder in "${ufs_folders[@]}"; do
  echo "0" > $folder/clkgate_enable
  echo "1" > $folder/clkscale_enable
  echo "0" > $folder/hibern8_on_idle_enable
done

echo "0" > /d/tracing/tracing_on

if [ -e /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd ]; then
    echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
    echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
    echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
    echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
    echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr
fi

echo "NO_GENTLE_FAIR_SLEEPERS" > /sys/kernel/debug/sched_features
echo "NO_HRTICK" > /sys/kernel/debug/sched_features
echo "DOUBLE_TICK" > /sys/kernel/debug/sched_features
echo "NO_RT_RUNTIME_SHARE" > /sys/kernel/debug/sched_features
echo "NEXT_BUDDY" > /sys/kernel/debug/sched_features
echo "TTWU_QUEUE" > /sys/kernel/debug/sched_features
echo "UTIL_EST" > /sys/kernel/debug/sched_features
echo "ARCH_CAPACITY" > /sys/kernel/debug/sched_features
echo "NO_ARCH_POWER" > /sys/kernel/debug/sched_features
echo "NO_ENERGY_AWARE" > /sys/kernel/debug/sched_features

echo "1" > /d/msm_vidc/disable_thermal_mitigation
echo "0" > /d/msm_vidc/fw_low_power_mode

change_task_cgroup()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            echo "$temp_tid" > "/dev/$3/$2/tasks"
        done
    done
}

# $1:task_name $2:hex_mask(0x00000003 is CPU0 and CPU1)
change_task_affinity()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            taskset -p "$2" "$temp_tid"
        done
    done
}

# $1:task_name $2:nice(relative to 120)
change_task_nice()
{
    # avoid matching grep itself
    # ps -Ao pid,args | grep kswapd
    # 150 [kswapd0]
    # 16490 grep kswapd
    local ps_ret
    ps_ret="$(ps -Ao pid,args)"
    for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
        for temp_tid in $(ls "/proc/$temp_pid/task/"); do
            renice -n "$2" "$temp_tid"
        done
    done
}


# Fix laggy scrolling
change_task_cgroup "servicemanager" "top-app" "cpuset"
change_task_cgroup "servicemanager" "foreground" "stune"
change_task_cgroup "android.phone" "top-app" "cpuset"
change_task_cgroup "android.phone" "foreground" "stune"

# Fix laggy home gesture
change_task_cgroup "system_server" "top-app" "cpuset"
change_task_cgroup "system_server" "foreground" "stune"

# Reduce render thread waiting time
change_task_cgroup "surfaceflinger" "top-app" "cpuset"
change_task_cgroup "surfaceflinger" "foreground" "stune"

change_task_cgroup "android.hardware.graphics.composer@2.3-service" "top-app" "cpuset"
change_task_cgroup "android.hardware.graphics.composer@2.3-service" "foreground" "stune"

change_task_cgroup "android.hardware.graphics.composer@2.2-service" "top-app" "cpuset"
change_task_cgroup "android.hardware.graphics.composer@2.2-service" "foreground" "stune"

change_task_cgroup "android.hardware.graphics.composer@2.1-service" "top-app" "cpuset"
change_task_cgroup "android.hardware.graphics.composer@2.1-service" "foreground" "stune"

change_task_cgroup "android.hardware.graphics.composer@2.0-service" "top-app" "cpuset"
change_task_cgroup "android.hardware.graphics.composer@2.0-service" "foreground" "stune"

change_task_cgroup "android.hardware.graphics.composer@2.4-service" "top-app" "cpuset"
change_task_cgroup "android.hardware.graphics.composer@2.4-service" "foreground" "stune"

change_task_cgroup "vendor.qti.hardware.perf@2.0-service" "top-app" "cpuset"
change_task_cgroup "vendor.qti.hardware.perf@2.0-service" "foreground" "stune"

change_task_cgroup "vendor.qti.hardware.perf@1.0-service" "top-app" "cpuset"
change_task_cgroup "vendor.qti.hardware.perf@1.0-service" "foreground" "stune"

change_task_cgroup "vendor.somc.hardware.graphics@1.0-service.rc" "top-app" "cpuset"
change_task_cgroup "vendor.somc.hardware.graphics@1.0-service.rc" "foreground" "stune"