#!/bin/bash

list_file="/storage/emulated/0/Lynx/applist_perf.txt"
previous_checksum=""

# Compiler Apps
compile_packages() {
    while IFS= read -r app_name || [[ -n "$app_name" ]]; do
        package_name=$(pm list packages 2>/dev/null | grep -i "$(echo "$app_name" | tr -d ' ')" | cut -d':' -f2 | tr -d '[:space:]')
        [ -n "$package_name" ] && cmd package compile -m speed -f "$package_name"
    done < "$list_file"
}

# Checksum File
calculate_checksum() {
    md5sum "$list_file" | awk '{print $1}'
}

# Monitoring Compiler Apps
while true; do
    current_checksum=$(calculate_checksum)
    if [ "$current_checksum" != "$previous_checksum" ]; then
        compile_packages
        previous_checksum="$current_checksum"
    fi
    sleep 1
done