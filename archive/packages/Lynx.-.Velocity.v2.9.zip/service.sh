#!/system/bin/sh
#by Noir

# Waiting for boot completed
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 3; done

# Detect temproot

# Path
MODDIR=${0%/*}
MODPROP="$MODDIR/module.prop"

# Variables
ZRAMSIZE=0
SWAPSIZE=0

# Device online functions
wait_until_login()
{
    # whether in lock screen, tested on Android 7.1 & 10.0
    # in case of other magisk module remounting /data as RW
    while [ "$(dumpsys window policy | grep mInputRestricted=true)" != "" ]; do
        sleep 2
    done
    # we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
    while [ ! -d "/sdcard/Android" ]; do
        sleep 2
    done
}

# Unlock Screen fullroot
screen_unlock()
{
su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '⚠️ 𝘗𝘭𝘦𝘢𝘴𝘦 𝘶𝘯𝘭𝘰𝘤𝘬 𝘺𝘰𝘶𝘳 𝘭𝘰𝘤𝘬𝘴𝘤𝘳𝘦𝘦𝘯!'" >/dev/null 2>&1
}

# Zram Algorithm
zram_algorithm()
{
output=$(cat /sys/block/zram0/comp_algorithm)
if [[ $output == *zstd* ]]; then
    echo "zstd" > /sys/block/zram0/comp_algorithm
elif [[ $output == *lz4* ]]; then
    echo "lz4" > /sys/block/zram0/comp_algorithm
fi
}

# Zram functions
disable_zram()
{
    echo "3" > /proc/sys/vm/drop_caches
    swapoff /dev/block/zram0
    echo "0" > /sys/class/zram-control/hot_remove
}

change_zram()
{
    echo "3" > /proc/sys/vm/drop_caches
    swapoff /dev/block/zram0
    echo "1" > /sys/block/zram0/reset
    zram_algorithm
    echo "$ZRAMSIZE" > /sys/block/zram0/disksize
    mkswap /dev/block/zram0
    su -c swapon /dev/block/zram0 -p 5
	  su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '☢️ Zʀᴀᴍ Eɴᴀʙʟᴇᴅ☢️'" >/dev/null 2>&1
}

# Swap functions
change_swap()
{
    if [ ! -e $MODDIR/swapram_installed ]; then
      if test -f "/data/swap"; then
        rm -f /data/swap
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        su -c swapon /data/swap -p 3
      else
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        su -c swapon /data/swap -p 3
      fi
      touch $MODDIR/swapram_installed
    else
      if test -f "/data/swap"; then
        su -c swapon /data/swap -p 3
      else
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        su -c swapon /data/swap -p 3
      fi
    fi
	  su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '☣️ Sᴡᴀᴘ Eɴᴀʙʟᴇᴅ ☣️'" >/dev/null 2>&1
}

# GMS doze functions
gms_doze_enable()
{
GMS="com.google.android.gms"
GC1="auth.managed.admin.DeviceAdminReceiver"
GC2="mdm.receivers.MdmDeviceAdminReceiver"
NLL="/dev/null"
for U in $(ls /data/user); do
  for C in $GC1 $GC2 $GC3; do
    pm disable --user $U "$GMS/$GMS.$C" &> $NLL
  done
done
dumpsys deviceidle whitelist -com.google.android.gms &> $NLL
}

# Dex2oat opt function
dex2oat_opt_enable()
{
sed -Ei "s/^description=\[.*\]/description=[ ⛔ Dᴇx2ᴏᴀᴛ Oᴘᴛɪᴍɪᴢᴇʀ ɪꜱ ʀᴜɴɴɪɴɢ... ]/" "$MODPROP"
su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '⛔ Dᴇx2ᴏᴀᴛ Oᴘᴛɪᴍɪᴢᴇʀ ɪꜱ ʀᴜɴɴɪɴɢ...'" >/dev/null 2>&1
dexoat_opt
}

# Deepsleep functions
doze_default()
{
    sleep 3
}

doze_light()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=120000,light_pre_idle_to=120000,light_idle_to=600000,light_max_idle_to=3600000,locating_to=120000,location_accuracy=50,inactive_to=600000,sensing_to=120000,motion_inactive_to=300000,idle_after_inactive_to=300000
}

doze_moderate()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=60000,light_pre_idle_to=60000,light_idle_to=900000,light_max_idle_to=10800000,locating_to=60000,location_accuracy=100,inactive_to=60000,sensing_to=60000,motion_inactive_to=60000,idle_after_inactive_to=60000,idle_to=7200000,max_idle_to=28800000,quick_doze_delay_to=30000,min_time_to_alarm=1800000
}

doze_high()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=5000,light_pre_idle_to=30000,light_idle_to=1800000,light_max_idle_to=21600000,locating_to=10000,location_accuracy=500,inactive_to=30000,sensing_to=30000,motion_inactive_to=30000,idle_after_inactive_to=30000,idle_to=14400000,max_idle_to=43200000,quick_doze_delay_to=10000,min_time_to_alarm=600000
}

doze_extreme()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=0,light_pre_idle_to=5000,light_idle_to=3600000,light_max_idle_to=43200000,locating_to=5000,location_accuracy=1000,inactive_to=0,sensing_to=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_to=21600000,max_idle_to=172800000,quick_doze_delay_to=5000,min_time_to_alarm=300000
}

# Device online
#wait_login_temproot

# Enable all tweak
sed -Ei "s/^description=\[.*\]/description=[ ⚙️ Aᴘᴘʟʏ ᴛᴡᴇᴀᴋꜱ ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ... ]/" "$MODPROP"
su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '⚙️ Aᴘᴘʟʏ ᴛᴡᴇᴀᴋꜱ ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ...'" >/dev/null 2>&1

# Sync to data in the rare case a device crashes
sync

# Change zram
#change_zram

# Swap ram
#change_swap

# Device online
#screen_unlock
#wait_login_fullroot

# Color management
service call SurfaceFlinger 1023 i32 1

# Increase Display Saturation
service call SurfaceFlinger 1022 f 1.05

# HDR Display (maybe Gimmick)
settings put system hdr_mode 1
settings put system boost_brightness_hdr 1
settings put system boost_brightness_normal 1

# DNS Changer
DNS_CloudflareXGoogle() {
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
    iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2606:4700:4700::1111
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 2001:4860:4860::8844
    ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2606:4700:4700::1111
    ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2001:4860:4860::8844
}

DNS_Google() {
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
    iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.4.4:53
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2001:4860:4860::8888
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 2001:4860:4860::8844
    ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2001:4860:4860::8888
    ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2001:4860:4860::8844
}

DNS_Cloudflare() {
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53
    iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 1.1.1.1:53
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 1.0.0.1:53
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2606:4700:4700::1111
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 2606:4700:4700::1001
    ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2606:4700:4700::1111
    ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2606:4700:4700::1001
}

DNS_AdGuard() {
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 94.140.14.14:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 94.140.15.15:53
    iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 94.140.14.14:53
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 94.140.15.15:53
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2a10:50c0::ad1:ff
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 2a10:50c0::ad2:ff
    ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2a10:50c0::ad1:ff
    ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2a10:50c0::ad2:ff
}

DNS_OpenDNS() {
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 208.67.222.222:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 208.67.220.220:53
    iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 208.67.222.222:53
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 208.67.220.220:53
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2620:0:ccc::2:53
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 2620:0:ccd::2:53
    ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2620:0:ccc::2:53
    ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2620:0:ccd::2:53
}

DNS_Quad9() {
    iptables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 9.9.9.9:53
    iptables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 9.9.9.9:53
    iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 9.9.9.9:53
    iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 9.9.9.9:53
    ip6tables -t nat -A OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2620:fe::fe:53
    ip6tables -t nat -A OUTPUT -p udp --dport 53 -j DNAT --to-destination 2620:fe::fe:53
    ip6tables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 2620:fe::fe:53
    ip6tables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 2620:fe::fe:53
}

# DNS Routing
#change_dns

# Task scheduler
echo "0" > /proc/sys/kernel/sched_tunable_scaling
echo "0" > /proc/sys/kernel/sched_child_runs_first
echo "0" > /proc/sys/kernel/timer_migration
echo "1" > /proc/sys/kernel/sched_autogroup_enabled
echo "15" > /proc/sys/kernel/sched_min_task_util_for_boost
echo "0" > /proc/sys/kernel/sched_min_task_util_for_colocation
echo "950000" > /proc/sys/kernel/sched_rt_runtime_us
echo "1000000" > /proc/sys/kernel/sched_rt_period_us
echo "500000" > /proc/sys/kernel/sched_migration_cost_ns
echo "1" > /sys/kernel/rcu_expedited

# Disable kernel tracking
echo "0" > /proc/sys/kernel/tracing/tracing_on

# Timeslice process
echo "10" > /proc/sys/kernel/sched_rr_timeslice_ms

# Enable dynamic ravg window
echo "1" > /proc/sys/kernel/sched_dynamic_ravg_window_enable
echo "4" > /proc/sys/kernel/sched_ravg_window_nr_ticks

# Enable kernel fsync
echo "1" > /sys/kernel/dyn_fsync/Dyn_fsync_active

# Enable scroll acceleration
echo "Y" > /sys/module/hid_magicmouse/parameters/scroll_acceleration
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed

# Disable spi CRC
echo "0" > /sys/module/mmc_core/parameters/use_spi_crc
echo "0" > /sys/module/mmc_core/parameters/removable
echo "0" > /sys/module/mmc_core/parameters/crc

# Mglru
echo "5000" > /sys/kernel/mm/lru_gen/min_ttl_ms

# LPM (Low Power Mode)
echo "1" > /sys/module/lpm_levels/parameters/lpm_prediction
echo "0" > /sys/module/lpm_levels/parameters/sleep_disabled

# Disable printk
echo "0 0 0 0" > /proc/sys/kernel/printk
echo "off" > /proc/sys/kernel/printk_devkmsg

# Disable kernel panic
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/pause_on_oops

# Cpu Efficient
echo "Y" > /sys/module/workqueue/parameters/power_efficient

# Enable fast socket open for receiver and sender
echo "3" > /proc/sys/net/ipv4/tcp_fastopen

# Disable cpu input boost
echo "0" > /sys/module/cpu_boost/parameters/sched_boost_on_input
echo "0" > /sys/module/cpu_boost/parameters/input_boost_ms
echo "0:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "1:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "2:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "3:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "4:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "5:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "6:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "7:0" > /sys/module/cpu_boost/parameters/input_boost_freq

# Disable Adreno snapshot crashdumper
echo "0" > /sys/class/kgsl/kgsl-3d0/snapshot/snapshot_crashdumper
echo "0" > /sys/class/kgsl/kgsl-3d0/snapshot/force_panic
echo "0" > /sys/class/kgsl/kgsl-3d0/dispatch/fault_throttle_burst

# Cgroup Tweak
if [ -e /dev/stune/top-app/uclamp.max ]; then
  # Uclamp Tweak
  for ta in /dev/cpuset/*/top-app
  do
    echo "max" > "$ta/uclamp.max"
    echo "10" > "$ta/uclamp.min"
    echo "1" > "$ta/uclamp.boosted"
    echo "1" > "$ta/uclamp.latency_sensitive"
  done
  for fd in /dev/cpuset/*/foreground
  do
    echo "50" > "$fd/uclamp.max"
    echo "0" > "$fd/uclamp.min"
    echo "0" > "$fd/uclamp.boosted"
    echo "0" > "$fd/uclamp.latency_sensitive"
  done
  for bd in /dev/cpuset/*/background
  do
    echo "max" > "$bd/uclamp.max"
    echo "20" > "$bd/uclamp.min"
    echo "0" > "$bd/uclamp.boosted"
    echo "0" > "$bd/uclamp.latency_sensitive"
  done
  for sb in /dev/cpuset/*/system-background
  do
    echo "40" > "$sb/uclamp.max"
    echo "0" > "$sb/uclamp.min"
    echo "0" > "$sb/uclamp.boosted"
    echo "0" > "$sb/uclamp.latency_sensitive"
  done
  sysctl -w kernel.sched_util_clamp_min_rt_default=0
  sysctl -w kernel.sched_util_clamp_min=128
fi

# Disable Ramdumps
if [ -d "/sys/module/subsystem_restart/parameters" ]
then
    echo "0" > /sys/module/subsystem_restart/parameters/enable_ramdumps
    echo "0" > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps
fi

# Virtual memory tweaks
echo "10" > /proc/sys/vm/dirty_background_ratio
echo "85" > /proc/sys/vm/dirty_ratio
echo "3000" > /proc/sys/vm/dirty_expire_centisecs
echo "500" > /proc/sys/vm/dirty_writeback_centisecs
echo "500" > /proc/sys/vm/extfrag_threshold
echo "100" > /proc/sys/vm/swappiness
echo "3" > /proc/sys/vm/page-cluster
echo "0" > /proc/sys/vm/oom_kill_allocating_task
echo "8192" > /proc/sys/vm/min_free_kbytes
echo "0" > /proc/sys/kernel/sched_schedstats
echo "29615" > /proc/sys/vm/extra_free_kbytes
echo "8" > /sys/block/zram0/max_comp_streams
echo "0" > /proc/sys/vm/oom_dump_tasks
echo "100" > /proc/sys/vm/overcommit_ratio

# Pressure VM
echo "0" > /sys/module/vmpressure/parameters/allocstall_threshold
echo "100" > /sys/module/vmpressure/parameters/vmpressure_scale_max

# Disable all Log and Debug Mask
for mask in $(find /sys/ -type f -name debug_mask -or -name debug_level -or -name enable_event_log)
do
  echo "0" > "$mask"
done

# LMK
echo "1" > /sys/module/lowmemorykiller/parameters/enable_lmk
echo "0" > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo "14535,29070,43605,58112,72675,87210" > /sys/module/lowmemorykiller/parameters/minfree
chmod 444 /sys/module/lowmemorykiller/parameters/minfree

# I/O scheduler
for queue in /sys/block/*/queue
do
	# Do not use I/O as a source of randomness
	echo "0" > "$queue/add_random"
	# Disable I/O statistics accounting
	echo "0" > "$queue/iostats"
	# I/O Affinity
	echo "1" > "$queue/rq_affinity"
	# Reduce the maximum number of I/O requests in exchange for latency
	echo "128" > "$queue/nr_requests"
done

#Internal Storage (UFS User)
for int in /sys/block/sd*/queue; do
  if grep -q "kyber" "$int/scheduler"; then
    echo "kyber" > $int/scheduler
    echo "512" > $int/read_ahead_kb
    echo "128" > $int/nr_requests
  elif grep -q "noop" "$int/scheduler"; then
    echo "noop" > $int/scheduler
    echo "512" > $int/read_ahead_kb
    echo "128" > $int/nr_requests
  else
    echo "512" > $int/read_ahead_kb
    echo "128" > $int/nr_requests
  fi
done

#Extrenal Storage / EMMC User
for ext in /sys/block/sd*/queue; do
  if grep -q "kyber" "$ext/scheduler"; then
    echo "kyber" > $ext/scheduler
    echo "64" > $ext/read_ahead_kb
    echo "128" > $ext/nr_requests
    echo "1" > $ext/rq_affinity
    echo "0" > $ext/iosched/slice_idle
    echo "0" > $ext/iosched/slice_idle_us
    echo "0" > $ext/iosched/group_idle
    echo "0" > $ext/iosched/group_idle_us
    echo "1" > $ext/iosched/low_latency
  elif grep -q "noop" "$ext/scheduler"; then
    echo "noop" > $ext/scheduler
    echo "64" > $ext/read_ahead_kb
    echo "128" > $ext/nr_requests
    echo "1" > $ext/rq_affinity
    echo "0" > $ext/iosched/slice_idle
    echo "0" > $ext/iosched/slice_idle_us
    echo "0" > $ext/iosched/group_idle
    echo "0" > $ext/iosched/group_idle_us
    echo "1" > $ext/iosched/low_latency
  else
    echo "64" > $ext/read_ahead_kb
    echo "128" > $ext/nr_requests
    echo "1" > $ext/rq_affinity
    echo "0" > $ext/iosched/slice_idle
    echo "0" > $ext/iosched/slice_idle_us
    echo "0" > $ext/iosched/group_idle
    echo "0" > $ext/iosched/group_idle_us
    echo "1" > $ext/iosched/low_latency
  fi
done

#Looping
for loop in /sys/block/loop*/queue; do
  if grep -q "kyber" "$loop/scheduler"; then
      echo "kyber" > "$loop/scheduler"
      echo "512" > "$loop/read_ahead_kb"
  else
      echo "none" > "$loop/scheduler"
      echo "512" > "$loop/read_ahead_kb"
  fi
done

#ram
for ram in /sys/block/ram*/queue; do
    echo "0" > $ram/rotational
    echo "write back" > $ram/write_cache
done

#dm
for dm in /sys/block/dm*/queue; do
    echo "0" > $dm/rotational
    echo "write back" > $dm/write_cache
done

#zram
echo "write back" > /sys/block/zram0/queue/write_cache

# Disable Reclaim Ram (BETA)
for rec in /sys/module/process_reclaim/parameters/
do
    echo "0" > $rec/enable_process_reclaim
    echo "70" > $rec/pressure_max
    echo "50" > $rec/pressure_min
    echo "512" > $rec/per_swap_size
done

# Lib Game
lib_path="/proc/sys/kernel/sched_lib_name"
apps_to_run="com.miHoYo., com.miHoYo.GenshinImpact, com.activision., com.epicgames, com.dts., UnityMain, libunity.so, libil2cpp.so, libmain.so, libcri_vip_unity.so, libopus.so, libxlua.so, libUE4.so, libAsphalt9.so, libnative-lib.so, libRiotGamesApi.so, libResources.so, libagame.so, libapp.so, libflutter.so, libMSDKCore.so, libFIFAMobileNeon.so, libUnreal.so, libEOSSDK.so, libcocos2dcpp.so, libfb.so"
if [ -e "$lib_path" ]; then
  echo "$apps_to_run" > "$lib_path"
fi

# Disable debuggers bluetooth
for bl in /sys/module/bluetooth/parameters/disable_ertm /sys/module/bluetooth/parameters/disable_esco
do
  if [[ -e "$bl" ]]; then
    echo "Y" > "$bl"
  fi
done

# Reduce the maximum scheduling period for lower latency
echo "500000" > /proc/sys/kernel/sched_latency_ns

# Require preeptive tasks to surpass half of a sched period in vmruntime
echo "25000" > /proc/sys/kernel/sched_wakeup_granularity_ns

# Schedule this ratio of tasks in the guarenteed sched period
echo "100000" > /proc/sys/kernel/sched_min_granularity_ns

# Additional Script
echo "25000" > /sys/power/pm_freeze_timeout
echo "10" > /sys/class/devfreq/soc:qcom,gpubw/polling_interval
echo "10" > /sys/class/devfreq/soc:qcom,l3-cdsp/polling_interval
echo "0" > /sys/devices/system/edac/cpu/panic_on_ue
echo "1" > /dev/memcg/memory.use_hierarchy
echo "1" > /dev/memcg/apps/memory.move_charge_at_immigrate
echo "0" > /sys/block/sda/queue/iosched/slice_idle
echo "1" > /sys/module/rcupdate/parameters/rcu_cpu_stall_suppress
echo "0" > /sys/module/rcupdate/parameters/rcu_cpu_stall_timeout

# Core performance
echo "1" > /d/dri/0/debug/core_perf/perf_mode

# Schedtune Boost Base
echo "1" > /dev/stune/schedtune.sched_boost_enabled
echo "0" > /dev/stune/schedtune.boost
echo "0" > /dev/stune/schedtune.sched_boost_no_override
echo "1" > /dev/stune/schedtune.prefer_idle
echo "0" > /dev/stune/schedtune.colocate
echo "0" > /dev/stune/cgroup.clone_children

# Schedtune Boost foreground
echo "1" > /dev/stune/foreground/schedtune.sched_boost_enabled
echo "5" > /dev/stune/foreground/schedtune.boost
echo "1" > /dev/stune/foreground/schedtune.sched_boost_no_override
echo "1" > /dev/stune/foreground/schedtune.prefer_idle

# Schedtune Boost top app
echo "1" > /dev/stune/top-app/schedtune.sched_boost_enabled
echo "5" > /dev/stune/top-app/schedtune.boost
echo "1" > /dev/stune/top-app/schedtune.sched_boost_no_override
echo "1" > /dev/stune/top-app/schedtune.prefer_idle

# Schedtune Boost real time
echo "1" > /dev/stune/rt/schedtune.sched_boost_enabled
echo "0" > /dev/stune/rt/schedtune.boost
echo "0" > /dev/stune/rt/schedtune.sched_boost_no_override
echo "1" > /dev/stune/rt/schedtune.prefer_idle

# Core Ctl
for ctl in /sys/bus/cpu/devices/cpu{0,4,6}; do
    echo "0" > $ctl/core_ctl/enable
    echo "4" > $ctl/core_ctl/min_cpus
    echo "4" > $ctl/core_ctl/max_cpus
    echo "500" > $ctl/core_ctl/offline_delay_ms
done

# CPU set
echo "0" > /dev/cpuset/top-app/mem_exclusive
echo "0" > /dev/cpuset/foreground/cpu_exclusive
echo "0" > /dev/cpuset/top-app/memory_spread_slab
echo "0" > /dev/cpuset/foreground/memory_spread_slab
echo "0" > /dev/cpuset/top-app/memory_spread_page
echo "0" > /dev/cpuset/foreground/memory_spread_page
echo "0" > /dev/cpuset/cpu_exclusive

# Thermal Service
cmd thermalservice override-status 0

# BETA
nohup sh $MODDIR/script/main/beta.sh > /dev/null 2>&1 &

# Internet Function
Internet_Tweak() {
nohup sh $MODDIR/script/main/net.sh > /dev/null 2>&1 &
}

# Internet Tweak
#Internet_Tweak

# For UI System
#window=
#trans=
#anim=
animation_system()
{
settings put global window_animation_scale $window
settings put global transition_animation_scale $trans
settings put global animator_duration_scale $anim
}

# Animation Tweak
#animation
settings put secure long_press_timeout 280
settings put secure multi_press_timeout 80

# Activity manager
if [ $(getprop ro.build.version.sdk) -gt 28 ]; then
  device_config set_sync_disabled_for_tests none
  device_config put activity_manager max_cached_processes 50
  device_config put activity_manager max_empty_time_millis 1200000
  device_config put activity_manager max_phantom_processes 32
  settings put global settings_enable_monitor_phantom_procs true
else
  settings put global activity_manager_constants max_cached_processes=50
fi

#Dexoat Optimizer
#dex2oat_opt_enable

# Enable GMS doze
#gms_doze_enable

# Doze mode
#dozemode

# Unitytrick functions
unitytrick_enable()
{
    chmod 000 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq
    chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity
    chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
    chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id
}

# Unity Big.Little trick by lybxlpsv 
#unitytrick_enable

# Fstrim
fstrim /system
fstrim /vendor
fstrim /metadata
fstrim /odm
fstrim /system_ext
fstrim /product
fstrim /data
fstrim /cache
for sd in /storage/*; do
  fstrim -v ${sd}
done

# Disable System Log
pm uninstall --user 0 com.android.traceur

# Disable Some Service Log
stop logcat logcatd logd tcpdump cnss_diag statsd traced idd-logreader idd-logreadermain stats dumpstate aplogd vendor_tcpdump vendor.tcpdump vendor.cnss_diag

# Low Latency Wi-Fi
cmd wifi force-low-latency-mode enabled

# Clear Wi-Fi Logs
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs

# Disable Kernel Debugging
for i in 'debug_mask' 'log_level*' 'debug_level*' '*debug_mode' 'edac_mc_log*' 'enable_event_log' '*log_level*' '*log_ue*' '*log_ce*' 'log_ecn_error' 'seclog*' 'compat-log' '*log_enabled' 'tracing_on' 'mballoc_debug'; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo '0' > "$o"
    done
done

#Disable Adreno GPU Logging
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr

# Ram Cleaner
while true; do echo 3 > /proc/sys/vm/drop_caches; cmd activity kill-all; am kill-all; sleep 300; done &
su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '🚀 Aᴜᴛᴏ Rᴀᴍ Cʟᴇᴀɴᴇʀ Eɴᴀʙʟᴇᴅ'" >/dev/null 2>&1

# Cache Cleaner
# Log Script Cache Cleaner
LOG_FILE="/storage/emulated/0/Lynx/Cleaner.log"
log() {
    echo "$1" >> "$LOG_FILE"
}
log ""
log "# Cache Cleaner"
log " • Status : Executed"
log " • Date : $(date '+%A, %d/%m/%Y at %H:%M:%S')"
log "--------LOG--------"

# Clean Cache
clean_cache() {
    find "$1" -type d -iname '*cache*' \
    -not \( -ipath "*/*hkrpgoversea*/*" -o -ipath "*/*genshin*/*" \) \
    -exec rm -rf {} + >/dev/null 2>&1
}
clean_cache /data/data
clean_cache /data/media/0/Android/data
clean_cache /data_mirror/data_ce/null/0
clean_cache /data_mirror/data_de/null/0
clean_cache /data/user_de/0
clean_cache /data/user/0

# Clean Junk File
rm -rf /cache/ -mindepth 1 ! -name 'magisk.log' >/dev/null 2>&1
rm -rf /data/vendor/thermal/* >/dev/null 2>&1
rm -rf /data/vendor/wlan_logs >/dev/null 2>&1
rm -rf /data/anr/* >/dev/null 2>&1
rm -rf /data/log_other_mode/* >/dev/null 2>&1
rm -rf /cache/*.tmp >/dev/null 2>&1
rm -rf /dev/log/* >/dev/null 2>&1
rm -rf /data/tombstones/* >/dev/null 2>&1
rm -rf /data/system/dropbox/* >/dev/null 2>&1
rm -rf /data/log/* >/dev/null 2>&1
rm -rf /sys/kernel/debug/* >/dev/null 2>&1
rm -rf /dev/log/main >/dev/null 2>&1
rm -rf /data/system/package_cache/* >/dev/null 2>&1
rm -rf /data/media/0/mtklog >/dev/null 2>&1
rm -rf /data/media/0/MIUI/.debug_log >/dev/null 2>&1
rm -rf /data/media/0/MIUI/BugReportCache >/dev/null 2>&1
rm -rf /data/log/* >/dev/null 2>&1
rm -rf /data/logger/* >/dev/null 2>&1
rm -rf /data/tombstones/* >/dev/null 2>&1
rm -rf /data/system/usagestats/* >/dev/null 2>&1
rm -rf /sdcard/LOST.DIR >/dev/null 2>&1
rm -rf /sdcard/DCIM/.thumbnails >/dev/null 2>&1
rm -rf /sdcard/bugreports/* >/dev/null 2>&1

# Log & Notification
log "Cache Cleaned"
am start -a android.intent.action.MAIN -e toasttext "🧹 Cᴀᴄʜᴇ Cʟᴇᴀɴᴇᴅ" -n bellavita.toast/.MainActivity

# Charging Control
nohup sh $MODDIR/script/Charging-Controller.sh > /dev/null 2>&1 &

# Compiler Apps
# nohup sh $MODDIR/script/compiler.sh > /dev/null 2>&1 &

# Done
sed -Ei "s/^description=\[.*\]/description=[ ✅ Aʟʟ ᴛᴡᴇᴀᴋꜱ ɪꜱ ᴀᴘᴘʟɪᴇᴅ ]/" "$MODPROP"
nohup sh $MODDIR/script/main/updater.sh > /dev/null 2>&1 &
su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Vᴇʟᴏᴄɪᴛʏ' 'Lynx' '✅ All tweaks is applied...'" >/dev/null 2>&1

# Run Ai
sleep 3
nohup sh $MODDIR/script/Smart-AI.sh &