#!/bin/bash

# Menetapkan direktori dan file
base="/data/adb/modules/Lynx/script"
dir="/storage/emulated/0/Lynx"
except_file="${base}/eterna/eterna.conf"
applist_file="${dir}/applist_perf.txt"
custom_flow_file="${dir}/applist_flow.conf"
extra_file="${base}/flow/extra.conf"

# Make base file
pm list packages -3 | sed 's/package://' > "$except_file" && chmod 644 "$except_file" || { echo "Gagal membuat file except.txt"; exit 1; }

# Make file customable
[ -e "$custom_flow_file" ] || { touch "$custom_flow_file" && echo "# Isi dengan nama paket aplikasi (recommended) atau nama aplikasi (not recommended) yang bersangkutan untuk dikecualikan" > "$custom_flow_file"; }

# Make file extra.txt
[ -e "$extra_file" ] || { touch "$extra_file" && echo "# Isi dengan nama paket aplikasi atau nama aplikasi yang akan dikecualikan dari flow" > "$extra_file"; }

# Daftar paket app system yang akan dikecualikan
exclude_packages=("com.android.systemui" "com.android.settings")

# Memeriksa paket aplikasi pada customflow.txt
while IFS= read -r app_name || [[ -n "$app_name" ]]; do
    # Melewati baris pertama jika itu adalah komentar
    echo "$app_name" | grep -q '^#' && continue
    # Eksekusi Script
    package=$(pm list packages | grep -i -e "$app_name" | cut -d ":" -f 2 | cut -d " " -f 1)
    [ -n "$package" ] && exclude_packages+=("$package") || echo "Paket aplikasi tidak ditemukan untuk: $app_name"
done < "$custom_flow_file"

# Memeriksa paket aplikasi pada extra.txt
while IFS= read -r app_name || [[ -n "$app_name" ]]; do
    # Melewati baris pertama jika itu adalah komentar
    echo "$app_name" | grep -q '^#' && continue

    # Mencari paket aplikasi yang mengandung nama dari extra.txt
    packages_found=($(pm list packages | grep -i -F "$app_name" | cut -d ":" -f 2 | cut -d " " -f 1))
    
    # Menambahkan paket aplikasi yang ditemukan ke dalam daftar pengecualian
    for package in "${packages_found[@]}"; do
        [ -n "$package" ] && exclude_packages+=("$package") || echo "Paket aplikasi tidak ditemukan untuk: $app_name"
    done
done < "$extra_file"

# Menambahkan paket aplikasi dari applist_perf.txt ke dalam exclude_packages
while IFS= read -r package; do
    exclude_packages+=("$package")
done < "$applist_file"

# Flow Script (sisa skrip tetap sama)
[ -f "$except_file" ] || { echo "File except.txt tidak ditemukan"; exit 1; }
# Membaca paket aplikasi
while read -r package; do
    skip_package=false
    # Melewati paket aplikasi yang terdaftar
    for exclude in "${exclude_packages[@]}"; do
        [ "$exclude" == "$package" ] && { skip_package=true; break; }
    done
    grep -q "$package" "$custom_flow_file" && skip_package=true
    [ "$skip_package" = true ] && { echo "Melewatkan paket: $package"; continue; }
    # Menghentikan aplikasi sesuai paket yang sudah di filter
    pm suspend "$package" || echo "Gagal menghentikan paket: $package"
done < "$except_file" > /dev/null