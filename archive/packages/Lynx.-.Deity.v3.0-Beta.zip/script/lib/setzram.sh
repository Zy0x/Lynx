# Help function for ZRAM configuration
help_setzram() {
    echo "Usage: $0 -Zram <SIZE_IN_BYTES>"
    echo "Example: $0 -Zram 536870912  # For 512 MB"
    echo ""
    echo "Description:"
    echo "  This script configures ZRAM (compressed RAM-based block device) on your system."
    echo "  You must specify the size of the ZRAM device in bytes."
    echo ""
    echo "Arguments:"
    echo "  -Zram <SIZE_IN_BYTES>: The size of the ZRAM device in bytes."
    echo ""
    echo "Notes:"
    echo "  - The size must be a numeric value in bytes."
    echo "  - Example sizes: 536870912 (512 MB), 1073741824 (1 GB)."
}

# ZRAM configuration
main_setzram() {
    local size="$1"
    REQUIRED_FILES=(
        "/sys/class/zram-control/hot_add"
        "/sys/block/zram0/disksize"
        "/sys/block/zram0/reset"
        "/dev/block/zram0"
    )
    for file in "${REQUIRED_FILES[@]}"; do
        if [ ! -e "$file" ]; then
            log_msg "ERROR: Required file/directory not found: $file"
            echo "Please ensure that ZRAM is supported and properly initialized on your system."
            return 1
        fi
    done
    log_msg "Checking ZRAM configuration request..."
    # Check Size
    if [ -z "$size" ]; then
        log_msg "ERROR: No ZRAM size provided."
        help_setzram
        return 1
    fi
    # Validate Size
    if ! echo "$size" | grep -qE '^[0-9]+$'; then
        log_msg "ERROR: Invalid ZRAM size '$size'. Size must be a numeric value in bytes."
        help_setzram
        return 1
    fi
    log_msg "Changing ZRAM configuration with size: $size..."
    # Configure ZRAM
    RAM_DEV=$(cat /sys/class/zram-control/hot_add)
    echo "3" > /proc/sys/vm/drop_caches
    swapoff /dev/block/zram0
    echo "1" > /sys/block/zram0/reset
    Lxcore -zramalgo
    echo "$size" > /sys/block/zram0/disksize
    mkswap /dev/block/zram0
    swapon /dev/block/zram0 -p 5
    if [ $? -eq 0 ]; then
        log_msg "ZRAM successfully enabled with size: $size."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '☢️ 𝙕𝙧𝙖𝙢 𝙀𝙣𝙖𝙗𝙡𝙚𝙙'" >/dev/null 2>&1
    else
        log_msg "ERROR: Failed to enable ZRAM."
    fi
}