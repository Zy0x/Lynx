help_disablezram() {
    echo "Nothing! Coming Soon!"
}

main_disablezram() {
    if [ ! -f /sys/class/zram-control/hot_remove ] || ! ls /dev/block/zram* > /dev/null 2>&1; then
        log_msg "ERROR: Required ZRAM files or devices not found. Please ensure ZRAM is installed and enabled."
        return 1
    fi
    log_msg "Disabling all ZRAM..."
    echo "3" > /proc/sys/vm/drop_caches
    zram_devices=$(ls /dev/block/zram* 2>/dev/null)
    for zram_device in $zram_devices; do
        log_msg "Processing device: $zram_device"
        swapoff "$zram_device"
        if [ $? -ne 0 ]; then
            log_msg "ERROR: Failed to disable swap for $zram_device."
            continue
        fi
        echo "0" > /sys/class/zram-control/hot_remove
        if [ $? -ne 0 ]; then
            log_msg "ERROR: Failed to remove ZRAM module for $zram_device."
            continue
        fi
        log_msg "Successfully disabled ZRAM for $zram_device."
    done
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '⛔ 𝙕𝙧𝙖𝙢 𝘿𝙞𝙨𝙖𝙗𝙡𝙚𝙙'" >/dev/null 2>&1
}