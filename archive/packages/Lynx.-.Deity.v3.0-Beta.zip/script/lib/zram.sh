#!/bin/bash

# Help function for ZRAM commands
help_zram() {
    # Get available ZRAM algorithms dynamically
    if [ -f /sys/block/zram0/comp_algorithm ]; then
        supported_algorithms=$(cat /sys/block/zram0/comp_algorithm | sed 's/\[//g; s/\]//g')
    else
        supported_algorithms="Unknown (ZRAM not initialized)"
    fi

    # Get current ZRAM size dynamically
    if [ -f /sys/block/zram0/disksize ]; then
        current_size=$(cat /sys/block/zram0/disksize)
        # Convert size to human-readable format using awk
        current_size_human=$(awk -v size="$current_size" '
            BEGIN {
                suffixes = "KMGTPEZY"
                scale = 1024
                if (size == 0) {
                    print "0B"
                    exit
                }
                for (i = 0; size >= scale && i < length(suffixes); i++) {
                    size /= scale
                }
                printf "%.1f%sB\n", size, substr(suffixes, i, 1)
            }')
    else
        current_size="N/A"
        current_size_human="N/A"
    fi

    echo "Usage: Lxcore -zram [set|disable|help]"
    echo ""
    echo "Options:"
    echo "  set size=<SIZE_IN_BYTES>       Set the size of the ZRAM device in bytes."
    echo "  set size=<SIZE_IN_BYTES> algo=<ALGORITHM>  Set both size and compression algorithm."
    echo "  set algo=<ALGORITHM>           Set the ZRAM compression algorithm."
    echo "  disable                        Disable ZRAM."
    echo "  help                           Show this help message."
    echo ""
    echo "Examples:"
    echo "  Lxcore -zram set size=536870912            # Set ZRAM size to 512 MB"
    echo "  Lxcore -zram set size=536870912 algo=zstd  # Set ZRAM size to 512 MB and algorithm to zstd"
    echo "  Lxcore -zram set algo=lz4                 # Set ZRAM algorithm to lz4"
    echo "  Lxcore -zram disable                      # Disable ZRAM"
    echo ""
    echo "Additional Information:"
    echo "  Supported ZRAM Algorithms: $supported_algorithms"
    echo "  Current ZRAM Size: $current_size_human ($current_size bytes)"
}

# Configure ZRAM size and/or algorithm
main_setzram() {
    echo "DEBUG: Arguments received: $@"
    local size=""
    local algo=""

    # Parse arguments
    for arg in "$@"; do
        if [[ "$arg" == size=* ]]; then
            size="${arg#*=}"
        elif [[ "$arg" == algo=* ]]; then
            algo="${arg#*=}"
        fi
    done

    echo "DEBUG: Size: $size"
    echo "DEBUG: Algorithm: $algo"

    # Validate size only if it is provided
    if [[ -n "$size" && -z "$(echo "$size" | grep -E '^[0-9]+$')" ]]; then
        log_msg "ERROR: Invalid ZRAM size '$size'. Size must be a numeric value in bytes."
        help_zram
        return 1
    fi

    # Configure ZRAM size (only if size is provided)
    if [[ -n "$size" ]]; then
        REQUIRED_FILES=(
            "/sys/class/zram-control/hot_add"
            "/sys/block/zram0/disksize"
            "/sys/block/zram0/reset"
            "/dev/block/zram0"
        )
        for file in "${REQUIRED_FILES[@]}"; do
            if [ ! -e "$file" ]; then
                log_msg "ERROR: Required file/directory not found: $file"
                echo "Please ensure that ZRAM is supported and properly initialized on your system."
                return 1
            fi
        done

        RAM_DEV=$(cat /sys/class/zram-control/hot_add)
        echo "3" > /proc/sys/vm/drop_caches
        swapoff /dev/block/zram0
        echo "1" > /sys/block/zram0/reset
        echo "$size" > /sys/block/zram0/disksize
        mkswap /dev/block/zram0
        swapon /dev/block/zram0 -p 5
        if [ $? -eq 0 ]; then
            log_msg "ZRAM successfully enabled with size: $size."
            su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '☢️ Zʀᴀᴍ Eɴᴀʙʟᴇᴅ'" >/dev/null 2>&1
        else
            log_msg "ERROR: Failed to enable ZRAM."
            return 1
        fi
    fi

    # Configure ZRAM algorithm (only if algo is provided)
    if [[ -n "$algo" ]]; then
        #output=$(cat /sys/block/zram0/comp_algorithm)
        output=$(cat /storage/emulated/0/Oprek/tes2eadsast.sh)
        if [[ "$output" == *"$algo"* ]]; then
            echo "$algo" > /sys/block/zram0/comp_algorithm
            log_msg "ZRAM compression algorithm set to '$algo'."
        else
            log_msg "ERROR: Requested algorithm '$algo' is not supported."
        fi
    fi
}

# Disable ZRAM
main_disablezram() {
    if [ ! -f /sys/class/zram-control/hot_remove ] || ! ls /dev/block/zram* > /dev/null 2>&1; then
        log_msg "ERROR: Required ZRAM files or devices not found. Please ensure ZRAM is installed and enabled."
        return 1
    fi
    log_msg "Disabling all ZRAM..."
    echo "3" > /proc/sys/vm/drop_caches
    zram_devices=$(ls /dev/block/zram* 2>/dev/null)
    for zram_device in $zram_devices; do
        log_msg "Processing device: $zram_device"
        swapoff "$zram_device"
        if [ $? -ne 0 ]; then
            log_msg "ERROR: Failed to disable swap for $zram_device."
            continue
        fi
        echo "0" > /sys/class/zram-control/hot_remove
        if [ $? -ne 0 ]; then
            log_msg "ERROR: Failed to remove ZRAM module for $zram_device."
            continue
        fi
        log_msg "Successfully disabled ZRAM for $zram_device."
    done
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '⛔ ZRAM Dɪꜱᴀʙʟᴇᴅ'" >/dev/null 2>&1
}