#!/bin/bash
list_swap_files() {
    echo "Detected SWAP files on device:"
    found=0
    for f in $(find /data /cache /mnt /sdcard /storage -type f \( -iname "*swap*" -o -iname "swapfile*" \) 2>/dev/null); do
        size_kb=$(du -k "$f" 2>/dev/null | cut -f1)

        # Hanya proses file yang lebih besar dari 100 MB (100000 KB)
        if [ "$size_kb" -gt 102400 ]; then
            # Konversi ukuran ke bentuk yang dapat dibaca manusia
            human_size=$(awk -v size="$size_kb" '
                BEGIN {
                    suffixes = "KMGTPEZY"
                    scale = 1024
                    if (size == 0) {
                        print "0B"
                        exit
                    }
                    for (i = 0; size >= scale && i < length(suffixes); i++) {
                        size /= scale
                    }
                    printf "%.1f%sB\n", size, substr(suffixes, i+1, 1)
                }')

            if grep -q "$f" /proc/swaps; then
                echo "  ✔️ $f [ACTIVE] - $human_size ($size_kb KB)"
            else
                echo "  ⚠️ $f [INACTIVE] - $human_size ($size_kb KB)"
            fi
            found=1
        fi
    done
    if [ $found -eq 0 ]; then
        echo "  No large SWAP files (over 100MB) detected."
    fi
}


# Help function for SWAP commands
help_swap() {
    echo "Usage: Lxcore -swap [set|enable|disable|remove|help]"
    echo ""
    echo "Options:"
    echo "  set size=<SIZE_IN_KB>         Create and enable a SWAP file with the specified size in kilobytes."
    echo "  enable                        Enable the existing SWAP file without changing its size."
    echo "  disable                       Disable the SWAP file(s)."
    echo "  remove                        Disable and delete all SWAP file(s) found."
    echo "  help                          Show this help message."
    echo ""
    echo "Examples:"
    echo "  Lxcore -swap set size=524288      # Create and enable a 512 MB SWAP file (524288 KB)"
    echo "  Lxcore -swap enable              # Enable the existing SWAP file"
    echo "  Lxcore -swap disable             # Disable the SWAP file"
    echo "  Lxcore -swap remove              # Disable and delete all detected SWAP files"
    echo ""
    list_swap_files
    echo ""
    echo "Notes:"
    echo "  - If the SWAP file does not exist, use 'set' to create it."
    echo "  - Ensure you have sufficient storage space before creating a large SWAP file."
}

# Disable all active swap files
disable_all_swaps() {
    awk 'NR>1 {print $1}' /proc/swaps | while read swapfile; do
        log_msg "Disabling swap: $swapfile"
        su -c swapoff "$swapfile" >/dev/null 2>&1
    done
}

# Enable the SWAP file
main_enableswap() {
    log_msg "Enabling SWAP..."
    local found_swap=$(awk 'NR>1 {print $1}' /proc/swaps)

    if [ -n "$found_swap" ]; then
        log_msg "SWAP is already active: $found_swap"
        return 0
    elif [ -f "/data/swap" ]; then
        su -c swapon /data/swap -p 3 >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            log_msg "SWAP successfully enabled."
            su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '☣️ 𝙎𝙬𝙖𝙥 𝙀𝙣𝙖𝙗𝙡𝙚𝙙'" >/dev/null 2>&1
        else
            log_msg "ERROR: Failed to enable SWAP."
            su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '❌ 𝙎𝙬𝙖𝙥 𝙁𝙖𝙞𝙡𝙚𝙙 𝙩𝙤 𝙀𝙣𝙖𝙗𝙡𝙚'" >/dev/null 2>&1
            return 1
        fi
    else
        log_msg "ERROR: No SWAP file found. Please run 'set' first."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '❌ 𝙉𝙤 𝙎𝙬𝙖𝙥 𝙁𝙞𝙡𝙚 𝙁𝙤𝙪𝙣𝙙'" >/dev/null 2>&1
        return 1
    fi
}

# Disable all SWAP files
main_disableswap() {
    log_msg "Disabling all SWAP files..."
    if awk 'NR>1 {print $1}' /proc/swaps | grep -q .; then
        disable_all_swaps
        log_msg "All SWAPs disabled."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '⚠️ 𝘼𝙡𝙡 𝙎𝙬𝙖𝙥 𝘿𝙞𝙨𝙖𝙗𝙡𝙚𝙙'" >/dev/null 2>&1
    else
        log_msg "No active SWAP to disable."
    fi
}

# Set and enable new SWAP file
main_setswap() {
    local size="$1"
    log_msg "Setting up SWAP configuration..."

    if [ -z "$size" ]; then
        help_swap
        return 1
    fi

    if ! echo "$size" | grep -qE '^[0-9]+$' || [ "$size" -le 0 ] 2>/dev/null; then
        log_msg "ERROR: Invalid SWAP size '$size'."
        help_swap
        return 1
    fi

    # Disable all existing swap first
    log_msg "Disabling existing SWAP(s)..."
    disable_all_swaps

    # Remove any detected swap file (especially /data/swap)
    if [ -f "/data/swap" ]; then
        log_msg "Removing existing /data/swap..."
        rm -f /data/swap
    fi

    log_msg "Creating new SWAP file: $size KB..."
    dd if=/dev/zero of=/data/swap bs=1024 count=$size >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        log_msg "ERROR: Failed to create SWAP file."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '❌ 𝙁𝙖𝙞𝙡𝙚𝙙 𝙩𝙤 𝘾𝙧𝙚𝙖𝙩𝙚 𝙎𝙬𝙖𝙥'" >/dev/null 2>&1
        return 1
    fi

    mkswap /data/swap >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        log_msg "ERROR: Failed to initialize SWAP file."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '❌ 𝙁𝙖𝙞𝙡𝙚𝙙 𝙩𝙤 𝙄𝙣𝙞𝙩𝙞𝙖𝙡𝙞𝙯𝙚 𝙎𝙬𝙖𝙥'" >/dev/null 2>&1
        return 1
    fi

    su -c swapon /data/swap -p 3 >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        log_msg "SWAP successfully created and enabled: $size KB."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '☣️ 𝙎𝙬𝙖𝙥 𝙀𝙣𝙖𝙗𝙡𝙚𝙙'" >/dev/null 2>&1
    else
        log_msg "ERROR: Failed to enable SWAP."
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '❌ 𝙎𝙬𝙖𝙥 𝙀𝙣𝙖𝙗𝙡𝙞𝙣𝙜 𝙁𝙖𝙞𝙡𝙚𝙙'" >/dev/null 2>&1
        return 1
    fi
}

# Fungsi untuk menghapus semua swap (aktif dan tidak aktif)
main_removeswap() {
    log_msg "Removing all large SWAP files (over 100MB)..."
    for f in $(find /data /cache /mnt /sdcard /storage -type f \( -iname "*swap*" -o -iname "swapfile*" \) 2>/dev/null); do
        size_kb=$(du -k "$f" 2>/dev/null | cut -f1)

        # Hanya proses file yang lebih besar dari 100 MB (100000 KB)
        if [ "$size_kb" -gt 102400 ]; then
            if grep -q "$f" /proc/swaps; then
                log_msg "Disabling active SWAP: $f"
                su -c swapoff "$f" >/dev/null 2>&1
                if [ $? -eq 0 ]; then
                    log_msg "SWAP disabled: $f"
                else
                    log_msg "⚠️ 𝙁𝙖𝙞𝙡𝙚𝙙 𝙩𝙤 𝘿𝙞𝙨𝙖𝙗𝙡𝙚 𝙎𝙬𝙖𝙥: $f"
                fi
            fi

            log_msg "Deleting SWAP file: $f"
            rm -f "$f"
            if [ $? -eq 0 ]; then
                log_msg "SWAP file deleted: $f"
            else
                log_msg "⚠️ 𝙁𝙖𝙞𝙡𝙚𝙙 𝙩𝙤 𝙙𝙚𝙡𝙚𝙩𝙚 𝙎𝙒𝘼𝙋 𝙛𝙞𝙡𝙚: $f"
            fi
        fi
    done

    rm -f "$MODPATH/swapram_installed"

    su -lp 2000 -c "cmd notification post -S bigtext -t 'Lʏɴx - Dᴇɪᴛʏ' 'Lʏɴx' '🗑️ 𝘼𝙡𝙡 𝙎𝙬𝙖𝙥 𝙁𝙞𝙡𝙚𝙨 𝙍𝙚𝙢𝙤𝙫𝙚𝙙'" >/dev/null 2>&1
}
