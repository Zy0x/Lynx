# Lynx Universal [Zero-Loophole Mode Guard & Dynamic Voltage-Scaled Bounding] 7.0.0-RC62
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC62** (Lynx Kernel Manager v3.1.23): **Audit Menyeluruh Celah Semua Mode Pengisian Daya: Penutupan Celah Lonjakan Arus Mode Cool Melalui Skalasi Dinamis Arus Input Berbasis Voltase Adaptor (Mencegah Penggandaan Arus Baterai di 9V/10V), Resolusi Total Celah Mode Standar Lebih Cepat Dibanding Mode Hyper dengan Menjaga Kestabilan Timing Pulsa Negosiasi Pump Express Tanpa Interupsi Loop Setiap Detik, Penghapusan Subproses Redundan `dumpsys battery reset` Berkala, Serta Penyelarasan Penuh Skrip Shell Fallback**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC62)

### 1. Penutupan Celah Lonjakan Arus Mode Cool (`calculate_regulated_input_current_ma`)
- **Akar Masalah Lonjakan Arus**: Ketika pengguna beralih dari Hyper ke Cool (atau saat mode Sejuk diaktifkan), adaptor tetap mempertahankan voltase tinggi 9V/10V (Pump Express/USB-PD). Menulis batas `input_current=1000 mA` pada PMIC buck converter menghasilkan daya masuk $9\text{V} \times 1\text{A} = 9\text{W}$, yang ketika dikonversi ke baterai 4.0V melipatgandakan arus menjadi $\approx 2025\text{ mA}$ (dua kali lipat target 1000 mA!).
- **Skalasi Daya Berbasis Voltase Real-time**: Mengimplementasikan formula transfer daya fisis:
  $$I_{in\_bus} = \frac{I_{bat\_target} \times 4200}{V_{bus}}$$
  Jika $V_{bus} \ge 6000\text{ mV}$ (misal 9.0V), batas arus input ke PMIC otomatis dikurangi ke $\approx 466\text{ mA}$ sehingga daya adaptor tidak melebihi 4.2W dan arus ke baterai dijamin mutlak $\le 1000\text{ mA}$.
- **Soft-Pulse Reset ke 5V**: Mode Sejuk secara otomatis memutus sesaat FET input untuk memaksa adaptor menurunkan rel daya ke 5V standar USB murni.

### 2. Resolusi Total Celah Mode Standar Lebih Cepat Dibanding Mode Hyper
- **Akar Masalah Interupsi Pulsa**: Pada versi lawas, evaluasi `invariants_intact` memeriksa `enable_sc == "1"`. Karena saat baru dicolok voltase adaptor masih 5V (`enable_sc="0"`), kondisi invariant selalu bernilai `false`, menyebabkan `apply_hyper_mode()` dijalankan ulang setiap 1 detik. Penulisan sysfs berkala ini memotong dan mereset kereta pulsa kernel Pump Express (`pe_work_func`), menjebak adaptor di 5V / 1.5A (7.5W). Sebaliknya, pada mode Standar, skrip tidak berjalan setiap detik sehingga kernel dapat menyelesaikan negosiasi pulsa tanpa gangguan dan melesat ke 33W.
- **Stabilisasi Timing Handshake Negosiasi**: Invariant kini memverifikasi kesesuaian status `enable_sc` dengan voltase aktual (`adpv_clean >= 6500`). Selama fase negosiasi awal di 5V, register kernel dibiarkan hening tanpa interupsi, memberikan ruang waktu 3–4 detik bagi driver hardware untuk menyelesaikan handshake dan melesat ke voltase maksimal.
- **Relaksasi Batas Invariant Tapering**: Mengubah syarat `sc_limit >= 8000` menjadi `sc_limit >= 1000` sehingga fase tapering 80–90% (3,200 mA) dan 90–94% (2,200 mA) tidak memicu perulangan re-injeksi berkala.

### 3. Eliminasi Eksekusi Subproses Redundan pada Mode Standar
- Menghapus eksekusi subproses `dumpsys battery reset` yang sebelumnya berjalan setiap siklus 1 detik saat mode standar terpilih. Pemanggilan hanya dieksekusi secara selektif saat transisi keluar dari status hardware bypass.
- Evaluasi state marker `/dev/lynx_standard_charging` memastikan eksekusi mode standar dan sejuk bersifat atomik dan bebas dari overhead CPU.

### 4. Sinkronisasi Penuh Shell Fallback (`Charging-Controller.sh`)
- Menambahkan implementasi lengkap `fallback_cool()`, `fallback_standard()`, dan `fallback_custom()` dengan mitigasi soft-reconnect dan batas daya 5W yang identik dengan mesin native Rust `lynxd`.

---

# Lynx Universal [Zero-Touch Handshake Reset & Voltage-Gated Pump Activation] 7.0.0-RC61
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC61** (Lynx Kernel Manager v3.1.22): **Integrasi Mekanisme Voltage-Gated Switched-Capacitor Pump (Mencegah Fault Arus Balik UVLO Saat Adaptor di 5V), Sistem Zero-Touch Soft Reconnect (Reset Handshake BC1.2/PE Tanpa Cabut Kabel), dan Audit Ketat Pemulihan Zero-Leakage Pasca-Cabut Charger Serta Skalabilitas Multi-Vendor (Qualcomm SPMI vs MediaTek I2C vs Dual-Cell 2S)**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC61)

### 1. Voltage-Gated Switched-Capacitor Pump Activation (`charging.rs` & `Charging-Controller.sh`)
- **Eliminasi Masalah Colok-Cabut 2-3 Kali**: Menganalisis penyebab fisis kegagalan handshake pada konverter 2:1 (RT9759). Jika `enable_sc=1` aktif saat VBUS masih 5V, pompa menghasilkan 2.5V yang lebih rendah dari baterai (4.2V), memicu *Reverse Current Protection* dan mengunci adaptor di mode 5V lambat.
- **Gating Voltase Adaptor (Threshold $\ge 6.5\text{V}$)**: Register `enable_sc` kini secara ketat hanya diaktifkan jika sensor `ADC_Charger_Voltage` membaca $\ge 6500\text{ mV}$ (setelah negosiasi PE berhasil menaikkan VBUS ke 9V/10V). Pada 5V awal, pengisian ditangani aman oleh buck converter tanpa risiko UVLO trip.

### 2. Zero-Touch Soft Reconnect Watchdog (`charging.rs`)
- **Automated Handshake Kick**: Menyediakan fungsi `trigger_charger_soft_reconnect()` yang secara otomatis memutus sesaat FET input charging (`input_suspend` 150 ms) atau memicu `Pump_Express` / `rerun_aicl`.
- **Deteksi Adaptor Macet**: Jika dalam mode Hyper terdeteksi adaptor macet di mode 5V standar USB selama $\ge 4$ detik berturut-turut pada SoC $< 80\%$, sistem secara otomatis mengeksekusi *soft-reconnect* untuk memulai ulang handshake tanpa mengharuskan pengguna mencabut kabel secara fisik.

### 3. Pemulihan Penuh Pasca-Cabut Charger & Zero Battery Leakage
- **Audit Ground-Truth Hardware Nyata**: Terverifikasi secara empiris di kernel bahwa saat charger dicabut:
  - `enable_sc` seketika menjadi `0` (pompa dimatikan).
  - `BN_TestMode` kembali ke `0` dan `BatteryNotify` kembali ke `1`.
  - `thermal_zone1/mode` kembali ke `enabled` dan `pcb_thermal_debug` serta `clabcct` kembali ke setpoint pabrik OEM.
  - Seluruh lockfile RAM dibersihkan dan OS wakelock dilepas via `dumpsys battery reset` sehingga konsumsi daya idle baterai terlindungi dari kebocoran (*zero leakage*).

### 4. Skalabilitas Multi-Vendor Bebas Hardcode (Qualcomm vs MediaTek vs 2S Dual-Cell)
- **Lapisan Abstraksi HAL**: Mendukung pemetaan dinamis kelas `power_supply` Qualcomm berbasis SPMI (satuan mikroampere µA, `rerun_aicl`, `system_temp_level`) dan MediaTek I2C (satuan milliampere mA, direct pump).
- **Deteksi Baterai Seri Dual-Cell (2S)**: Arsitektur 65W–240W dideteksi melalui $V_{bat} \ge 7.0\text{V}$ untuk menyesuaikan batas arus PMIC hingga 20,000 mA tanpa keliru membatasi daya.

---

# Lynx Universal [Unconstrained 0-80% Hyper Curve & Sustained Direct Pump] 7.0.0-RC60
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC60** (Lynx Kernel Manager v3.1.21): **Implementasi Kurva Pengisian Hyper Mode Bebas Hambatan (0–80% Geber Penuh Watt Maksimal ~3900–4500 mA, 80–90% Kecepatan Tinggi Bertahan di ~3200 mA dengan Direct Charge Pump Tetap Aktif), Netralisasi Throttle Termal Kernel OEM (`mtktsAP` & `cooling_device56 abcct`), Perbaikan Resolusi Konflik Pill Mode (`⚡ HYPER` Single Source of Truth), serta Verifikasi Telemetri Sensor ADC Presisi**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC60)

### 1. Kurva Pengisian Daya Hyper Mode 0–80% Full Max & 80–90% Sustained Speed (`charging.rs`)
- **Fase Constant Current (CC) Penuh 0–80% SoC**: Menggeber arus pengisian daya maksimal tanpa pembatasan dini (`hyper`, target 12,000 mA / hingga batas hardware PMIC ~3900–4500 mA pada 18W–33W).
- **Fase Kecepatan Tinggi Bertahan 80–90% SoC (`tapering_80`)**: Menjaga arus pengisian pada kecepatan ~80% dari batas maksimal (**3,200 mA**), secara tegas **TIDAK** anjlok ke separuh (1500–1600 mA).
- **Direct Charge Pump Tetap Aktif di 80–90%**: Memperbaiki ambang `is_trickle = effective_ma < 1500`. Pompa muatan ganda (`enable_sc=1`, `pe20=1`, `pe40=1`) tetap dipertahankan aktif pada rentang 80–90% sehingga pengisian cepat 9V/10V tetap bekerja.
- **Transisi Halus Pasca-90%**: Penurunan bertahap yang aman pada rentang 90–94% (2,200 mA) dan 95–99% (1,000 mA), serta AutoCut/Bypass hardware penuh pada 100% SoC (0 mA).

### 2. Netralisasi Throttling Termal Kernel MediaTek (`mtktsAP` & `abcct`)
- **Penonaktifan Trip Point OEM Pengganggu**: Menetralisir `thermal_zone1` (`mtktsAP`) dan mendinginkan derater cooling device 56 (`abcct`) yang sebelumnya mengunci target arus baterai ke 600–750 mA saat suhu menyentuh 41–42°C.
- **Penyelarasan Ambang Termal Toleransi Tinggi**: Mengangkat kurva termal PCB dan DV2 in-memory ke level aman toleransi tinggi (`[55,4500,58,3200,2500]` pada `pcb_thermal_debug` dan `[101,55,58,60,4500,3200,2500]` pada `dv2_debug`) di mesin native `lynxd` dan skrip fallback `Charging-Controller.sh`.
- **Restorasi Otomatis**: Semua trip point dan mode termal kernel dipulihkan ke setelan default OEM saat pengisian selesai atau kabel dilepas.

### 3. Perbaikan Resolusi Konflik Pill Mode UI (`ChargingHeroDisplayCard.kt`)
- **Sanitasi Status Internal**: Memastikan sub-status internal (`tapering_80`, `night_gentle`, dll.) tidak menimpa mode pengisian utama yang dipilih pengguna.
- **Single Source of Truth**: Menetapkan prioritas mode `hyper` saat `chargingConfig.chargingMode == "hyper"` atau `extremeChargingEnabled == true`, meniadakan masalah pill yang sebelumnya keliru menampilkan `⚡ STANDARD`.

### 4. Perbaikan Skala Register Arus Bus Adaptor (`LynxBatteryTelemetryRepository.kt`)
- **Akurasi Sensor ADC Hardware Murni**: Memperbaiki pemetaan node tegangan bus ke `/sys/devices/platform/charger/ADC_Charger_Voltage` dan arus bus ke `/sys/devices/platform/charger/input_current`.
- **Heuristik Skala Multi-Satuan**: Mendukung deteksi presisi untuk register berformat 10 µA (seperti `209264` -> `2092 mA`), microampere (uA), dan milliampere (mA).
- **Proteksi Overflow 32-Bit Berbasis Panjang String**: Menggunakan proteksi `${#raw_val} >= 10` untuk mencegah integer wrap-around 32-bit tanpa terkena limitasi `strtol` pada shell Android.

---

# Lynx Universal [Gesture Pager Charging Bento & Authentic Hardware Telemetry] 7.0.0-RC59
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC59** (Lynx Kernel Manager v3.1.20): **Perombakan Total Sistem Telemetri Bento Grid Pengisian Daya Menggunakan Gesture-Driven Horizontal Pager dengan Dot Indicator Ultra-Compact (Hanya Berpindah Saat Digeser, Tanpa Kedipan Otomatis), Standardisasi Angka Putih Netral Monospace Tabular (Meniadakan Bias Warna Kuning), serta Audit Ketat Akurasi Sensor Hardware ADC Murni (Eliminasi Mutlak Rumus Perkiraan Buatan)**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC59)

### 1. Gesture-Driven Horizontal Pager & Ultra-Compact Dot Indicator (`ChargingHeroDisplayCard.kt`)
- **Kendali Geser Manual Murni (No Auto-Flicker)**: Mengeliminasi siklus timer otomatis yang melelahkan mata. Transisi antara perspektif *Input Adaptor* dan *Sel Baterai* kini 100% berada di bawah kendali pengguna melalui gestur geser horizontal (*horizontal swipe*) yang mulus dan tenang.
- **Indikator Titik Kompak (Space-Saving Dot Indicator)**: Menampilkan indikator titik minimalis (`● ○` / `○ ●`, tinggi 3.5 dp) di bawah ubin Bento Grid yang hanya aktif saat charging terhubung dengan data adaptor valid. Menghemat ruang vertikal dan menjaga estetika antarmuka tetap bersih.
- **Header Pill Subtitle Real-Time**: Subtitle pada banner protokol (`Input adaptor • 34.0 W` vs `Daya baterai • 17.0 W`) tersinkronisasi secara dinamis mengikuti halaman pager yang aktif.

### 2. Standardisasi Angka Putih Netral Berstandar Instrumen EV (`ChargingHeroDisplayCard.kt`)
- **Meniadakan Bias Warna Kuning/Emas**: Seluruh angka pembacaan daya, tegangan, dan arus distandardisasi menggunakan warna putih bersih (`TextPrimary` / `#FFFFFF`) dengan tipografi tabular monospace.
- **Pencegahan Ambiguitas UX**: Menghilangkan persepsi negatif pengguna yang mengasosiasikan warna kuning dengan status peringatan/warning, sehingga tampilan selaras dengan instrumen dashboard profesional.

### 3. Akurasi Sensor Hardware Ground-Truth (`LynxBatteryTelemetryRepository.kt` & `LynxTelemetryMapper.kt`)
- **Eliminasi Formula Estimasi Buatan**: Menghapus seluruh rumus kalkulasi perkiraan buatan (`watt / effFactor`) yang sebelumnya memicu kesalahan beruntun saat register arus kernel tidak terpetakan.
- **Pembacaan Murni Sensor ADC Fisik**: Daya adaptor ($P_{adaptor}$) hanya dihitung jika tegangan bus ($V_{bus} \ge 4.0\text{V}$) dan arus bus ($I_{bus} \ge 100\text{mA}$) terdeteksi secara fisik dari sensor hardware kernel (`ADC_Charger_Voltage` & `Pump_Express_ICharger`). Jika sensor arus tidak tersedia, modul secara transparan menyajikan telemetri Fuel Gauge baterai murni tanpa rekayasa.
- **Perbaikan Unsigned 32-Bit Overflow**: Menangani overflow negatif register arus (nilai `4294967249` pada Transsion battery) agar tidak salah terbaca sebagai arus pengisian daya positif.

---

# Lynx Universal [Dual-Mode Crossfade Charging Telemetry Engine] 7.0.0-RC58
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC58** (Lynx Kernel Manager v3.1.19): **Integrasi Animasi Sinkron Dual-Mode Telemetri (Crossfade Fade In/Out) pada Bento Grid Dashboard Pengisian Daya (Bergantian antara Input Adaptor Charger 34W Emas & Daya Bersih Baterai 17W Hijau Neon), Dukungan Interaksi Instan Tap-to-Toggle, dan Subtitle Pill Status Dinamis**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC58)

### 1. Dual-Mode Crossfade Telemetry pada Charging Hero Card (`ChargingHeroDisplayCard.kt`)
- **Animasi Sinkron Tiga Ubin (3-Tile Synchronized Fade)**: Mengintegrasikan animasi `Crossfade` (350 ms) yang berputar otomatis setiap 2,5 detik saat pengisian daya aktif, menampilkan dua perspektif kelistrikan secara transparan:
  - **Mode 1: Sumber Daya Masuk (Input Adaptor Charger - Kuning Emas / Electric Gold `#FFB800`)**:
    - Ubin Daya: `Daya Adaptor` (misal **34.0 W**)
    - Ubin Tegangan: `Tegangan Charger` (misal **8.88 V**)
    - Ubin Arus: `Arus Charger` (misal **+3770 mA**)
  - **Mode 2: Penyerapan Sel Baterai (Net Battery Inflow - Hijau Neon `#00FF9D`)**:
    - Ubin Daya: `Daya Baterai` (misal **17.0 W**)
    - Ubin Tegangan: `Tegangan Sel` (misal **4.34 V**)
    - Ubin Arus: `Arus Baterai` (misal **+3816 mA**)
  - Ubin Suhu: Tetap konstan memantau temperatur fisik hardware baterai (`tempFloat °C`).
- **Dukungan Interaksi Instan (Tap-to-Toggle)**: Pengguna dapat mengetuk ubin mana pun untuk langsung beralih mode tampilan secara seketika tanpa harus menunggu siklus animasi otomatis.
- **Header Pill Subtitle Dinamis**: Mengalihkan deskripsi protokol antara `Input adaptor • 34.0 W` dan `Daya baterai • 17.0 W` sesuai status tampilan aktif.
- **Presisi Geometri Bento Grid 2x2 Simetris**: Memastikan keempat kotak telemetri (Daya, Suhu, Tegangan, Arus) beroperasi dalam struktur grid kontainer 2x2 yang terpadu dengan bobot `Modifier.weight(1f)` dan `fillMaxWidth()`, meniadakan penyusutan lebar ubin (narrow box wrapping) saat animasi maupun saat tidak mengisi daya sehingga tampilan 100% konsisten, simetris, dan rapi.

---

# Lynx Universal [Native 3-Stage Calibrated Charging Thermal Engine] 7.0.0-RC57
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC57** (Lynx Kernel Manager v3.1.18): **Integrasi Native 3-Stage Calibrated Charging Thermal Curve (<48°C: 33W Penuh, 48°C–50°C: 18W Sweet Spot, >50°C: 10W Proteksi Darurat OEM), Eliminasi Mutlak Ketergantungan KPM Thermal via Direct Sysfs Engine (`pcb_thermal_debug` & `dv2_debug`), dan Penyelarasan Suhu Otentik Baterai**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC57)

### 1. 3-Stage Calibrated Charging Thermal Engine (`charging.rs` & `Charging-Controller.sh`)
- **Implementasi Kurva Cerdas Tiga Tingkat**: Menggantikan skema unconstrained biner 95°C/100°C dengan kurva bergradasi halus yang terkalibrasi presisi pada hardware:
  - **Tingkat 1 (< 48°C)**: Mengalirkan daya puncak penuh **33 Watt** (hingga 6.000 mA pump current). Memperpanjang durasi fast charging hingga baterai terisi ~65%–70% tanpa terpotong dini di 45°C.
  - **Tingkat 2 (48°C – 50°C)**: Menahan arus secara elegan di **18 Watt** (~4.000 mA). Mencegah daya anjlok drastis ke 10W, sekaligus menstabilkan temperatur PCB agar tidak terus merangkak naik.
  - **Tingkat 3 (> 50°C)**: Mengaktifkan proteksi darurat OEM **10 Watt** (2.500 mA / 1.500 mA) demi perlindungan absolut sel baterai dan sirkuit motherboard.
- **Konfigurasi Node Kernel Transsion**:
  - `pcb_thermal_debug` $\rightarrow$ `[48,4000,50,2500,1500]`
  - `dv2_debug` (Perintah 101) $\rightarrow$ `[101,48,50,52,4000,2500,1500]`
  - `dv2_debug` (Perintah 102) $\rightarrow$ `[102,75,80,85,600,900,1200]`

### 2. Eliminasi Ketergantungan KPM Thermal (100% Native Lynx)
- **Kompatibilitas Universal Seluruh Root**: Karena kernel Transsion MediaTek mengekspos gerbang sysfs yang sepenuhnya dapat ditulis (`-rw-rw-rw-`), seluruh logika kontrol termal pengisian daya kini dijalankan secara murni oleh daemon `lynxd` dan skrip kontrol. Pengguna Magisk, KernelSU, maupun APatch dapat menikmati fitur ini tanpa perlu memuat modul KPM khusus.

### 3. Penyelarasan Pembacaan Suhu Otentik (`Battery_Temperature`)
- **Eliminasi Hard Spoofing Statis 28°C**: Mengganti pemalsuan temperatur statis dengan pembacaan sensor otentik yang diselaraskan dengan tabel ambang batas bertingkat, menjamin transisi otomatis dari 33W ke 18W dan sebaliknya berlangsung mulus secara real-time.

---

# Lynx Universal [Extreme Storage Prefetch & VM Swappiness Tuning] 7.0.0-RC56
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC56** (Lynx Kernel Manager v3.1.17): **Integrasi Permanen Internal Storage Read-Ahead Prefetch (512 KB) untuk Penyimpanan UFS/eMMC pada Profil Performance & Extreme, Penyetelan Agresif VM Swappiness (30) pada Mode Extreme untuk Mengeliminasi ZRAM Thrashing, dan Verifikasi Lapangan Gameplay Aktif Genshin Impact**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC56)

### 1. Internal Storage Read-Ahead Prefetch (`translator.rs`)
- **Penyetelan Otomatis Node Blok Internal**: Menyuntikkan konfigurasi `512 KB` pada antrean blok penyimpanan internal (`/sys/block/{sda,sdb,sdc,mmcblk0}/queue/read_ahead_kb`) saat mode performa tinggi atau ekstrem aktif.
- **Eliminasi Micro-Freeze Rendering Map**: Mengakselerasi pembacaan tekstur 3D dan aset geometri game dunia terbuka (*open-world* seperti Genshin Impact) langsung dari storage fisik UFS.

### 2. VM Swappiness Tuning pada Mode Extreme
- **Penyusutan Nilai Swappiness ke 30**: Menurunkan kecenderungan kernel melakukan kompresi memori ZRAM di tengah permainan yang sebelumnya memicu lonjakan latensi (*frametime jitter*).

### 3. Validasi Komparatif Live Gameplay (Genshin Impact di Helio G96)
- **Kenaikan Framerate**: Dari rata-rata **27.69 FPS (Balanced)** melompat ke **36.18 FPS (Extreme)** (+30.6%).
- **Pengurangan Stutter Parah (Jank)**: Frame jank berkurang dari **26.26%** menjadi **5.48%** (pemotongan 79% stutter).
- **Frekuensi Terkunci**: Big Cores 6–7 terkunci di **2.050 MHz** dan GPU Mali-G57 terkunci di **950 MHz (Indeks 0 Zero-Throttle)**.

---

# Lynx Universal [Zero-Throttle GPU & MediaTek CCI Performance Synchronization] 7.0.0-RC55
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC55** (Lynx Kernel Manager v3.1.16): **Sinkronisasi Menyeluruh Profil Eksekusi Daemon (`ProfileExecutor`) dengan Subkomponen Termal & Cpuset, Pembongkaran Pembatas Termal GPU MediaTek (`gpufreq_limit_table` unthrottle ID 3–7 pada Extreme Mode), Integrasi MediaTek CoreLink Interconnect (CCI Sports Mode), dan DVFS Aggressive Frame Tracking**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC55)

### 1. Sinkronisasi Otomatis ProfileExecutor dengan Subkomponen Termal & Cpuset
- **Eliminasi Celah Transisi Profil**: Sebelumnya pengubahan profil melalui WebUI atau CLI hanya mengatur parameter umum tanpa menyinkronkan subsistem termal kernel dan cpuset. Pada versi ini, setiap kali profil `extreme` dipilih, sistem secara otomatis mengeksekusi `ThermalController::set_mode("extreme")` dan `CpusetController::apply_preset("gaming")`.
- **Dukungan Profil Berjenjang**:
  - `extreme`: Thermal bypass penuh + GPU unthrottle mutlak + isolasi Big Cores 6–7 untuk `top-app`.
  - `performance`: Thermal gaming mode + unthrottle terukur + cpuset gaming.
  - `powersave`: Mode konservatif termal + cpuset battery.
  - `balanced`: Pemulihan governor seimbang + cpuset seimbang.

### 2. Pembongkaran Limitasi Termal GPU MediaTek pada Extreme Mode (`thermal.rs`)
- **Penetapan Zero-Throttle Table**: Menyuntikkan konfigurasi `0 0` pada seluruh indeks thermal throttling GPU MediaTek (`/proc/gpufreq/gpufreq_limit_table` ID 3 sampai 7) pada profil `extreme`, mencegah kernel mengunci frekuensi GPU Mali-G57 ke 316 MHz saat suhu meningkat.
- **Bypass Driver Proteksi Termal**: Mengaktifkan `ignore_thermal_protect 1`, `ignore_pbm_limited 1`, menonaktifkan `thrm_limit_cpu`, dan mematikan `eara_thermal` saat mode performa tinggi aktif.

### 3. MediaTek CoreLink Interconnect (CCI) & DVFS Aggressive Frame Tracking (`translator.rs`)
- **CCI Sports Mode**: Mengunci `cpufreq_cci_mode=1` saat performa tinggi untuk memangkas latensi transfer data antar-cluster CPU dan GPU.
- **Power Mode 3**: Mengaktifkan `cpufreq_power_mode=3` (Sports Mode) pada MediaTek DVFS.
- **Aggressive Frame Tracking**: Mengaktifkan `dvfs_loading_mode=1` dan menaikkan `boost_amp=3` pada GED HAL agar GPU merespons lonjakan beban frame game dalam < 1 ms.

---

# Lynx Universal [Adaptive Undervolt & Overclock Engine KPM] 7.0.0-RC54
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC54** (Lynx Kernel Manager v3.1.15): **Implementasi KernelPatch Module (KPM) Lynx Adaptive Undervolt (UV) & Overclock (OC) Engine: Pemetaan 9 Power Rails Hardware PMIC (MT6358 vproc11, vproc12, vgpu, vsram, vcore), Ring-0 Hooking pada regulator_set_voltage & ged_dvfs_vcore untuk Pemotongan Panas Kuadratik (P = C·V²·f), Eliminasi Latensi Transisi OPP via dev_pm_opp_set_rate, dan Batas Pengaman Hardware Floor 700mV/550mV**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC54)

### 1. Lynx Adaptive Undervolt & Overclock Engine KPM (`lynx_oc_uv.c`)
- **Pemetaan Power Rails Hardware PMIC**: Memetakan seluruh jalur daya fisik MT6358: `vproc11` (Little Cores), `vproc12` (Big Cores), `vgpu` (Mali-G57), `vsram_proc11`, `vsram_proc12`, `vsram_gpu`, dan `vcore`.
- **Dynamic Voltage Interception (`regulator_set_voltage`)**: Mencegat penulisan voltase CPU/GPU dan menerapkan offset undervolt negatif yang aman (`-12.5 mV`, `-25.0 mV`, atau `-37.5 mV`), menurunkan suhu chipset 4°C–8°C secara instan tanpa mengorbankan frekuensi.
- **GPU Undervolt Engine (`ged_dvfs_vcore`)**: Mengoptimalkan kurva daya dinamis pada seluruh 49 level frekuensi GPU Mali-G57 (300 MHz s/d 950 MHz).
- **OPP Latency Elimination (`dev_pm_opp_set_rate`)**: Mencegah penurunan frekuensi (*downclocking*) agresif saat beban gaming aktif, menjaga framerate tetap konsisten.
- **Hardware Safety Floors**: Dilengkapi batas bawah voltase mutlak (CPU minimal `700 mV`, GPU minimal `550 mV`) untuk menjamin 100% bebas *freezing* atau *kernel panic*.
- **Runtime Reconfiguration (`KPM_CTL0`)**: Mendukung pengubahan profil voltase secara dinamis dari userspace tanpa memerlukan reboot ponsel (`reset`, `uv=-12.5`, `uv=-25`, `uv=-37.5`).

### 2. Biner Kompilasi NDK Standalone (`build_kpm.ps1`)
- Menghasilkan biner relocatable ELF mandiri: `native/kpm/lynx_oc_uv/build/lynx_oc_uv.kpm` (~7.6 KB).

---

# Lynx Universal [TPCB Thermal Unthrottle KernelPatch Module] 7.0.0-RC53
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC53** (Lynx Kernel Manager v3.1.14): **Implementasi KernelPatch Module (KPM) Lynx TPCB Thermal Unthrottle: Ring-0 Kernel Inline Hooking untuk Membongkar Pembatasan Suhu Motherboard (TPCB 45°C) pada Pengisian Daya Cepat MediaTek / Transsion (Helio G96 / MTK DV2 Algorithm), Integrasi Toolchain LLVM Clang aarch64, Guardrail Keselamatan Darurat 52°C, dan Pemuatan Otomatis via APatch**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC53)

### 1. Lynx TPCB Thermal Unthrottle KPM (`lynx_thermal.c`)
- **Penyelesaian Simbol Runtime (`kallsyms_lookup_name_by_suffix`)**: Menemukan fungsi evaluasi termal kernel `__dv2_check_thermal_level` dan `dv2_check_thermal_level` secara dinamis di RAM kernel tanpa memerlukan full kernel source code OEM.
- **Ring-0 Inline Hooking (`hook_wrap3`)**: Memasang inline hook pada fungsi `__dv2_check_thermal_level` untuk mencegat penurunan status termal ke Level 7 (1.500 mA input) saat PCB mencapai 45°C.
- **Override Arus Penuh ke Level 0**: Mengembalikan nilai status termal `args->ret = 0` (Level 0 / Normal Unthrottled) selama suhu PCB berada dalam batas operasional aman (< 52°C), memungkinkan arus pengisian 3.3A–4.0A mengalir bebas ke Direct Pump RT9759 (2:1).
- **Hard Safety Guardrail (`HARD_MAX_SAFE_PCB_TEMP 52°C`)**: Jika suhu motherboard fisik menyentuh 52°C, modul secara otomatis membatalkan override dan mengembalikan kendali ke proteksi pabrikan untuk menjaga keselamatan fisik sirkuit.

### 2. Toolchain Kompilasi Mandiri (`build_kpm.ps1`)
- Menyediakan skrip kompilasi otomatis berbasis Android NDK Clang (`aarch64-linux-android`) yang menghasilkan biner relocatable ELF standalone: `native/kpm/lynx_thermal/build/lynx_thermal.kpm` (~5.5 KB).
- Menghilangkan ketergantungan pada kernel tree penuh atau penyesuaian string vermagic berkat dukungan arsitektur KernelPatch / APatch.

---

# Lynx Universal [Universal Dynamic Charger Topology Scanner & Deep Kernel Sysfs Crawler] 7.0.0-RC52
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC52** (Lynx Kernel Manager v3.1.13): **Implementasi Universal Dynamic Charger Topology Scanner & Deep Kernel Sysfs Crawler: Deteksi Otomatis Seluruh IC Pengisi Daya (Direct Charge Pump, Primary Switching Buck, dan OEM Controllers) via Kernel Bus Inspection (/sys/bus/i2c/drivers, /sys/bus/platform/drivers), Penelusuran Dinamis Node Pengisian Daya (/sys/class/power_supply/*), dan Pembongkaran Batas Arus/Termal Tanpa Hardcoding di Seluruh Perangkat Android**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC52)

### 1. Universal Dynamic Charger Topology Scanner (`scan_charging_hardware_chips`)
- **Pemeriksaan Bus Driver Kernel Fisik**: Memindai direktori kernel bus driver (`/sys/bus/i2c/drivers/` dan `/sys/bus/platform/drivers/`) serta class `/sys/class/power_supply/` secara langsung untuk mengidentifikasi seluruh chip fisik charging yang terpasang di motherboard:
  - **Direct Charge Pumps (2:1 & 4:1 Switched Capacitor)**: Richtek RT9759, Qualcomm SMB1390/1396/1398/1395, Lion Semi LN8000/LN8282 (Xiaomi 67W/120W), Southchip SC8551/8547/8571 (Xiaomi/Vivo/Honor), Texas Instruments BQ25970/BQ25980, NXP PCA9468, NuVolta NU1619, Halo Micro HL7132.
  - **Primary Switching Buck Converters**: Richtek RT9471/RT9490, MediaTek MT6370/MT6360/MT6375 PMU Buck, Maxim MAX77759/MAX77705/MAX77958 (Google Pixel & Samsung), Texas Instruments BQ25890/BQ25790, Qualcomm SMB1351/1355/1381 & PM8150B/PM8350B/PM7250B Buck, Samsung Shannon S2MU106/S2MU004 PMIC.
  - **Vendor Controllers**: Transsion Dual-Engine (`tran_battery`, `pca_mtk_chg`, `pca_dv2_algo`), OPPO/Realme SuperVOOC Engine (`oplus_chg`), Google Pixel Battery Controller, Samsung SEC Battery Controller, Qualcomm Battery Subsystem.
- **Formulasi Topologi Terpadu (`DiscoveredChargerTopology`)**: Menyajikan ringkasan hardware akurat secara dinamis, contoh: `Direct Charge Pump (RT9759 2:1) + Switching Buck Converter (RT9471)` pada Infinix/Tecno, atau `Lion Semi LN8000 Direct Pump + Qualcomm PM8150B Buck` pada Xiaomi.

### 2. Deep Kernel Sysfs Crawler (`crawl_dynamic_power_supply_nodes`)
- **Penelusuran Mandiri Tanpa Ketergantungan Path Statis**: Menelusuri seluruh subdirektori `/sys/class/power_supply/*/` (`battery`, `usb`, `ac`, `main`, `bms`, `charger`, `parallel`, `cp-standalone`, `smb1390`, dll.) untuk mendeteksi seluruh atribut kontrol pengisian daya yang diekspos oleh kernel vendor.
- **Spektrum Penguncian & Pembongkaran Arus Menyeluruh**:
  - Pada **Hyper Mode**: Secara dinamis membongkar batas atas seluruh node pembatas arus yang ditemukan (`constant_charge_current_max`, `constant_charge_current`, `current_max`, `input_current_limit`, `hw_current_max`) ke nilai puncak perangkat, serta mengaktifkan toggle boost (`fastcharge_mode`, `boost_current`, `turbo_power`).
  - Pada **Bypass Mode**: Secara otomatis mengunci seluruh node pengisian daya yang terdeteksi ke nilai 0 mA dengan proteksi izin 0444, memutus arus ke sel baterai secara mutlak pada perangkat apa pun.
  - Pada **Regulated Mode**: Menuliskan limit arus yang diminta pengguna ke seluruh node yang ditemukan secara atomik.

### 3. Perintah Diagnostik CLI Baru (`lynxd charging scan`)
- Menambahkan subperintah `lynxd charging scan` (atau `lynxd charging topology`) untuk memeriksa ringkasan hardware, primary buck converter, direct charge pump, vendor engine, dan daftar lengkap node sysfs dinamis yang berhasil dipindai kernel secara real-time.
- Memperbarui format telemetri JSON (`lynxd charging status`) dengan menambahkan atribut `"detected_hardware_chips"` dan `"dynamic_scanned_nodes_count"`.

---

# Lynx Universal [Anti-Spoofing Hardware Ground Truth & Cross-Platform Integrity Architecture] 7.0.0-RC51
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC51** (Lynx Kernel Manager v3.1.12): **Implementasi Penuh Protokol Anti-Spoofing Hardware Ground Truth: Kekebalan Mutlak Terhadap Modul Device Faker / Game Unlocker 120 FPS / MagiskHide Props Config / Play Integrity Fix Melalui Verifikasi Driver Fisik Kernel Linux & DTB Sysfs Nodes, Deteksi Otomatis Anomali Props, dan Penyajian Status Keaslian Hardware pada Seluruh Antarmuka & Native Daemon**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC51)

### 1. Protokol Anti-Spoofing Hardware Ground Truth (Tingkat 1 - Otoritas Mutlak)
- **Kekebalan Mutlak Terhadap Manipulasi User-Space**: Modul pengubah props di Android (Game Unlocker 90/120 FPS, Play Integrity Fix, MagiskHide Props Config, GLTools, Device Faker, atau Custom ROM/GSI) yang memanipulasi `ro.product.manufacturer`, `ro.product.model`, dan `ro.product.brand` **tidak akan pernah bisa memalsukan driver fisik kernel Linux** maupun *Device Tree Blob (DTB)* yang dimuat saat cold-boot.
- **Hierarki Deteksi Hardware Multi-Tier (`detect_charging_platform`)**:
  - **Tier 1 (Ground Truth Fisik)**:
    - Transsion (Infinix/Tecno/Itel): Keberadaan node driver `/sys/devices/platform/odm/odm:tran_battery`, `/sys/devices/platform/tran_battery`, `/sys/bus/i2c/drivers/rt9759`, atau `/sys/devices/platform/charger/BN_TestMode`. Jika node ini terdeteksi, arsitektur hardware **100% dipastikan Transsion**, mengabaikan nilai `getprop` yang dipalsukan ke Xiaomi/ASUS/Google Pixel.
    - Xiaomi (Xiaomi/Redmi/POCO): Keberadaan node driver `/sys/class/power_supply/battery/fastcharge_mode`, `/sys/class/thermal/thermal_message`, `/sys/class/power_supply/battery/turbo_power`, `/sys/bus/i2c/drivers/ln8000`, atau `/sys/bus/i2c/drivers/sc8551`.
    - OPPO / Realme / OnePlus: Keberadaan `/sys/class/power_supply/battery/vooc_charging` atau `/sys/class/oplus_chg`.
    - Samsung: Keberadaan `/sys/class/power_supply/sec-battery` atau `/sys/class/sec/sec-battery`.
    - Google Pixel: Keberadaan `/sys/devices/platform/google,battery` atau `/sys/bus/i2c/drivers/max77759`.
    - Qualcomm Snapdragon Generic: Keberadaan `/sys/class/qcom-battery`, `/sys/class/power_supply/smb1390`, atau `/sys/class/power_supply/smb1355`.
  - **Tier 2 (Advisory Fallback)**: `ro.product.manufacturer` dan `ro.product.brand` hanya dikonsultasikan jika seluruh node kernel fisik Tier 1 tidak ditemukan (perangkat generik tertutup).
- **Deteksi Otomatis & Peringatan Anomali Props (`is_props_spoofed`)**:
  - Jika perangkat keras fisik terverifikasi sebagai **Infinix/Tecno (RT9759)**, namun props melaporkan **Xiaomi (Redmi K70 Pro)**, **ASUS (ROG Phone)**, atau **Google Pixel**: sistem mencatat status spoofing aktif, mengabaikan props palsu, dan tetap mengeksekusi direct pump RT9759 secara aman.
  - Jika perangkat keras fisik terverifikasi sebagai **Xiaomi (Snapdragon/Qualcomm)**, namun props dimanipulasi: sistem **dilarang keras** mengeksekusi perintah khusus Transsion (`BN_TestMode`, `odm:tran_battery/Charging_CallState`), melindungi perangkat dari error kernel.

### 2. Integrasi Telemetri & Tampilan Antarmuka (Lynx Companion v3.1.12)
- **Indikator Perlindungan Anti-Spoof pada Hero Card**: Jika modul spoofer aktif, kartu pengisian daya secara elegan menampilkan badge `[🛡️ Anti-Spoof]` di samping daya watt.
- **Seksi Verifikasi Hardware Ground Truth pada Modal Detail**: Menambahkan seksi *"VERIFIKASI GROUND TRUTH HARDWARE"* pada `BatteryDetailBottomSheet`, menampilkan platform fisik kernel riil, status deteksi SoC Spoofer, serta integritas brand props.
- **Penyelarasan Mutlak Status Protokol & IC**: Protokol pengisian daya dan identitas IC driver dijamin selalu akurat mencerminkan komponen fisik yang terpasang di motherboard tanpa risiko tertukar akibat spoofing identitas perangkat.

---

# Lynx Universal [Universal Multi-OEM Charging Protocol & Cross-Brand Telemetry Architecture] 7.0.0-RC50
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC50** (Lynx Kernel Manager v3.1.11): **Implementasi Penuh Multi-OEM Brand-Awareness & Eliminasi Kebocoran Label Transsion pada Perangkat Non-Transsion (Xiaomi, Redmi, POCO, Samsung, OPPO, OnePlus, Realme, dan Google Pixel): Resolusi Akurat IC Daya (Qualcomm SMB1390/PMIC vs RT9759), Isolasi Ketat Protokol Cepat Sesuai Manufaktur Riil, dan Sanitasi Otomatis Antarmuka Pengguna**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC50)

### 1. Multi-OEM Brand-Awareness pada Native Daemon (lynxd)
- **Otentikasi Brand Hardware Real-Time**: `lynxd` kini menginspeksi identitas manufaktur asli (`ro.product.brand` dan `ro.product.manufacturer`) secara langsung saat mengevaluasi status pengisian daya.
- **Isolasi IC Pengisi Daya (`active_ic`)**: Menghilangkan kesalahan di mana perangkat Xiaomi/Qualcomm yang mengisi daya pada 9V salah terdeteksi sebagai `RT9759 2:1 Charge Pump`. Perangkat non-Transsion kini secara tepat dilaporkan sebagai `Qualcomm SMB1390 Dual-Pump`, `Xiaomi Quick Charge PMIC`, `Qualcomm PMIC Buck`, atau `Samsung PMIC Buck`.
- **Resolusi Protokol Sesuai Manufaktur**: Protokol Transsion (`Transsion Super Charge`) kini **100% terkunci hanya untuk perangkat Infinix, Tecno, dan Itel**. Jika Lynx berjalan di perangkat Xiaomi, protokol akan dilaporkan sebagai `Xiaomi TurboCharge` / `Xiaomi HyperCharge` / `Qualcomm QC`, pada Samsung sebagai `Samsung Super Fast Charging`, dan pada OPPO/Realme sebagai `SuperVOOC / Dart`.

### 2. Sanitasi & Penyelarasan Antarmuka Aplikasi (Lynx Companion v3.1.11)
- **Brand Guard pada Dashboard Hero Card**: `ChargingHeroDisplayCard`, `LynxBatteryTelemetryRepository`, dan `LynxTelemetryMapper` dilengkapi filter manufaktur berlapis (`isTranssionBrand`, `isXiaomiBrand`, `isSamsungBrand`, `isOppoRealmeBrand`).
- **Pembersihan Otomatis String Asing**: Mencegah teks bertuliskan "Transsion" muncul di ponsel Xiaomi, Redmi, POCO, atau Samsung dalam kondisi apa pun, baik saat initial handshake, status kalkulasi, maupun fallback adaptor standar.

---

# Lynx Universal [Dynamic Wattage Resolution & Hardware Charging Limit Decoupling Architecture] 7.0.0-RC49
Released on: 2026-10-15
> **Lynx Universal v7.0.0-RC49** (Lynx Kernel Manager v3.1.10): **Audit Arsitektur Pengisian Daya Silikon & Eliminasi Mutlak Hardcoded 33W: Penyelarasan Negosiasi Daya Dinamis (33W, 45W, 68W+), Pemulihan Preservasi Session Baseline `pdc_max_watt`, dan Resolusi Otomatis Protokol Transsion Super Charge pada Seluruh Antarmuka & Daemon**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC49)

### 1. Eliminasi Total Hardcoded 33W pada Daemon & Skrip Pengontrol
- **Pemulihan Baseline Preservasi (`pdc_max_watt`)**: Menghapus penulisan statis `"33"` pada `DISCONNECT_CHARGING_RESETS` dan `apply_standard_mode()` di `native/lynxd`. Sistem kini mempertahankan nilai baseline asli perangkat (`CHARGING_SESSION_NODES`) saat kabel dicabut atau kembali ke Standard Mode, mencegah pemangkasan daya tidak disengaja pada perangkat berkemampuan 45W/68W/120W+.
- **Penyelarasan Dinamis Shell Fallback (`Charging-Controller.sh`)**: Mengintegrasikan pencatatan state `/dev/lynx_orig_pdc_watt` sebelum penguncian Mode Hyper 120W, menjamin pemulihan akurat ke nilai bawaan pabrik saat disconnect tanpa memaksakan nilai 33.

### 2. Resolusi Protokol & Wattage Adaptif pada Antarmuka Aplikasi (Lynx Companion v3.1.10)
- **Pelabelan Daya Real-Time Adaptif**: Memperbarui algoritma pemetaan protokol pengisian cepat (`ChargingHeroDisplayCard`, `LynxBatteryTelemetryRepository`, dan `LynxTelemetryMapper`) agar mengkalkulasi daya nyata berdasarkan tegangan dan arus listrik:
  - $\ge 55\text{W}$ -> `Transsion 68W (PE+)`
  - $\ge 38\text{W}$ -> `Transsion 45W (PE+)`
  - $\ge 22\text{W}$ -> `Transsion 33W (PE+)`
  - $\ge 12\text{W}$ -> `Transsion 18W (PE+)`
  - Tegangan tinggi awal / idle -> `Transsion Super Charge (PE+)` (nama resmi yang elegan dan netral tanpa memaksakan angka 33W saat terhubung ke adaptor 45W/68W).
- **Eliminasi Fallback Statis**: Menghapus seluruh residu string `"Transsion 33W (PE+)"` statis pada kartu dashboard banner.

---

# Lynx Universal [Unconstrained Hyper Charging & Full Hardware Thermal Bypass Architecture] 7.0.0-RC46
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC46**: **Implementasi Penuh Unconstrained Hyper Charging Mode Tanpa Pembatasan Suhu: Eliminasi Mutlak Software JEITA (`sw_jeita = 0` locked), Penguncian BCCT/ABCCT Thermal Throttling ke 0, Bypass Otomatis Emergency Thermal & Night Sleep Guards, Uncap Wattage 120W, serta Pendorongan Arus Maksimum 12,000 mA pada MediaTek & Qualcomm**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC46)

### 1. Unconstrained Hyper Charging Mode (Full Thermal Bypass)
- **Bypass Mutlak Software JEITA**: Mematikan dan mengunci `sw_jeita` ke `0` (`0444` permission lock) pada Mode Hyper sehingga kernel MediaTek tidak memangkas arus pengisian saat suhu sel atau SoC meningkat.
- **Bypass BCCT / ABCCT Cooling Devices**: Menonaktifkan dan mengunci seluruh cooling devices pengisian daya (`mtk-cl-bcct00/01/02` dan `abcct`) ke `0` secara atomik via `write_node_lock`.
- **Eliminasi Emergency Guard Throttling pada Hyper Mode**: Mengecualikan Mode Hyper dari pemangkasan arus darurat 750 mA (`emergency_temp_guard`) dan pembatasan arus malam hari 1500 mA (`night_sleep_guard`), memberikan prioritas absolut kepada kecepatan penuh sesuai perintah pengguna.
- **Uncap Wattage & Register Arus Puncak**: Membuka `pdc_max_watt = 120` (unconstrained USB-PD / Pump Express 120W), serta mendorong batas arus hardware register hingga 12,000 mA (`sc_ibat_limit = 12000`, `input_current = 33170/max`, `direct_charging = 1`, `restrict_cur = 12000`, `thermal_input_current_limit = -1`).
- **Restorasi Otomatis saat Disconnect & Mode Standard**: Seluruh hak akses (`0666`), proteksi JEITA (`sw_jeita = 1`), dan kontrol kernel OEM dipulihkan secara aman saat kabel dicabut atau saat beralih ke Mode Standard.

---

# Lynx Universal [Universal Zero-Latency Controls & Universal Compact Toast HUD Architecture] 7.0.0-RC45
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC45** (Lynx Kernel Manager v3.1.7): **Ekspansi Menyeluruh Arsitektur Zero-Latency dan Feedback Kompak Elegan ke Seluruh Kontrol Aplikasi: Eliminasi Total Material Snackbar Menjadi Universal Toast HUD, Transisi Warna Halus 150 ms pada Seluruh Preset Profil Per Halaman (CPU, GPU, Dashboard, Profil Grid), serta Optimasi Respons Instan LynxSwitch**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC45)

### 1. Universal Compact Toast HUD (Penghapusan Total Material 3 Snackbar)
- **Eliminasi Total Snackbar Lebar**: Menghapus seluruh komponen `SnackbarHost` Material 3 lama yang lebar dan menutupi dock navigasi bawah.
- **Universal Event Ingestion**: `successMessage` dan `errorMessage` di seluruh sub-halaman aplikasi (RAM Cleaner, GPU driver reload, thermal profile, governor, dan backup/restore) kini secara otomatis dialirkan ke Universal Toast HUD (`Jewel Dynamic Island` atau `Jewel Bottom Capsule` sesuai preferensi pengguna).
- **Penanganan Teks Adaptif & Safe Max Width**: Desain Toast HUD diperkuat dengan batas lebar maksimum `240.dp`, teks ber-ellipsis rapi, pendaran status multi-tipe (`MODE`, `PRESET`, `SUCCESS`, `ERROR`, `INFO`, `WARNING`), serta resolusi ikon dinamis.
- **Header Morph Fallback**: Jika pengguna memilih model *In-Header Seamless Morpher*, notifikasi aksi tetap dimunculkan sebagai floating jewel pill agar pesan sistem penting tidak terlewat.

### 2. Zero-Latency Preset Profil Per Halaman (Animasi Warna Halus 150 ms)
- **Sub-Halaman CPU (`CpuTuningCards`)**: Tombol preset profil CPU (Hemat Daya, Seimbang, Performa, Ekstrem) kini bereaksi instan (0 ms) dengan transisi animasi halus `animateColorAsState(150 ms)` pada background dan border saat disentuh.
- **Sub-Halaman GPU (`GpuProfilesAndHardwareCard`)**: Tombol preset profil GPU (Battery Saver, Balanced, Esports, Ekstrem) merespon seketika tanpa jeda, menampilkan transisi warna dan border 150 ms yang mulus.
- **Katalog Profil Kernel (`ProfileGrid`)**: Kartu profil kernel di halaman tuning kini memiliki transisi warna dinamis 150 ms dan feedback visual seketika.
- **Penggantian Native Toast**: Mengganti pemanggilan `android.widget.Toast.makeText` di sub-halaman GPU dengan Universal Toast HUD yang konsisten dan elegan.

### 3. Peningkatan Responsivitas Kontrol Sub-Halaman (`LynxSwitch`)
- **Pangkas Lockout & Debounce**: Memangkas lockout sinkronisasi eksternal dari 3500 ms menjadi 600 ms, serta memangkas debounce klik keras dari 300 ms menjadi 50 ms.
- **0 ms Touch Feeling**: Toggle switch di seluruh sub-halaman kini memberikan sensasi sentuhan langsung tanpa jeda atau jitter, tetap terlindungi dari bouncing ganda.

---

# Lynx Universal [Zero-Latency Mode Switching & Universal Control Reconciliation Architecture] 7.0.0-RC44
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC44** (Lynx Kernel Manager v3.1.6): **Implementasi Arsitektur Zero-Latency Mode Switching Berkecepatan Tinggi (0 ms Touch Response), Pengurangan Forking Root Shell Berantai Menjadi Single Batch Invocation, Eliminasi Blocking Cascade Jobs, serta Integrasi Two-Phase State Reconciliation dengan Automatic Hardware Rollback Guard**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC44)

### 1. Zero-Latency Mode Switching (0 ms Touch Recomposition)
- **Eliminasi Total Gap & Freeze**: Tombol mode di Header dan Sub-Halaman Profil kini menerapkan *Instant Optimistic UI Update*, berpindah sorotan dan warna aksen dalam 1 frame (<16 ms pada 60/120 Hz) seketika jari menyentuh tombol bersamaan dengan Toast HUD.
- **Transisi Visual Halus**: Diintegrasikan `animateColorAsState` berdurasi 150 ms pada background dan border tombol mode di Header untuk pengalaman visual yang sangat fluid dan premium.

### 2. Konsolidasi Root Shell Pipeline (Single Batch Invocation)
- **Pangkas Forking `su` Berulang**: Mengonsolidasikan 5 instruksi shell terpisah pada `setProfile` (`mkdir`, file write `active_profile`, `setprop lynx.mode`, dan penulisan state) menjadi satu batch shell script atomik (<35 ms total).
- **Hapus Blocking Cascade**: Menghilangkan blocking synchronous `.join()` (`cpuProfileJob?.join()` dan `gpuProfileJob?.join()`) yang sebelumnya menahan alur pergantian profil hingga 1.5–3 detik. Seluruh sinkronisasi sekunder dijalankan secara asinkron di latar belakang (`Dispatchers.IO`).

### 3. Two-Phase State Reconciliation & Automatic Rollback
- **Keamanan Hardware Berlapis**: Memanfaatkan mesin native `lynxd` yang berkecepatan 20.56 ms sebagai *Single Source of Truth* untuk penulisan 29 sysfs nodes.
- **Automatic Rollback Guard**: Jika eksekusi gagal atau izin root terganggu, UI secara otomatis mengembalikan (*rollback*) status tombol ke profil sebelumnya disertai pesan error yang transparan.
- **Hardware Ground Truth Telemetry**: Telemetri fisik sysfs disinkronkan secara asinkron di latar belakang sehingga nilai MHz, governor, dan daya yang tampil di layar selalu akurat 100% terhadap silikon hardware.

---

# Lynx Universal [Ultra-Compact Toast HUD Feedback & In-Header Morpher Architecture] 7.0.0-RC43
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC43** (Lynx Kernel Manager v3.1.5): **Integrasi Sistem Feedback Pergantian Mode Kernel Menjadi Toast HUD Ultra-Compact (26–28 dp) dengan 3 Model Pilihan (Jewel Dynamic Island, In-Header Seamless Morpher, dan Jewel Bottom Capsule), Penghapusan Snackbar Lebar yang Mengganggu, serta Penempatan Kartu Konfigurasi Interaktif di Sub-Halaman Profil Performa Kernel**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC43)

### 1. Sistem Toast HUD Ultra-Compact (26–28 dp Single-Line)
- **Eliminasi Total Snackbar Kaku**: Menghapus penggunaan Material 3 Snackbar lama yang lebar membentang layar dengan tombol "OK", menggantikannya dengan kapsul melayang (*pill HUD*) ultra-kompak yang adaptif (*hug-content width*).
- **Estetika Obsidian Glassmorphism**: Latar belakang `#0A0E15` (94% opacity + blur) dengan border hairline 0.85 dp berpendar lembut (*ambient glow*) sesuai warna profil aktif:
  - 🌿 *Hemat*: Pendaran Hijau Neon (`#00E676`)
  - ⚖️ *Seimbang*: Pendaran Biru Cyber (`#00A3FF`)
  - 🚀 *Performa*: Pendaran Oranye Amber (`#FF9100`)
  - 🔥 *Extreme*: Pendaran Merah Crimson (`#FF3D00`)
- **Komposisi Jewel Minimalis**: Menggabungkan dot pendaran permata 5 dp + mikro ikon mode + nama mode bold + chip status `AKTIF`.
- **Zero Friction**: Auto-dismiss dalam 1.8 detik dan mendukung gestur tap-to-dismiss instan.

### 2. 3 Model Pilihan Feedback & Default Jewel Dynamic Island
- **Model 1: Jewel Dynamic Island (Default)**: Melayang di bagian atas layar tepat di bawah status bar (28 dp). Sangat ergonomis karena searah dengan jari dan pandangan pengguna saat menekan tombol mode di Top Header.
- **Model 2: In-Header Seamless Morpher**: Subteks header `• Codename: Deity` bermutasi mulus menjadi `• Mode [Nama] Aktif` (0 dp overlap, 100% bebas tumpang tindih).
- **Model 3: Jewel Bottom Capsule**: Kapsul melayang di atas dock bawah (26 dp).
- **Dual-Morph Synchronization**: Saat Jewel Dynamic Island aktif, subteks header juga ikut bertransisi serentak menghasilkan feedback harmonis.

### 3. Kartu Konfigurasi Interaktif di Sub-Halaman Profil Performa Kernel (Opsi 1)
- **Penempatan Fungsional & Koheren**: Ditempatkan di sub-halaman *Profil Performa Kernel* (diakses via tab Tuning atau tombol `[ Kustom → ]` di header).
- **Pilihan Segmented Interaktif**: Menyediakan 3 kartu radio interaktif dengan indikator bawaan (*DEFAULT badge*).
- **Tombol Uji Langsung (Live Test)**: Memungkinkan pengguna menguji animasi Toast HUD terpilih secara instan di layar tanpa mengubah profil aktif.
- **Switch Sinkronisasi Header**: Kontrol penuh atas fitur dual-morphing header.

---

# Lynx Universal [Unified All-in-One Header & Integrated Mode Selector & Official App Icon Revamp] 7.0.0-RC42
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC42** (Lynx Kernel Manager v3.1.4): **Penggabungan Menyeluruh Top Header dan Mode Performa Kernel Menjadi Satu Komponen All-in-One yang Ultra-Kompak, Penyelarasan Sub-Header Status Menjadi "Codename: Deity", dan Integrasi Aset Ikon Aplikasi Resmi Lynx (Cyan Metallic Fold)**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC42)

### 1. Unified All-in-One Header & Mode Selector Terpadu
- **Penggabungan Dua Komponen Kunci**: Menyatukan Top Header dan pemilih Mode Performa Kernel (`QuickProfileSwitcherCard`) ke dalam satu kartu bento box all-in-one yang rapi dan proporsional.
- **Efisiensi Ruang Layar Signifikan**: Menghemat ruang vertikal hingga ~110 dp pada dashboard, sehingga kartu telemetri baterai, SoC clock, dan memori dapat langsung terlihat di area *first-fold* tanpa perlu scroll jauh.
- **Tata Letak Baris Ganda Simetris**:
  - *Baris 1*: Ikon resmi Lynx, judul `"Lynx Kernel"`, dan status `"Codename: Deity"` dengan dot indikator hijau aktif, berdampingan dengan aksi cepat palet tema dinamis (expandable via `AnimatedVisibility`) dan tombol `[ Kustom → ]`.
  - *Divider Halus*: Garis pembatas semi-transparan (`White` 5% alpha) pemisah zona identitas dan zona kontrol frekuensi.
  - *Baris 2*: 4-Way Mode Selector (`Hemat`, `Seimbang`, `Performa`, `Extreme`) dengan feedback glow interaktif, border aktif, dan subteks profil yang presisi.

### 2. Penyelarasan Status Sub-Header ("Codename: Deity")
- **Standardisasi Identitas Modul**: Mengubah teks sub-header status dari sebelumnya `"Lynx Deity Active"` menjadi **`"Codename: Deity"`** dengan dot indikator hijau bersinar halus (`EmeraldGreen`), mempertegas arsitektur inti modul hybrid Deity secara profesional.

### 3. Integrasi Ikon Aplikasi Resmi Lynx (Cyan Metallic Fold)
- **Aset Visual Generasi Baru**: Mengadopsi ikon resmi bernuansa *Cyan Metallic Fold* (`ic_lynx_logo.png`) dengan palet kromium futuristik dan aksen cyan yang tajam.
- **Dukungan Penuh Multi-DPI & Adaptive Icons**:
  - Menghasilkan aset mipmap berkualitas tinggi di semua densitas: `mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, dan `xxxhdpi` (`ic_launcher.png` dan `ic_launcher_round.png`).
  - Mengonfigurasi Adaptive Vector Icon XML (`mipmap-anydpi-v26/ic_launcher.xml` dan `ic_launcher_round.xml`) dengan background solid OLED `#0B0F17` dan foreground terpusat 108dp.

---

# Lynx Universal [Dashboard Harmonization & Telemetry Gauges Symmetry] 7.0.0-RC41
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC41** (Lynx Kernel Manager v3.1.3): **Harmonisasi Total Antarmuka Dashboard, Eliminasi Redundansi Badge Daya & Dial Mode saat Discharging, Simetri Tampilan Load GPU Mirroring CPU, serta Penyelarasan Bahasa Indonesia Baku pada Profil Performa Kernel**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC41)

### 1. Eliminasi Redundansi Status Daya & Baterai
- **Penghapusan Badge Pojok Kanan Atas Total**: Menghilangkan seluruh badge pill di pojok kanan atas kartu Status Daya (`BATERAI` / `CHARGING` / `BYPASS`) untuk tampilan yang lebih bersih, tenang, dan bebas dari pengulangan kata yang tidak perlu.
- **Pembersihan Dial Lingkaran saat Discharging**: Saat perangkat berjalan menggunakan daya baterai mandiri, mode pill di dalam dial (`⚡ STANDBY`) otomatis disembunyikan sehingga dial hanya memfokuskan tampilan persentase baterai yang elegan. Mode pill hanya ditampilkan saat kabel pengisi daya terhubung aktif (`⚡ HYPER`, `⚡ STANDARD`, `⚡ COOL`, `⚡ BYPASS`).
- **Penyelarasan Banner Protokol Daya**: Menyelaraskan teks banner saat unplugged menjadi `"Discharging"` dengan subteks `"Menggunakan daya baterai"`, menghilangkan duplikasi frase "Baterai Internal" yang bertumpuk.

### 2. Simetri Telemetri & Clock Hardware (GPU Load Mirroring CPU Engine)
- **Judul Kartu Berbahasa Indonesia Baku**: Mengubah judul kartu dari `"Live Telemetry & Hardware Gauges"` menjadi **`"Telemetri & Clock Hardware"`**.
- **Pelabelan Domain Presisi**: Mengganti label `"GPU Engine"` dan `"CPU Engine"` menjadi **`"GPU (Grafis)"`** dan **`"CPU (Prosesor)"`** untuk menghindari kebingungan asosiasi dengan 3D game engine.
- **Simetri Tampilan Beban Dinamis Real-Time**:
  - Mengintegrasikan pemetaan beban GPU (`gpuLoadPercent` / `gpuBusy`) ke dalam kartu telemetri bento box secara simetris dengan CPU.
  - Saat aktif: Menampilkan beban persentase real-time beserta arsitektur hardware (contoh: `Load 13% • Mali` / `Load 32% • 8 Cores`).
  - Saat siaga: Menampilkan status manajemen frekuensi dinamis yang bersih (contoh: `Dynamic DVFS • Mali` / `Dynamic EAS • 8 Cores`) dengan perlindungan `TextOverflow.Ellipsis`.

### 3. Konsistensi Penamaan Profil Performa Kernel ("Seimbang")
- **Penyelarasan Bahasa Baku**: Menggantikan istilah campur aduk `"Balance"` menjadi **`"Seimbang"`** di seluruh aplikasi (`QuickProfileSwitcherCard`, header badge status bar `StatusBadge`, `MainDashboard`, `TuningProfilesCategory`, dan `strings.xml`).
- Menyelaraskan 4 profil performa kernel inti ke dalam bahasa Indonesia baku yang serasi: **`Hemat`**, **`Seimbang`**, **`Performa`**, dan **`Extreme`**.

# Lynx Universal [Luxury Battery Energy Ring & Quick Charging Mode Selector Modal] 7.0.0-RC40
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC40** (Lynx Kernel Manager v3.1.2): **Revamp Total Animasi Circle Dial Baterai Menjadi Luxury EV Energy Ring dengan Leading Pulse Bead, Penambahan Quick Charging Mode Selector Modal Langsung dari Dashboard, dan Penyingkatan Seluruh Deskripsi Daya Bebas Truncation**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC40)

### 1. Luxury EV / Cyberpunk Energy Ring Dial Revamp
- **Desain Mewah Tanpa Gimmick**: Menggantikan sweep gradient lama dengan sistem rendering multi-layer presisi tinggi:
  - *Recessed Metallic Track Groove*: Alur sirkular gelap (`#0F141D`) dengan hairline guide ring luar dan dalam.
  - *Precision Quadrant Ticks*: Aksen notch kuadran pada posisi 12, 3, 6, dan 9 tepat untuk estetika instrumen otomotif mewah.
  - *Soft Breathing Halo*: Lapisan glow halus berdenyut lembut (*smooth sine pulse*) di bawah busur energi aktif.
  - *Leading Energy Bead / Tip Indicator*: Partikulat energi bercahaya (aura lembut + inti titik putih laser) yang berputar tepat di ujung persentase baterai secara real-time.
  - *Inner Dial OLED Gradient*: Wajah dial bagian dalam dengan radial gradient halus dan border hairline elegan.

### 2. Quick Charging Mode Selector Modal (Clean OEM Infinix Hypercharge & Mi Turbo Charge Aesthetic)
- **Desain Bersih, Elegan & Bebas AI Slop**: Menghilangkan seluruh badge tag warna-warni yang berantakan (*rainbow clutter*) dan menyelaraskan seluruh tampilan overlay dengan bahasa desain OEM flagship:
  - Menggunakan satu aksen warna tema terpadu yang harmonis (*Single Cohesive Accent Theme*).
  - Mengadopsi indikator seleksi *OEM Radio Button* modern dengan glowing ring dan dot aktif di sisi kanan.
  - Kartu opsi berbasis Obsidian Dark (`#0F1219` / `#131722`) dengan kontras tipografi tinggi dan ikon perak monokromatik halus.
- **3 Pilihan Profil Pengisian Daya Terfokus**:
  1. *Mode Hyper*: Kecepatan pengisian maksimal dengan daya penuh (*unrestricted max hardware speed*).
  2. *Mode Standar*: Keseimbangan cerdas kecepatan dan suhu perangkat bawaan regulasi pabrikan.
  3. *Mode Sejuk*: Menjaga perangkat tetap dingin untuk keawetan baterai (*low-temp comfort*).
- **Akses Ergonomis & Instan**: Dapat dibuka langsung dengan mengetuk dial tengah atau pill status daya, diterapkan seketika ke hardware tanpa restart.

### 3. Penyingkatan Seluruh Deskripsi Daya Banner (Bebas Truncation)
- Menyingkat seluruh string deskripsi banner daya agar tidak lagi terpotong (*no text truncation / ellipsis*) pada semua rasio layar:
  - Baterai Internal: `"Menyuplai motherboard perangkat secara mandiri"` -> `"Daya mandiri aktif"`
  - Bypass Charging: `"Daya dialihkan langsung ke motherboard • 0 mA ke sel baterai"` -> `"Daya ke motherboard (0 mA)"`
  - Pengisian Daya: `"Daya masuk • X.X W"` / `"Daya terhubung"`
- Mengintegrasikan `TextOverflow.Ellipsis` dan `softWrap` pelindung untuk stabilitas tampilan sempurna.

### 4. Tombol Pembersih RAM Ultra-Kompak & Eliminasi Redundansi Persentase
- **Desain Ultra-Kompak Icon-Only**: Menggantikan tombol pill teks dengan *chip* aksi ringkas berukuran `24.dp` (`RoundedCornerShape(6.dp)`) murni ikon pembersih **`Icons.Default.DeleteSweep`**, menghasilkan jarak baris yang jauh lebih rapat, seimbang, dan konsisten dengan ritme vertikal kartu.
- **Eliminasi Redundansi Persentase**: Menghapus teks duplikat `"Penggunaan: XX%"` di baris bawah yang sebelumnya redundan dengan persentase di header atas, menggantinya dengan label domain `"Memori Fisik Utama"` sehingga tercipta simetri arsitektur sempurna dengan ZRAM Swap (`"Kompresi RAM Kernel"`).
- **Feedback Interaktif Real-Time**: Saat tombol ditekan, indikator putar `CircularProgressIndicator` (12.dp) berputar halus hingga proses pembebasan memori selesai seketika.

### 5. Penyelarasan Badge Header Mode Performa Kernel ("Kustom")
- **Penyesuaian Konteks Mode (Domain Relevance)**: Menggantikan label `"Katalog"` yang kurang relevan untuk pemilihan mode performa kernel menjadi **`"Kustom"`** (`[ Kustom → ]`), selaras dengan 4 preset bawaan vs profil kustom pengguna.
- **Harmoni Warna Visual**: Menyelaraskan border dan teks badge dengan aksen oranye kartu (`AccentOrange` 45% alpha) agar selaras dengan ikon speedometer dan tema Mode Performa Kernel.
- **Navigasi Langsung**: Tombol mengarahkan pengguna secara presisi ke sub-halaman editor profil kustom dan otomasi per-aplikasi di Tuning Engine.

---

# Lynx Universal [Quick High-Impact RAM Cleaner Button & Multi-Stage Memory Compaction] 7.0.0-RC39
Released on: 2026-10-14
> **Lynx Universal v7.0.0-RC39** (Lynx Kernel Manager v3.1.1): **Integrasi Tombol Pembersih RAM Cepat Berupa Icon di Samping Kanan Progress Bar RAM Fisik dengan Pembebasan Memori Multi-Stage Kernel (Sync, Drop Caches, Memory Defrag, ZRAM Compaction) yang Akurat dan Berdampak Nyata**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC39)

### 1. Tombol Pembersih RAM di Samping Kanan Progress Bar RAM Fisik
- **Penempatan Ergonomis & Presisi**: Menambahkan tombol aksi cepat berbentuk ikon sapu pembersih (`CleaningServices`) tepat di sebelah kanan progress bar RAM Fisik pada kartu **Alokasi Memori, ZRAM & Swap**.
- **Indikator Proses Dinamis**: Menampilkan spinner pembersihan (`CircularProgressIndicator`) halus saat eksekusi berlangsung dan kembali ke ikon semula seketika proses selesai.

### 2. Reklamasi Memori Kernel Multi-Stage Berdampak Nyata
- **Eksekusi Aman & Terkalibrasi**:
  1. `sync`: Melakukan commit dirty memory pages ke penyimpanan flash agar integritas berkas terjamin 100%.
  2. `echo 3 > /proc/sys/vm/drop_caches`: Membebaskan page cache, dentries, dan inode yang tidak lagi digunakan.
  3. `echo 1 > /proc/sys/vm/compact_memory`: Melakukan defragmentasi ruang halaman memori fisik kernel menjadi blok-blok besar (*high-order blocks*) untuk alokasi RAM instan tanpa lag.
  4. `echo 1 > /sys/block/zram0/compact`: Mengompaksi pool memori zsmalloc pada swap ZRAM.
- **Kalkulasi Delta Akurat**: Mengukur delta pembebasan memori sebelum dan sesudah eksekusi melalui pembacaan `/proc/meminfo` secara langsung, memperbarui telemetri secara real-time, dan memberikan notifikasi ringkas hasil pembersihan memori kepada pengguna.

---

# Lynx Universal [Dashboard Streamlining & Quick Profile Header Action & Label Polish] 7.0.0-RC38
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC38** (Lynx Kernel Manager v3.1.0): **Penyelarasan Label Baterai Dashboard ("Arus" & "Suhu Baterai"), Standardisasi Label Protokol Pengisian Daya Ringkas Anti-Truncation, Penghapusan Dot Indicator pada Mode Aktif, dan Desain Header Action Ringkas "Katalog" pada Mode Performa Kernel**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC38)

### 1. Penyelarasan & Penyempurnaan Label Telemetri Baterai Dashboard
- **"Arus Riil" -> "Arus"**: Mengganti label mini tile telemetri daya dari "Arus Riil" menjadi "Arus" untuk kesederhanaan dan kejelasan informasi.
- **"Suhu Sel" -> "Suhu Baterai"**: Mengganti label "Suhu Sel" menjadi "Suhu Baterai" agar lebih intuitif bagi pengguna umum.

### 2. Standardisasi Label Protokol Fast Charging Ringkas (Anti-Truncation)
- Memperpendek string protokol pengisian daya pada `ChargingHeroDisplayCard` dan `LynxBatteryTelemetryRepository` agar pas secara sempurna di badge/banner tanpa terpotong (*no text truncation / ellipsis*) pada berbagai rasio layar non-reguler:
  - `Transsion Flash Charge (PE+ Pump)` -> `Transsion Flash (PE+)`
  - `Qualcomm Quick Charge 4.0/5.0` -> `Qualcomm QC 4/5`
  - `Qualcomm Quick Charge 3.0` -> `Qualcomm QC 3.0`
  - `Qualcomm Quick Charge` -> `Qualcomm QC`
  - `USB Power Delivery (PD / PPS)` -> `USB-PD / PPS`
  - `USB Power Delivery (USB-PD)` -> `USB-PD`
  - `SuperVOOC / Dart Charge` -> `SuperVOOC / Dart`
  - `Xiaomi Turbo / HyperCharge` -> `Xiaomi TurboCharge`
  - `MediaTek Pump Express (PE+)` -> `MTK Pump Express`
  - `USB Komputer/Laptop (SDP/CDP)` -> `USB PC / Laptop`
  - `Adaptor USB Standar (DCP 5V/2A)` -> `Adaptor Standar (DCP)`

### 3. Quick Profile Switcher Card Compact Header Action & Polish
- **Penghapusan Dot Indicator**: Menghilangkan titik lingkaran (*dot indicator*) pada mode yang aktif/terpilih, memberikan tampilan tombol mode yang simetris, bersih, dan elegan.
- **Compact Header Action "Katalog"**: Memindahkan tombol "Katalog & Kustom" yang sebelumnya memakan ruang baris penuh (tinggi 44dp) ke slot header `LynxCard` (`action`) dengan chip ringkas `[ Katalog → ]`.
- **Penghematan Ruang Vertikal**: Mengurangi tinggi kartu secara signifikan dan menghapus status baris redundan sehingga tata letak Dashboard jauh lebih ringkas, hemat ruang, dan responsif.

---

# Lynx Universal [Dynamic Live Status Bar Mode Icons & Telemetry & Dashboard Cleanup] 7.0.0-RC37
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC37** (Lynx Kernel Manager v3.0.99): **Notifikasi Status Bar Lynx Mode Benar-Benar Live dengan Dynamic Vector Mode Icon Sesuai Mode Aktif, Telemetri Real-Time Baterai & Suhu Tanpa Overhead, Pemindahan Live Benchmark ke Sub-Halaman Game HUD, dan Pembersihan Redundansi Dashboard**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC37)

### 1. Dynamic Mode Icons & Live Telemetry pada Status Bar Notification
- **Icon Dinamis Status Bar (`setSmallIcon`)**:
  - `Extreme Mode`: Ikon Api / Flame (`ic_mode_extreme.xml`) dengan aksen warna merah menyala (`#FF3B30`).
  - `Performance Mode`: Ikon Petir / Lightning Bolt (`ic_mode_performance.xml`) dengan aksen warna oranye/amber (`#FF9500`).
  - `Balance Mode`: Ikon Yin-Yang Seimbang (`ic_mode_balance.xml`) dengan aksen warna biru cyber (`#007AFF`).
  - `Powersave Mode`: Ikon Daun / Eco Leaf (`ic_mode_powersave.xml`) dengan aksen warna hijau (`#34C759`).
  - `Auto (AI) Mode`: Ikon Chipset AI / Memory Core (`ic_mode_auto.xml`) dengan aksen warna ungu (`#AF52DE`).
- **Telemetri Suhu & Persentase Baterai Real-Time**:
  - Notifikasi memperbarui suhu (°C) dan daya baterai (%) secara periodik (setiap 3 detik saat layar aktif) menggunakan OS sticky intent tanpa shell fork (0.05ms, 0% CPU overhead).
  - Ticker telemetri otomatis tidur lelap saat layar mati (*Deep Sleep Shield*) guna menjamin CPU C-States optimal.
- **Pembaruan Seketika (0ms IPC)**:
  - Setiap pergantian mode dari Dashboard, Quick Settings Tile, Floating HUD, maupun deteksi game langsung memicu pembaruan notifikasi secara instan via singleton in-process hook.
  - Perbaikan bug baseline profil di mana sebelumnya mode manual `extreme` atau `performance` dipaksa kembali ke `balance`.

### 2. Relokasi Live Benchmark ke Sub-Halaman Floating Game HUD
- Kartu **Live Hardware Benchmark & Frame Pacing** dipindahkan dari Dashboard utama ke dalam Sub-Halaman **Floating Game HUD** (`GameHudSubscreen.kt`).
- Menyatukan seluruh instrumen pengujian performa game dan frametime jitter ke satu tempat yang relevan.

### 3. Pembersihan Redundansi Halaman Dashboard
- Kartu **Kesehatan Baterai** dihilangkan dari Dashboard utama untuk mencegah redundansi, karena analisis kesehatan baterai lengkap sudah tersedia di sub-halaman Baterai.
- Dashboard utama kini berfokus penuh pada 3 kartu esensial: **Hero Battery Card**, **Quick Profile Switcher**, dan **Live Thermal Zones Matrix**.

### 4. Zero-Overhead Fast-Path Execution & Eliminasi Broken-Pipe Latency
- **Direct In-Memory Caching Path `lynxd`**: Lokasi biner native Rust `lynxd` kini di-cache langsung di memori RAM (`cachedLynxdPath`), memangkas shell pre-check `[ -x ... ]` berulang kali (~15 ms) pada setiap pergantian profil.
- **Pembersihan `killall lynxd`**: Menghilangkan perintah `killall lynxd` pada penerapan profil rutin (`extreme`, `performance`, `balance`, `powersave`), menjamin perpindahan mode berlangsung instan tanpa gangguan sinyal kill.
- **Eliminasi Broken Pipe SIGPIPE pada Window Watcher**: Mengganti pipeline `dumpsys window | grep -m1` dengan query terarah `dumpsys window displays` dan in-memory pattern matching di Kotlin, melenyapkan 100% error SIGPIPE (Broken pipe) di `system_server` Android.

### 5. Pembersihan Berkas Usang & Modernisasi Packaging Modul
- **Pembersihan Total Obsolete APKs**: Menghapus `Toast.apk` (119 KB) dan file mentah debug lama `LynxCompanion.apk` (17.5 MB) dari root repositori.
- **Dynamic Installer Versioning**: `customize.sh` kini secara dinamis membaca versi modul dari `module.prop` untuk banner instalasi terminal, menggantikan teks statis lawas.
- **Pembaruan Packaging Flashable ZIP**: Skrip `package_module.sh` dan `package_module.ps1` kini memprioritaskan bundel APK release terkompresi R8 (`LynxKernelManager.apk`, 2.9 MB) dan membersihkan seluruh rujukan berkas usang sehingga ZIP bersih tanpa warning.

---

# Lynx Universal [UX Architecture Restructure: Dedicated Game HUD Subscreen & Unified Per-App Profiling Hub] 7.0.0-RC36
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC36** (Lynx Kernel Manager v3.0.98): **Restrukturisasi Total Information Architecture (IA) UX/UI: Relokasi Floating Game HUD & OSD ke Sub-Halaman Mandiri di Pusat Tuning, Penyatuan Tunggal Otomasi Profil Per-Aplikasi ke dalam Sub-Halaman Profil Performa Kernel, Dekompresi Visual Halaman Dashboard Menjadi Ringkas dan Berfokus Performa**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC36)

### 1. Relokasi Floating Game HUD & OSD ke Sub-Halaman Mandiri Tuning Hub
- **Latar Belakang**: Kartu Floating Game HUD sebelumnya memakan ruang vertikal masif (>350 dp) pada Dashboard utama karena memuat konfigurasi interaksi (Edge Drawer vs Floating Window), Pin Mini FPS, dan 6 preset gaya visual layout OSD.
- **Penyempurnaan Arsitektur**:
  - Kartu kontrol Game HUD dipindahkan secara menyeluruh ke sub-halaman mandiri baru di Pusat Tuning (`TuningCategory.HUD` - "Floating Game HUD").
  - Menghadirkan *Permanent Sticky Pinned Header* lengkap dengan navigasi kembali yang mulus, deskripsi telemetri, master sakelar, mode drawer/jendela, serta 6 preset visual OSD (RTSS Pillar, Top Nano-Ribbon, Dual-Block Esport, Quad-Tiles Modular, Steam Deck Banner, dan Ghost Text Frameless).
  - Dashboard utama kini bersih, responsif, dan ringan tanpa beban visual HUD.

### 2. Penyatuan Otomasi Profil Per-Aplikasi ke "Profil Performa Kernel"
- **Penyelarasan Domain Tingkat Tinggi**: Aturan profil per-aplikasi (`appProfileRules`) dipindahkan dari sub-halaman *Subsystem & Deep Tunables* langsung ke sub-halaman **Profil Performa Kernel** (`TuningCategory.PROFILES`).
- **Pengalaman Pengguna (*User Workflow*)**:
  - Di dalam satu sub-halaman yang sama, pengguna dapat melihat Katalog Profil Kernel (Definisi: Extreme, Performance, Balance, Powersave) dan sekaligus mengonfigurasi aturan aplikasi/game mana yang mengaktifkan profil tersebut (Penerapan).
  - Sub-halaman *Subsystem & Deep Tunables* kembali murni menangani parameter kernel mendalam (*deep sysfs, printk, SELinux, panic handlers*).

---

# Lynx Universal [Unified Silent Status Bar Notification & Redundancy Purge] 7.0.0-RC35
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC35** (Lynx Kernel Manager v3.0.99): **Penyatuan Tunggal Notifikasi Status Bar Hening (Single Silent Status Bar Notification), Eliminasi Total Redundansi Ganda (Modul & Aplikasi), Penghapusan Mutlak Pop-up Toast Pihak Ketiga (`bellavita.toast` & `Toast.apk` Purged), Serta Pengoptimalan Visual Ringan Berfokus Performa**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC35)

### 1. Eliminasi Mutlak Redundansi Notifikasi Ganda
- **Akar Masalah**: Sebelumnya pengguna menerima notifikasi ganda sekaligus dari modul (`cmd notification post` via root shell) dan dari aplikasi Lynx Companion (`LynxAppAutomationService`), ditambah pop-up toast dari APK pihak ketiga (`bellavita.toast`) yang mencuri fokus layar saat profil berganti.
- **Solusi**:
  - Seluruh pemanggilan `cmd notification post` pada biner native Rust `lynxd` (`lifecycle_hooks.rs`) dan skrip otomasi (`lynx_watcher.sh`) dimatikan total. Modul root bekerja secara senyap di level kernel/hardware tanpa menciptakan notifikasi shell liar.
  - Penataan ulang single-source of truth: Hanya tersisa **1 notifikasi status bar tunggal** yang dikelola rapi oleh aplikasi Lynx Companion.

### 2. Penghapusan Total Pop-up Toast Layar (`Toast.apk` Purged)
- `Toast.apk` (`bellavita.toast`) dihapus dari instalasi modul (`customize.sh`) dan di-uninstall dari perangkat.
- Tidak ada lagi pop-up toast yang menginterupsi layar sentuh saat membuka game atau beralih aplikasi, menjamin pengalaman gaming 100% mulus tanpa gangguan visual.

### 3. Notifikasi Status Bar Tunggal yang Bersih & Hening
- Notifikasi status bar dikonfigurasi dengan prioritas rendah (`IMPORTANCE_LOW`): tanpa suara, tanpa getar, dan tanpa banner pop-up heads-up yang menutupi game.
- Format teks dibuat minimalis, elegan, dan informatif:
  - Saat Game Aktif: `Lynx • [EXTREME]` | Teks: `Honkai: Star Rail • 120Hz`
  - Saat Standby/Harian: `Lynx • [BALANCE]` | Teks: `Mode Standby Aktif`
- Notifikasi tersemat secara hening (*ongoing silent*) dan memperbarui diri di tempat yang sama (*in-place update*) tanpa menumpuk entri notifikasi baru.

# Lynx Universal [Per-App Custom Target Profile Engine & Zero-Fork Precise Foreground Activity Detection] 7.0.0-RC34
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC34** (Lynx Kernel Manager v3.0.98): **Penyelarasan Dinamis Aturan Per-App Companion (`app_rules.json` Custom Profile Evaluation), Peralihan Otomatis Profil `Extreme` untuk Honkai: Star Rail, Eliminasi Total Masking Keyboard/IME via Pemfilteran Kernel `oom_score_adj == 0`, Latensi Peralihan Sub-100ms (86.87 ms), serta Histeresis Pendinginan Zero-Stutter 5 Detik**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC34)

### 1. Integrasi Penuh Aturan Kustom Per-Aplikasi (`app_rules.json` & `targetProfile`)
- **Akar Masalah**: Sebelumnya `DecisionEngine` pada daemon native `lynxd` menetapkan profil `performance` secara hardcoded untuk semua aplikasi berkategori game, mengabaikan konfigurasi spesifik pengguna pada Lynx Companion App yang mengatur game tertentu (seperti Honkai: Star Rail `com.HoYoverse.hkrpgoversea`) ke mode `extreme`.
- **Solusi**: Lapisan `RulesEngine` kini mengurai konfigurasi `app_rules.json` (dan `app_rules.tsv`), memetakan `targetProfile` (seperti `extreme`, `performance`, `balanced`, atau `powersave`) langsung ke `ForegroundApp.target_profile`. `DecisionEngine` memprioritaskan profil kustom pengguna saat aplikasi aktif di latar depan.

### 2. Presisi Deteksi Latar Depan Sub-1ms Tanpa Masking Input Method (IME/Gboard)
- **Akar Masalah**: Pengecekan grup cgroup `/dev/cpuset/top-app/cgroup.procs` sebelumnya mengembalikan paket pertama yang memiliki titik, sehingga saat keyboard (Gboard/LatinIME) atau Text-To-Speech (TTS) berjalan di latar depan, nama paket yang dilaporkan tertahan pada `com.google.android.inputmethod.latin` dan menutupi game atau aplikasi aktif.
- **Solusi**:
  - Menyaring secara ketat service latar belakang/helper (`inputmethod`, `keyboard`, `.tts`).
  - Menginspeksi `/proc/{pid}/oom_score_adj` secara langsung dari procfs Linux (Zero-Fork). Kernel Android menetapkan `TOP_APP_ADJ = 0` secara eksklusif hanya untuk activity jendela utama yang sedang difokuskan oleh pengguna, sementara service perceptible atau IME memiliki skor `200`. Hal ini menjamin deteksi aplikasi foreground 100% akurat tanpa jeda dan tanpa forking berat `dumpsys`.

### 3. Pengujian Nyata Hardware MediaTek (Infinix Note 11S)
- **Aktivasi Extreme Mode**: Saat Honkai: Star Rail (`com.HoYoverse.hkrpgoversea`) aktif, daemon seketika beralih ke profil `extreme` dengan latensi komit hanya 86.87 ms (31 node sysfs terkomit).
- **Verifikasi Clock Hardware**: Core LITTLE Cortex-A55 terkunci di frekuensi maksimal 2.0 GHz (`2000000`), dan Core BIG Cortex-A76 terkunci di 2.05 GHz (`2050000`).
- **Histeresis Cooldown**: Saat pengguna keluar ke home launcher, sistem menahan mode `extreme` selama buffer 5 detik untuk mencegah micro-stutter, sebelum secara mulus kembali ke profil `balance`.

# Lynx Universal [Zero-Freeze Live Battery Synchronization & Hardware Decoupling] 7.0.0-RC33
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC33** (Lynx Kernel Manager v3.0.97): **Eliminasi Total Pembekuan Persentase Baterai Android (`dumpsys battery set` Purged), Sinkronisasi Dinamis Live Uevent Kernel Real-Time, Pencegahan Risiko Sudden Power-Off & Overcharging Akibat Tampilan Terkunci, dan Sinkronisasi Sempurna Perhitungan Persen Desimal**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC33)

### 1. Eliminasi Mutlak Pembekuan Layanan Baterai (`dumpsys battery set` Purged)
- **Akar Masalah**: Eksekusi perintah `dumpsys battery set status 4` pada saat pengaktifan mode bypass memicu flag `mUpdatesStopped = true` di dalam `BatteryService` Android. Hal ini menghentikan total pembaruan status dan level baterai dari kernel Linux ke framework Android (`UPDATES STOPPED`), sehingga angka di status bar terkunci permanen pada persentase tertentu meskipun baterai secara fisik mengalami penurunan (*discharge*) atau peningkatan daya.
- **Dampak Kritis yang Dicegah**: Mencegah perangkat mati mendadak (*sudden power-off*) akibat kekurangan daya yang tidak terlihat oleh pengguna (baterai fisik habis padahal UI menampilkan angka statis), serta mencegah salah persepsi pengisian daya berlebih (*overcharge*).
- **Solusi**: Seluruh pemanggilan `dumpsys battery set` dihapus secara menyeluruh dari lapisan native Rust (`charging.rs`) dan aplikasi Android Companion (`ChargingRepository.kt`). Sebagai gantinya, sistem secara aktif memanggil `dumpsys battery reset` agar Android framework terus menerima uevent live secara real-time langsung dari sensor fuel gauge hardware.

### 2. Presisi Perhitungan Desimal & Visual Baterai
- Karena persentase baterai kernel dan Android kini sinkron 100%, animasi pengisian daya, persentase desimal (`xx.xx%`), dan status kapasitas pada Hero Card Companion App mencerminkan kondisi riil sel baterai tanpa keterlambatan.

# Lynx Universal [Autonomous Game Awareness & Screen Backlight Detection Fix] 7.0.0-RC32
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC32** (Lynx Kernel Manager v3.0.96): **Perbaikan Deteksi Layar Aktif (ScreenDetector Prioritizing LCD Backlight over Write-Only fb0/blank), Otomatisasi Peralihan Profil Kernel Game Real-Time (Autonomous Real-Time Game Detection for Honkai: Star Rail & 3D Gaming), serta Verifikasi Telemetri Bypass Hardware di Bawah Beban Berat**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC32)

### 1. Perbaikan Prioritas Sensor Layar Aktif (`ScreenDetector`)
- **Masalah**: Node `/sys/class/graphics/fb0/blank` pada kernel MediaTek bersifat write-only dan mengembalikan string kosong saat dibaca. Akibatnya daemon `lynxd` menganggap layar dalam status `ScreenState::Off`, memicu Deep Sleep Shield (20s) dan menonaktifkan pemantauan aplikasi aktif.
- **Solusi**: `ScreenDetector` kini memprioritaskan pemeriksaan node kecerahan backlight fisik (`/sys/class/leds/lcd-backlight/brightness`, `/sys/class/backlight/*/brightness`) yang terbukti membaca nilai aktual numerik secara presisi, dengan fallback terpadu ke `dumpsys power` (`mHoldingDisplaySuspendBlocker=true`).

### 2. Otomatisasi Penuh Peralihan Profil Game Real-Time
- Begitu game berat (seperti Honkai: Star Rail `com.HoYoverse.hkrpgoversea`) dibuka di latar depan, daemon `lynxd` secara instan mendeteksi status game dan beralih ke profil `performance`.
- Governor CPU0 (LITTLE) terkunci ke frekuensi maksimum 2.0 GHz, dan CPU6 (BIG Cortex-A76) melonjak ke 1.986 GHz untuk menjamin zero-stutter gaming.

### 3. Verifikasi Telemetri Bypass Hardware Aktual di Bawah Beban Berat
- Adapter input current (`Pump_Express_ICharger`) terbukti terputus total ke 0 mA saat batas cut-off aktif.
- Baterai beroperasi dalam status discharge terkendali (`current_now < 0`, -121 mA) untuk menyuplai sisa konsumsi daya motherboard tanpa terjadi pengisian berlebih ke sel baterai.

# Lynx Universal [Hardware Regulated Charging Precision & Dynamic Auto-Cut Latch] 7.0.0-RC31
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC31** (Lynx Kernel Manager v3.0.96): **Penyempurnaan Total Regulasi Arus Fisik Fast Charging (Physical Hardware Charging Regulation), Pemisahan Tegas Spektrum Mode (Cool 1000mA, Standard OEM 33W, Hyper Unconstrained, Custom Slider), Implementasi Kontrol Khusus Chipset Transsion MTK (PDC Max Watt 5W/33W, PE20/PE40 Pump Suppression, Battery Charging Current Throttling BCCT Thermal Devices, dan In-Call Charging Clamping State), Sistem Cutoff Pengisian Cerdas Histeresis Murni (Auto-Cut & Bypass Hysteresis Latching Bebas-Flapping), Serta Restorasi Penuh Register & Izin Sysfs pada Saat Pencabutan Charger**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC31)

### 1. Presisi Arus Fisik Tiap Mode Pengisian Daya (Hardware Regulation)
- **Mode Sejuk (Cool Mode - 1000 mA Target)**:
  - Mengunci batas daya adapter `pdc_max_watt` ke 5W (5V/1.0A), mematikan pump express `pe20` & `pe40` (0), dan mengaktifkan BCCT (`mtk-cl-bcct00..02`, `abcct`) ke status 1 (throttle).
  - Mengaktifkan `Charging_CallState = 2` pada platform Transsion untuk meredam pemanasan baterai secara fisik.
  - Memperbarui nilai bawaan mode sejuk dari 2000 mA menjadi 1000 mA di seluruh lapisan native Rust (`lynxd`), repository Kotlin (`ChargingRepository.kt`), ViewModel (`LynxViewModelBattery.kt`), dan UI (`FastChargingControlCard.kt`).
- **Mode Standar (Standard OEM Adaptive)**:
  - Mengembalikan alokasi daya adapter `pdc_max_watt` ke 33W, membuka kembali pump express `pe20` & `pe40` (1), menormalkan `Charging_CallState = 0`, dan melepaskan BCCT throttling ke status 0.
  - Membuka seluruh izin node pengisian daya kembali ke `0666` sehingga algoritma termal OEM dapat mengontrol arus secara dinamis tanpa hambatan kuncian.
- **Mode Hyper & Custom**:
  - Hyper mode membuka potensi penuh pengisian daya tanpa batasan kaku.
  - Custom mode menerapkan batasan mA presisi dari slider pengguna (500–25.000 mA) langsung ke register kernel.

### 2. Cutoff Pengisian Cerdas & Bypass Histeresis Bebas-Flapping
- **Eliminasi Syarat Kaku 50mA**:
  - Mengganti evaluasi histeresis lama yang bergantung pada pembacaan arus `<= 50mA` dengan evaluasi status kait (*latch state*) berbasis persentase baterai vs ambang batas slider.
  - Menghilangkan flapping bolak-balik antara bypass dan normal saat arus pengisian masih mengalami sisa trickle flow.
  - Telemetri `status_json()` secara konsisten melaporkan `smart_limit_latched: true` dan `bypass_active: true`, menampilkan status `⚡ BYPASS (Cutoff Active)` secara stabil pada UI Hero Card.
- **Pembersihan Otomatis Saat Ganti Mode**:
  - Mengubah mode pengisian daya (Cool/Standard/Hyper/Custom) secara otomatis mereset status bypass dan menghapus flag kuncian bypass yang kadaluarsa.

### 3. Restorasi Seketika Saat Charger Dilepas (Unplug Restoration)
- **`handle_disconnect()` Native Rust**:
  - Secara otomatis memulihkan `pdc_max_watt` ke 33W, melepaskan `Charging_CallState` ke 0, mematikan pembatasan BCCT, mereset `dumpsys battery reset`, dan membuka izin seluruh node sysfs ke `0666`.
  - Mencegah kebocoran daya atau anomali termal pada saat pengisian daya dihentikan atau kabel dilepas.

### 4. Presisi Desimal Baterai & Animasi Lingkaran
- Menjaga keakuratan desimal Coulomb counter terintegrasi (`.0` s/d `.9`) yang tersinkronisasi mulus dengan persentase dasar baterai dan indikator animasi lingkaran daya.

---

# Lynx Universal [Standard Charging State Restoration & Decimal Battery SOC Precision] 7.0.0-RC30
Released on: 2026-10-13
> **Lynx Universal v7.0.0-RC30** (Lynx Kernel Manager v3.0.95): **Pemberantasan Tuntas Masalah Kebocoran Mode Pengisian Ekstrem (Extreme Charging Leak Eliminator), Implementasi Pemulihan Standar OEM Hardware Murni pada Rust Daemon & Kotlin Shell (`apply_standard_mode`), Resolusi Pembekuan Daemon Termal Vendor (`thermalloadalgod` Unfreeze via Signal 18/SIGCONT), Penggantian Skrip Monolitik Lingering dengan Facade Delegator (`core/Charging-Controller.sh`), Serta Kalkulasi Presisi Tinggi Persentase Baterai Desimal 4-Tingkat Bebas-Hilang (`.0` s/d `.9`)**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC30)

### 1. Eliminasi Kebocoran Mode Pengisian Ekstrem (State & Sysfs Leak Fix)
- **Rust Native Daemon (`native/lynxd`)**:
  - Merekonstruksi `apply_standard_mode()` di `ChargingRegulator`: Menghapus penulisan kuncian `0444` dan pembatasan arus kaku, serta secara otomatis membuka kunci (*chmod 666*) seluruh node pengisian daya (`input_current`, `sc_ibat_limit`, `chg1_current`, `enable_sc`, dll.) agar driver OEM dapat mengontrol arus secara dinamis.
  - Memulihkan parameter proteksi termal `/proc/driver/thermal/clabcct`, `clabcct_lcmoff`, `tzbts_param`, dan `pca_dv2_algo/dv2_debug` ke nilai default aman OEM dengan izin tulis `0644`.
  - Mengirimkan sinyal langsung `SIGCONT` (18) melalui panggilan sistem libc ke seluruh daemon termal vendor (`thermalloadalgod`, `thermal-engine`, `mi_thermald`, `joyose`), memulihkan status daemon dari `T (Stopped)` menjadi `S (Sleeping)` yang aktif menjaga suhu perangkat.
  - Menghapus flag kuncian atomik `/dev/lynx_extreme_charging` dan menyinkronkan status ke `/dev/lynx_standard_charging`.
- **Penghentian Skrip Latar Belakang Lingering**:
  - Mengidentifikasi dan mematikan proses shell lawas `Charging-Controller.sh` yang sebelumnya memicu loop penguncian ekstrem terus-menerus di latar belakang.
  - Mengganti `core/Charging-Controller.sh` dengan facade delegator 20 baris yang mendelegasikan 100% eksekusi ke biner native `lynxd`, mengeliminasi loop konkuren.
  - Menyederhanakan `service.sh` modul menjadi pemanggilan langsung `lynxd boot`.

### 2. Guard Penguncian Ekstrem pada Lapisan Kotlin Repository
- **`ChargingRepository.kt`**:
  - Melindungi `reapplyExtremeChargingLock()` dengan pengecekan ketat: Eksekusi dibatalkan seketika jika mode pengisian aktif bukan `"hyper"` dan `extremeChargingEnabled` bernilai `false`.
  - Memperbaiki `applySavedChargingConfig()` agar memanggil `setChargingMode()` yang tepat untuk `"standard"` daripada jatuh ke blok `else` yang berpotensi memicu skrip ekstrem warisan.
- **`StandardChargingScript.kt`**:
  - Menyinkronkan pemulihan `/proc/driver/thermal/clabcct`, `clabcct_lcmoff`, dan `tzbts_param` serta mengirimkan sinyal `kill -18` untuk mencairkan proses termal vendor jika lynxd tidak tersedia.

### 3. Presisi Tinggi Kalkulasi Persentase Desimal Baterai (Zero-Drop Decimal SOC)
- **`ChargingHeroDisplayCard.kt`**:
  - Merevisi arsitektur kalkulasi desimal baterai dengan model interpolasi 4-tingkat:
    1. *Tingkat 1*: Delta Coulomb counter perangkat keras sejak persentase integer aktif dimulai (`liveHardwareChargeCounterUah - levelEntryAnchorUah`).
    2. *Tingkat 2*: Integrasi arus riil listrik dinamis ($\Delta Q = I \times \Delta t$) terkalibrasi per-detik.
    3. *Tingkat 3*: Rasio Coulomb langsung jika selisih fuel-gauge selaras dengan persentase OS.
    4. *Tingkat 4*: Estimasi laju aliran listrik kontinu berbasis waktu aktif dan arus pengisian riil.
  - Memastikan angka desimal (`.0` s/d `.9`) selalu tampil aktif dan mulus selama pengisian terhubung, bebas dari kedipan atau hilang menjadi integer murni.
  - Mengoreksi penentuan status `isCharging` agar tetap aktif selama perangkat tersambung daya eksternal dan tidak mengalami pelepasan daya aktif.

---

# Lynx Universal [CPU Cluster Tuner Modularization & i18n Localization Engine] 7.0.0-RC27
Released on: 2026-10-12
> **Lynx Universal v7.0.0-RC27** menandai implementasi Tahap 3 (Modularisasi Domain CPU - Sub-domain A: CPU Cluster Tuner) pada aplikasi Lynx Kernel Manager (v3.0.92): **Dekomposisi Monolith `CpuClusterTunerCard` (1.377 Baris) Menjadi 8 Modul Mandiri Terfokus di Bawah `com.noir.lynx.feature.cpu.ui.cluster.*`, Kepatuhan Anggaran Baris Ketat ($\le 330$ Baris per File Sesuai Pedoman Arsitektur AGENTS.md), Standarisasi i18n Multi-Bahasa Menyeluruh via `strings.xml` dan `stringResource`, Serta Pengurangan Signifikan Ukuran Berkas Inti `LynxComponents.kt` Sebesar 1.351 Baris**. Seluruh fungsionalitas penalaan frekuensi kluster (stepped grid MHz/GHz, auto min/max, thermal lock, selector scaling governor, preset latensi Schedutil, dan governor tunables editor) terverifikasi 100% utuh tanpa kehilangan fungsi sedikit pun.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC27)

### 1. Dekomposisi Modular Domain CPU Cluster (`feature/cpu/ui/cluster/`)
- Memecah kartu penala kluster CPU monolith menjadi 8 berkas modular terisolasi:
  - `TunableMeta.kt` (~144 baris): Metadata parameter kernel, ikonografi, dan fungsi pemformatan satuan mikrodetik/milidetik (`formatTunableDisplay`, `getTunableMeta`).
  - `dialogs/TunableEditDialog.kt` (~196 baris): Dialog pengeditan parameter tunggal dengan saran nilai cepat, preview konversi waktu instan, dan tombol terapkan.
  - `dialogs/FrequencyPickerBottomSheet.kt` (~198 baris): Lembar pemilihan frekuensi 2-kolom dengan format MHz/GHz adaptif dan deteksi otomatis batas *Auto Min / Auto Max*.
  - `dialogs/GovernorPickerBottomSheet.kt` (~178 baris): Lembar pemilihan algoritma scaling governor dengan tag deskriptif dan indikator seleksi aktif.
  - `dialogs/SchedutilPresetsCard.kt` (~185 baris): Kartu preset latensi responsivitas jam Schedutil (Responsif, Seimbang, Hemat Daya, OEM) dengan detektor status aktif *real-time*.
  - `dialogs/QuickTunablesBottomSheet.kt` (~330 baris): Lembar orkestrasi tunable governor, pengurutan kronologis, switch boolean, dialog konfirmasi reset OEM, dan delegasi ke kartu preset.
  - `CpuClusterItemCard.kt` (~250 baris): Kartu kebijakan kluster individual dengan header peran/inti, tombol ganda min/max frekuensi, tombol kunci sentuh 48×48 px, serta tombol aksi governor dan tunables.
  - `CpuClusterTunerCard.kt` (~128 baris): Orkestrator utama yang mengelola status lembar modal dan merender daftar kartu kluster CPU.

### 2. Standarisasi i18n Multi-Bahasa Menyeluruh (`strings.xml`)
- Membungkus seluruh teks UI penala kluster CPU (judul kartu, dialog edit, saran cepat, deskripsi governor, preset latensi, dan pesan konfirmasi) ke dalam file sumber daya string `strings.xml` menggunakan format `stringResource(R.string...)`.
- Menyiapkan fondasi multi-bahasa yang bersih dan terstandarisasi untuk lokalisasi lintas bahasa tanpa teks tertulis keras (*hardcoded string*).

### 3. Pengurangan Beban Monolith & Kepatuhan Metrik Baris
- Mengurangi ukuran berkas `LynxComponents.kt` dari 6.854 baris menjadi 5.503 baris (-1.351 baris) dengan mendelegasikan pemanggilan ke `com.noir.lynx.feature.cpu.ui.cluster.CpuClusterTunerCard`.
- Menambah jumlah berkas compliant ($\le 400$ baris) dari 63 menjadi 71 berkas pada repositori Lynx Companion.
- Menguji rilis APK teroptimasi R8 pada perangkat uji fisik Infinix Note 11S (Helio G96 / Android 14) via Wireless ADB: proses booting mulus, interaksi responsif, dan nol *runtime crash*.

---

# Lynx Universal [Autonomous ADB Keep-Alive Self-Healing & Real-Time Socket Verification] 7.0.0-RC26
Released on: 2026-10-12
> **Lynx Universal v7.0.0-RC26** menghadirkan penyempurnaan menyeluruh pada fitur ADB Wireless Keep-Alive & Port Lock di daemon `lynxd` dan aplikasi Lynx Kernel Manager (v3.0.91): **Pemulihan Otomatis 100% Mandiri (*Autonomous Self-Healing* Saat Deep Sleep atau Restart Tanpa Perlu Sakelar Manual), Proteksi Framework Android 11+ (`settings put global adb_wifi_enabled 1`), Siklus Pemantauan Super Hemat Daya (Watchdog 2500ms Non-Wakelock, <0.001% CPU Duty Cycle, Sub-0.02ms In-Process Read), Akurasi Status Socket Real-Time di Antarmuka (`● LOCKED` Hijau Hanya Jika Socket Benar-Benar Listening vs `⚡ MEMULIHKAN` Oranye Saat Proses Re-binding), Serta Quick Connection Guide Row yang Bersih dan Elegan**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC26)

### 1. Resilient & Battery-Friendly Rust Daemon (`native/lynxd/src/subsystems/adb.rs`)
- Mengintegrasikan penguncian framework Android 11+ via `settings put global adb_wifi_enabled 1` untuk mencegah garbage collector sistem mematikan server nirkabel ADB saat perangkat tidur lelap.
- Mengubah interval watchdog loop menjadi 2500ms adaptif tanpa menahan CPU wakelock, mengizinkan SoC memasuki status Deep Sleep C-States 100% sempurna tanpa menguras baterai.
- Membangun auto-resurrection pada kueri `lynxd adb status`: jika konfigurasi keep-alive aktif namun watchdog terhenti, daemon secara otomatis membangkitkan watchdog kembali di latar belakang.

### 2. Autonomous Self-Healing & Real-Time Badge di Aplikasi (`LynxCompanion`)
- Memperkenalkan properti `isAdbListening` pada `LynxUiState` yang memvalidasi pembukaan port fisik di `/proc/net/tcp` secara presisi.
- Memicu pemulihan otomatis seketika saat aplikasi dibuka (`init`) dan saat kembali ke latar depan (`onAppResume`) jika port terdeteksi tertutup saat status keep-alive aktif.
- Memperbarui badge status: menampilkan `● LOCKED : <PORT>` (Hijau) jika socket aktif mendengarkan, `⚡ MEMULIHKAN : <PORT>` (Oranye) saat proses re-binding, dan `○ STANDBY` jika dinonaktifkan.
- Menambahkan kartu ringkas `adb connect <IP>:<PORT>` untuk memudahkan pengembang menyambungkan terminal tanpa perlu memeriksa IP perangkat secara manual.
- Perbaikan susulan: label tombol `Kunci Port` yang sempat hilang pada build awal RC26 telah dikembalikan.

---

# Lynx Universal [Seamless Vector Discharge Curve & Single Interactive Cursor] 7.0.0-RC25
Released on: 2026-10-12
> **Lynx Universal v7.0.0-RC25** memperbarui estetika kanvas grafik penurunan baterai pada aplikasi Lynx Kernel Manager (v3.0.90): **Eliminasi Total Bulatan Titik Koordinat Bergerombol (*Clutter-Free Vector Spline Curve* dengan `StrokeCap.Round` & `StrokeJoin.Round`), Pengenalan Kursor Interaktif Tunggal Dinamis (*Single Active Glow Cursor* yang Mengikuti Sentuhan Jari Pengguna atau Titik Terkini), serta Retensi Penuh Indikator Status Layar Aktif/Mati (SOT/Off-Screen) Melalui Strip Garis Bawah Kanvas dan Chip Ringkasan Cerdas**. Menghadirkan visual grafik analitik yang sangat bersih, elegan, dan profesional setara dashboard analitik modern.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC25)

### 1. Kurva Vektor Mulus Tanpa Distorsi Titik Bergerombol (`LynxTuningSubscreens.kt`)
- Menghapus perulangan penggambaran lingkaran statis pada seluruh koordinat titik riwayat baterai yang sebelumnya membuat kurva terlihat padat dan bergelombang tidak rata saat jumlah data meningkat.
- Mengonfigurasi rendering garis kurva dengan sambungan membulat antialiased (`StrokeJoin.Round`, `StrokeCap.Round`), menghasilkan garis vektor yang bersih dan tajam di atas gradien vertikal transparan.

### 2. Kursor Titik Interaktif Tunggal dengan Halo Bersinar (`LynxTuningSubscreens.kt`)
- Menampilkan satu titik fokus interaktif yang presisi hanya pada posisi yang sedang disentuh (*scrubbing*) atau titik riwayat terakhir.
- Dilengkapi lingkaran halo bersinar lembut (*subtle glowing aura*) dan garis vertikal putus-putus panduan waktu yang secara cerdas berganti warna mengikuti status layar (Hijau untuk Layar Aktif / SOT dan Cyan untuk Layar Mati).

---

# Lynx Universal [Collapsible Step Log Accordion & Top-5 App Drain Views] 7.0.0-RC24
Released on: 2026-10-12
> **Lynx Universal v7.0.0-RC24** menghadirkan penyempurnaan antarmuka yang sangat ringkas, bersih, dan elegan (*compact & glanceable*) pada kartu Riwayat & Penggunaan Baterai di Lynx Kernel Manager (v3.0.89): **Accordion Lipat Minimalis untuk Log Durasi per 1% Penurunan (Eliminasi Beban Vertikal 10+ Kartu Langkah dengan Header Sentuh Modern & Transisi Halus `AnimatedVisibility`), Tampilan Top-5 Prioritas untuk Konsumsi Daya Aplikasi & Proses Sistem (Fokus pada Konsumen Terbesar dengan Tombol Ekspansi Sleek `Lihat X Aplikasi Lainnya`), serta Kepatuhan Penuh Standar Touch-First $\ge 44\text{ px}$ Tanpa Kebisingan Visual**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC24)

### 1. Accordion Lipat Log Durasi per 1% Penurunan (`LynxTuningSubscreens.kt`)
- Mengemas daftar panjang langkah penurunan baterai 1% ke dalam header lipat (accordion) interaktif berlatar elevasi halus dengan ikon riwayat dan indikator jumlah langkah.
- Membuka dan menutup dengan animasi tinggi dan opasitas halus (*fluid expand/shrink transition*), menjaga kanvas grafik penurunan waktu tetap menjadi fokus utama tanpa terdorong ke bawah.

### 2. Tampilan Ringkas Top-5 Aplikasi & Tombol Ekspansi Sleek (`LynxTuningSubscreens.kt`)
- Secara cerdas menampilkan 5 aplikasi/proses sistem yang paling banyak menghabiskan daya baterai secara default.
- Menyediakan tombol sentuh yang sangat elegan di bagian bawah untuk mengekspansi daftar lengkap dengan transisi lembut saat pengguna ingin menelusuri seluruh proses yang aktif.
- Menjaga kebersihan layout antarmuka agar selalu rapi, modern, dan tidak membebani layar pengguna.

---

# Lynx Universal [Clean Minimalist App & System Battery Drain Analytics] 7.0.0-RC23
Released on: 2026-10-12
> **Lynx Universal v7.0.0-RC23** menghadirkan modul analisis konsumsi daya aplikasi dan proses sistem yang akurat, minimalis, dan elegan pada halaman Informasi Baterai di Lynx Kernel Manager (v3.0.88): **Segmented Switcher 2-Mode Minimalis (`Grafik Waktu` | `Penggunaan Aplikasi`), Ekstraksi 100% Data Riil & Akurat dari Subsistem Kernel/Android (`dumpsys batterystats --charged` Section `Estimated power use (mAh)` Sub-100ms Tanpa Lag), Eliminasi Kebisingan Visual (Tanpa Tumpukan Pill, Badge, Maupun Jargon Rumit), Serta Resolusi Otomatis UID ke Ikon & Label Resmi Aplikasi (`PackageManager` In-Memory Caching)**. Memberikan visibilitas instan kepada pengguna mengenai aplikasi maupun layanan latar belakang yang paling menguras daya baterai secara transparan dan mudah dipahami.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC23)

### 1. Kartu Riwayat & Penggunaan Baterai Terpadu (`LynxTuningSubscreens.kt`)
- Menyatukan dimensi waktu (grafik kurva penurunan dan log durasi per 1%) dengan dimensi aktor/penyebab penurunan daya ke dalam satu kartu terpadu via switcher 2-segmen yang rapi dan touch-friendly.
- **Tampilan Minimalis & Elegan**:
  - Menghilangkan filter pill berlapis dan badge warna-warni yang mengaburkan fokus.
  - Setiap baris hanya menyajikan 3 elemen esensial: Ikon resmi (aplikasi atau komponen sistem), nama yang jelas, persentase (%) tebal dengan estimasi mAh riil, serta bilah proporsi gradien tipis (*subtle glowing progress bar*).
  - Diurutkan otomatis dari konsumsi tertinggi ke terendah secara deterministik.

### 2. Ekstraksi Akurat & Resolusi UID Cepat (`LynxRepository.kt`)
- Mengoptimalkan pembacaan `dumpsys batterystats --charged` hingga 350 baris pertama untuk menangkap tabel `Estimated power use (mAh):` secara lengkap tanpa memicu pemotongan data.
- Menambahkan *in-memory cache* (`appDrainLabelCache`) untuk memetakan UID sistem (`UID 0` -> Kernel & Root, `UID 1000` -> Sistem Android, `UID 1041` -> Audio Server, `UID 2000` -> Shell/ADB) dan UID aplikasi pengguna (`u0aXXX`) ke nama dan paket resmi aplikasi secara instan dalam hitungan mikrodetik.
- Menjumlahkan dan menggabungkan sub-komponen paket ganda agar setiap aplikasi tampil dalam satu entitas yang akurat dan bersih.

---

# Lynx Universal [Stokes-Coulomb Analytical Physics & Zero-Jerk Landing] 7.0.0-RC22
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC22** merevolusi arsitektur fling scrolling aplikasi Lynx Kernel Manager (v3.0.87) dengan menerapkan **Solusi Tertutup Analitis Stokes-Coulomb (Analytical Closed-Form Trajectory Engine)**: **Integrasi Parametrik Berbasis Clock Hardware Nanosecond (`withFrameNanos`), Eliminasi Pemotongan Sub-Piksel (*Sub-Pixel Residual Roll-Over*), Deselerasi Landing Tanpa Hentakan (*Zero-Jerk Terminal Settling* dengan $v(T) \equiv 0.000\text{ px/s}$), serta Sinergi Friksi Permukaan ($\mu = 1350\text{ px/s}^2$) dan Redaman Fluida Viskos ($\gamma = 0.80\text{ s}^{-1}$)**. Menghasilkan pergerakan inersia yang luar biasa mulus (*buttery smooth*), tanpa mikrojitter, presisi di layar 120Hz, dan mendarat sempurna tanpa freeze mendadak.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC22)

### 1. Solusi Tertutup Analitis Stokes-Coulomb (`MainActivity.kt`)
- Menggantikan integrasi aproksimasi langkah per-frame diskret dengan solusi diferensial analitis tertutup:
  $$S(t) = \left(v_0 + \frac{\mu}{\gamma}\right) \frac{1 - e^{-\gamma t}}{\gamma} - \frac{\mu}{\gamma} t$$
  dengan durasi deterministik:
  $$T = \frac{1}{\gamma} \ln\left(1 + \frac{\gamma v_0}{\mu}\right)$$
- Di setiap frame VSYNC (8,3 ms pada 120Hz), posisi kanvas dievaluasi langsung dari selisih waktu nanodetik murni hardware sejak jari dilepas, menghilangkan akumulasi distorsi akibat variasi latensi thread.

### 2. Eliminasi Jitter Sub-Piksel (*Sub-Pixel Roll-Over*)
- Sisa pecahan piksel yang belum terkonsumsi oleh layout Compose pada frame sebelumnya otomatis diakumulasikan ke frame berikutnya (`targetDisplacement - accumulatedConsumed`), menghasilkan luncuran yang bebas patah-patah mikro.

### 3. Pendaratan Terminal Murni Nol (*Zero-Jerk Landing*)
- Kecepatan tepat mencapai $0.000\text{ px/s}$ saat $t = T$ secara matematis, mengeliminasi penghentian mendadak dari ambang batas kecepatan cutoff.

---

# Lynx Universal [Featherlight Chromium Fluid Fling & Friction Calibration] 7.0.0-RC21
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC21** mengalibrasi koefisien redaman fluida inersia pada aplikasi Lynx Kernel Manager (v3.0.86) untuk menghadirkan sensasi scrolling yang super ringan (*featherlight*): **Penurunan Koefisien Friksi Viscous Damping dari $\gamma = 2.10\text{ s}^{-1}$ ke $\gamma = 1.25\text{ s}^{-1}$ (Peningkatan Jarak Luncur Inersia 68% Lebih Ringan Tanpa Bobot), serta Penyesuaian Ambang Batas Cutoff Kecepatan ke $6\text{ px/s}$ untuk Transisi Berhenti Sehalus Sutra**. Menghilangkan sensasi berat atau hambatan saat mengusap layar, memberikan pergerakan yang ringan, cepat, dan presisi layaknya Google Chrome Android asli di layar 120Hz.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC21)

### 1. Kalibrasi Friksi Fluida Viskos Featherlight ($\gamma = 1.25\text{ s}^{-1}$)
- Mengurangi hambatan inersia hingga 40% lebih ringan dibandingkan RC20:
  $$v(t) = v_0 \cdot e^{-1.25 \cdot t}$$
- Jarak tempuh luncuran usapan jari meningkat hingga 68% lebih leluasa, memungkinkan pengguna menjelajahi dashboard dan daftar opsi hanya dengan satu usapan santai tanpa harus mengayuh layar berulang-ulang.
- Ambang batas penghentian akhir diturunkan dari $15\text{ px/s}$ menjadi $6\text{ px/s}$ untuk deselerasi terminal yang mulus tanpa penghentian mendadak.

---

# Lynx Universal [Chrome Android Viscous Fluid Fling & Stretch Overscroll Damping] 7.0.0-RC20
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC20** menyempurnakan fisika scroll aplikasi Lynx Kernel Manager (v3.0.85) dengan mengadopsi model pergerakan **Google Chrome Android (Viscous Fluid Damping Model)**: **Eliminasi Pengali Kecepatan Artifisial (Normal 1.0x Velocity), Implementasi Model Friksi Eksponensial Kontinu Chromium ($\gamma = 2.10\text{ s}^{-1}$), Absorpsi Energi Kinetik Batas Kontainer (Zero Residual Overscroll Recoil), serta Penonaktifan Global Stretch Overscroll Elastis (`LocalOverscrollConfiguration provides null`)**. Menghasilkan sensasi scrolling yang super ringan, mulus tanpa hentakan, stabil di layar 120Hz, dan bebas dari sentakan balik.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC20)

### 1. Adopsi Fisika Viscous Damping Google Chrome Android (`MainActivity.kt`)
- **Model Redaman Fluida Kontinu**:
  - Menggantikan spline decay bawaan dengan model gesekan fluida viskos kontinu Chromium:
    $$v(t) = v_0 \cdot e^{-\gamma \cdot t}$$
    dengan koefisien redaman $\gamma = 2.10\text{ s}^{-1}$.
  - Mengeliminasi pengali kecepatan `1.15x` yang sebelumnya membuat layar terlalu sensitif/liar saat disentuh perlahan, mengembalikan rasio kecepatan alami `1.0x` yang presisi mengikuti laju jari pengguna.
  - Pergerakan inersia kini meluncur dengan kebebasan hambatan di awal dan melambat secara sangat anggun tanpa rem mendadak (*soft aerodynamic settling*), identik dengan sensasi scrolling Google Chrome.

### 2. Eliminasi Total Lentingan Balik Batas Kontainer (*Zero Residual Bounce*)
- **Absorpsi Kecepatan Kinetik pada Batas Layar**:
  - Saat daftar mencapai puncak atas atau batas terbawah kontainer, sisa kecepatan inersia seketika diserap dan dinetralkan (`currentVelocity = 0f`), dan fungsi `performFling` selalu mengembalikan `0f`.
  - Mencegah Compose menyalurkan sisa ribuan pixel/detik kecepatan inersia ke mesin overscroll yang sebelumnya memicu lentingan balik (*elastic snap-back*).

### 3. Penonaktifan Global Stretch Overscroll Elastis (`MainActivity.kt`)
- **Pemberian `LocalOverscrollConfiguration provides null`**:
  - Membungkus seluruh hierarki tampilan root dengan `CompositionLocalProvider(LocalOverscrollConfiguration provides null)`.
  - Menghilangkan efek melar (*rubber-band stretch*) Android 12+ yang sering disalahartikan sebagai tampilan yang terpental kembali ke posisi awal saat digulir hingga ujung halaman.

---

# Lynx Universal [Touchscreen Collision Elimination & Calibrated Natural Spline Fling] 7.0.0-RC19
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC19** menuntaskan tuntas anomali scroll pada layar sentuh fisik di aplikasi Lynx Kernel Manager (v3.0.84): **Verifikasi Integritas Hardware Digitizer via Analisis Kernel Evdev (`mtk-tpd`), Eliminasi Tombol Lebar Pemicu Recomposisi pada Jalur Usap Jempol (`BatteryHealthStatsCard`), serta Kalibrasi Inersia Spline Glide dengan Deteksi Batas Kontainer (`Edge-Aware Animation Cancellation`)**. Menjamin interaksi usap layar (flick & drag) terasa seringan dan sealami Google Chrome dan aplikasi native Android tanpa hambatan maupun hentakan balik.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC19)

### 1. Bukti Faktual Integritas Hardware Layar Sentuh (`Evdev Kernel Audit`)
- **Verifikasi Digitizer Kapasitif Fisik 100% Sehat**:
  - Berdasarkan audit real-time event kernel `/dev/input/event3` (`mtk-tpd`), panel layar sentuh perangkat berfungsi sempurna tanpa cacat fisik: koordinat absolut analog kontinu (`0x257 ➔ 0x254 ➔ 0x24e`), tekanan stabil (`ABS_MT_PRESSURE = 1000`), elips sentuhan presisi (`ABS_MT_TOUCH_MAJOR = 7..12`), serta laju pelaporan stabil (~8–12 ms).
  - Masalah terkonfirmasi 100% merupakan software gesture collision di antarmuka, bukan kerusakan digitizer layar.

### 2. Eliminasi Tombol Pemicu Recomposisi pada Jalur Sentuh Jempol (`LynxComponents.kt`)
- **Pembersihan Kartu Kesehatan Baterai dari Tombol Full-Width**:
  - Menghapus tombol selebar layar `[ Segarkan Statistik Baterai & Sleep ]` yang sebelumnya melintang tepat di koordinat pendaratan alami jempol pengguna (`X: 650–710, Y: 1340–1475`).
  - Sebelumnya, sapuan cepat jempol (<100 ms) di area tersebut memicu deteksi tap/klik pada tombol, memanggil `refreshBatteryHealth()`, dan menghasilkan mutasi state mendadak yang membatalkan animasi scroll dan menghentakkan tampilan kembali.
  - Tombol segarkan kini dipindahkan secara elegan ke header kartu berupa badge pill minimalis (`Surface` + `Row` compact).

### 3. Kalibrasi Inersia Spline Glide & Pembatalan Batas Kontainer (`MainActivity.kt`)
- **Natural Inertia Glide 1.15x Boost**:
  - Mengimplementasikan `rememberSplineBasedDecay` yang dikalibrasi dengan pengali kecepatan inersia `1.15x` untuk mengeliminasi rasa berat atau "rem tak terlihat" (*artificial friction*) bawaan Compose.
- **Edge-Aware Boundary Cancellation**:
  - Menambahkan pembatalan animasi seketika saat scroll mencapai batas atas/bawah kontainer (`abs(delta) > 1.2f && abs(consumed) < 0.1f`), mencegah overscroll stretch berlebihan yang memantulkan kembali layar ke posisi awal.

---

# Lynx Universal [Touchscreen Fling Recoil Elimination & Native Platform Scroll Physics] 7.0.0-RC18
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC18** menghadirkan perbaikan kritis pada subsistem interaksi sentuh dan inersia scroll di aplikasi Lynx Kernel Manager (v3.0.83): **Eliminasi Total Bug Recoil/Snap-Back Fling pada Touchscreen Fisik, Restorasi Fisika Inersia Native Android (`ScrollableDefaults.flingBehavior`), Perbaikan Konsumsi Gesture Chart Riwayat Penurunan Baterai (`detectHorizontalDragGestures`), serta Penguncian Recomposisi Anchor Scroll Tab**. Menuntaskan anomali scroll di mana sapuan jari fisik pada layar touchscreen langsung ditarik/dikembalikan ke posisi awal (snap-back) akibat inversi tanda kecepatan (`VelocityTracker` jitter) dan pencegatan event sentuh vertikal.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC18)

### 1. Eliminasi Total Bug Fling Recoil / Snap-Back (`MainActivity.kt`)
- **Restorasi Fisika Fling Native Android**:
  - Menggantikan implementasi custom `rememberFluidFlingBehavior` dengan `ScrollableDefaults.flingBehavior()` bawaan Jetpack Compose yang telah terkalibrasi presisi terhadap `ViewConfiguration` dan kepadatan layar fisik perangkat.
  - Mengeliminasi pengali kecepatan `1.15x/1.20x` dan logika pembatalan `unconsumed > 2.0f && abs(consumed) < 0.1f` yang sebelumnya memicu eksekusi spline decay terbalik ketika terjadi micro-jitter pada saat jari diangkat (*finger lift-off*) dari panel kapasitif.
  - Memulihkan integrasi penuh dengan `AndroidEdgeEffect` overscroll damping sehingga batas kontainer diredam secara mulus tanpa sentakan.

### 2. Eliminasi Hambatan Gesture Vertikal pada Chart Baterai (`LynxTuningSubscreens.kt`)
- **Peralihan ke `detectHorizontalDragGestures`**:
  - Memperbaiki kartu grafik riwayat penurunan baterai (`RealDischargeStepHistoryCard`) yang sebelumnya menggunakan `detectDragGestures` umum tanpa filter arah, yang memonopoli dan memakan seluruh event sentuh vertikal ketika pengguna meletakkan ibu jari di area grafik untuk menggulir halaman ke bawah.
  - Mengalihkan scrubber grafik ke `detectHorizontalDragGestures` murni sehingga geseran vertikal diteruskan 100% tanpa hambatan ke kontainer scroll induk, sementara penjelajahan titik horizontal dan ketukan langsung (`detectTapGestures`) tetap responsif.

### 3. Stabilisasi Reset Posisi Scroll Subhalaman (`MainActivity.kt`)
- **Guard Transisi Tab Berbasis Komparasi State**:
  - Membungkus pemicu `subscreenLazyState.scrollToItem(0)` pada `LaunchedEffect(selectedCpuTab, selectedGpuTab, batterySubTab)` dengan pengecekan state sebelumnya (`lastCpuTab`, `lastGpuTab`, `lastBattTab`).
  - Mencegah reset scroll yang tidak disengaja ke posisi 0 saat terjadi recomposisi rutin atau pembaruan telemetri background periodik (1 Hz) ketika pengguna sedang membaca konten di bagian bawah halaman.

---

# Lynx Universal [Zero-Hardcode Battery Information & Unified Cycle Runtime Breakdown] 7.0.0-RC17
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC17** menghadirkan perombakan total pada halaman **Informasi Baterai** di aplikasi Lynx Kernel Manager (v3.0.82): **100% Data Sensor & Kernel Asli Tanpa Hardcode/Sintetis, Penggabungan Total Waktu & Proporsi Siklus Berjalan (Awal Dilepas ➔ Sekarang: Layar Aktif, Deep Sleep, dan Siaga Bangun), Riwayat Penurunan Per-Persen Asli (`Discharge Step History`), serta Penyederhanaan Tata Letak Menjadi 3 Kartu Presisi**. Mengeliminasi seluruh angka estimasi statis, grafik sintetis, maupun daftar aplikasi fallback tiruan, sehingga seluruh metrik yang ditampilkan murni mencerminkan data aktual dari `dumpsys batterystats --charged` dan node `/sys/class/power_supply/battery/`.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC17)

### 1. Eliminasi Total Nilai Hardcode & Data Sintetis (`LynxRepository.kt` & `LynxModels.kt`)
- **Zero-Hardcode Policy**:
  - Menghapus seluruh nilai default atau fallback statis pada statistik baterai (seperti laju terkuras statis `~10.8% / jam`, siklus fallback `868`, suhu offset buatan `+3.2°C` / `+1.1°C`, kurva riwayat sintetis `getOrGenerateDrainHistory`, serta daftar aplikasi fallback).
  - Seluruh metrik kini dibaca langsung dari `dumpsys batterystats --charged`, `dumpsys battery`, dan node sysfs perangkat (`/sys/devices/platform/odm/odm:tran_battery/BATTERY_QMAX`, `charge_full`, `charge_counter`, `cycle_count`, `voltage_now`, `current_now`, `current_avg`, `temp`).

### 2. Penggabungan Total Waktu & Proporsi Siklus Berjalan (`Awal ➔ Sekarang`)
- **Rincian Siklus Terpadu 100% Akurat**:
  - Menampilkan rentang level sejak charger dilepas hingga saat ini (misal `100% ➔ 91% (-9%)`), jam pelepasan charger (`Start clock time`), total mAh terkuras (`Discharge: mAh`), serta **Total Waktu Berjalan** gabungan (`Time on battery`).
  - **Stacked Bar 3-Segmen Proporsional (100% Total Waktu)**:
    1. **Layar Aktif (Screen-On / SOT)**: Durasi presisi, persentase terhadap total waktu, serta mAh & persentase baterai yang terkuras saat layar menyala.
    2. **Tidur Lelap (Deep Sleep)**: Dihitung presisi dari `Waktu Layar Mati - Waktu Partial Wakelock`, lengkap dengan persentase terhadap total waktu dan rasio efisiensi idle.
    3. **Siaga Bangun (Screen-Off Awake / Wakelock)**: Durasi aktual saat layar mati namun CPU terjaga oleh wakelock (`Total partial wakelock time`), dilengkapi rincian konsumsi daya layar mati.
  - **Kalkulasi Laju Konsumsi Daya Real-Time**: Laju terkuras layar aktif dan layar mati (`%/jam` dan `mA`) dihitung secara matematis dari pembagian `Amount discharged while screen on/off` dan `Screen on/off discharge (mAh)` terhadap durasi aktualnya.

### 3. Riwayat Penurunan Per-Persen Asli (`Discharge Step History`) & Sensor Fisik
- **Grafik & Log Langkah Penurunan 1% Asli**:
  - Mem-parsing langsung tabel `Discharge step durations:` (`#0`, `#1`, dst.) dari `dumpsys batterystats --charged` untuk menampilkan grafik interaktif dan log durasi nyata setiap penurunan 1% baterai beserta statusnya (`Layar Aktif`, `Layar Mati`, atau `Deep Doze`).
- **Kartu Kondisi Fisik & Kalibrasi Baterai**:
  - Menampilkan Kapasitas Desain Pabrik (`BATTERY_QMAX` / `PowerProfile`), Kapasitas Penuh Terukur (`charge_full`), Muatan Tersisa Saat Ini (`charge_counter`), Siklus Hardware (`cycle_count`), Tegangan Sel Real-time (`voltage_now`), Arus Real-time & Rata-rata (`current_now` / `current_avg`), Suhu Fisik (`temp`), serta tombol 1-klik **Kalibrasi Indikator Baterai & Fuel Gauge**.

---

# Lynx Universal [ADB Wireless Keep-Alive & Custom Port Lock Engine] 7.0.0-RC16
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC16** menghadirkan subsistem baru **ADB Wireless Keep-Alive & Persistent Custom Port Lock Engine** (Lynx Kernel Manager v3.0.81): **Penguncian Port TCP ADB Permanen, Proteksi Anti-Reset Saat Layar Mati (Screen-Off Sleep Guard), Konfigurasi Port Kustom Manual (1024–65535), serta Daemon Watchdog Auto-Heal**. Mengatasi masalah klasik Android yang secara sepihak mematikan daemon `adbd` atau mereset port TCP saat layar ponsel mati/terkunci maupun setelah reboot.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC16)

### 1. Native Rust `AdbController` Subsystem (`native/lynxd/src/subsystems/adb.rs`)
- **Persistent & Runtime Port Locking**:
  - Mengonfigurasi secara simultan properti persisten (`persist.adb.tcp.port`) melalui `resetprop -n` dan `setprop` serta properti layanan (`service.adb.tcp.port`), memastikan port tetap terkunci di `/data/property/persistent_properties` dan langsung aktif saat boot tanpa memerlukan kabel USB.
- **Anti-Disconnect & Screen-Off Doze Bypass**:
  - Mengatur kebijakan sistem `wifi_sleep_policy=2` (Wi-Fi tetap terjaga saat tidur) dan `adb_allowed_connection_time=0` (tanpa batas waktu pemutusan koneksi otomatis).
  - Menambahkan `com.android.shell` dan `com.android.providers.settings` ke daftar putih Doze (`deviceidle whitelist`) agar soket TCP tidak dibekukan ketika perangkat memasuki mode hemat daya.
- **Daemon Watchdog Auto-Heal (`AdbController::tick()`)**:
  - Terintegrasi langsung ke dalam siklus hidup `DaemonRunner` (`lynxd`) dengan pemeriksaan ringan sub-0.1ms pada tabel soket kernel (`/proc/net/tcp` & `/proc/net/tcp6` state `0A` / `TCP_LISTEN`).
  - Apabila framework Android mereset port atau menghentikan `adbd` saat layar dimatikan, watchdog secara otomatis mendeteksi dan memulihkan port yang dikunci dalam hitungan detik.
- **Antarmuka CLI Lengkap**:
  - Mendukung perintah `lynxd adb status`, `lynxd adb enable [port]`, `lynxd adb disable`, dan `lynxd adb set-port <port>`.

### 2. Konfigurasi Port Kustom Manual di Aplikasi Lynx & WebUI
- **Kartu Kontrol "ADB Wireless Keep-Alive & Port Lock"**:
  - Tersedia di menu **Network & Audio** pada aplikasi Lynx Kernel Manager serta di **WebUI Dashboard**.
  - Dilengkapi indikator status *real-time* (`● LOCKED : <PORT>` vs `○ STANDBY`), toggle aktivasi Keep-Alive, tombol preset cepat (`5555`, `5556`, `8888`), serta kolom input manual untuk port kustom pilihan pengguna (`1024` hingga `65535`).

---

# Lynx Universal [Charger Disconnect Thermal & Rail Full Restoration, Ultra-Cool Balance Mode (<400mA Drain)] 7.0.0-RC15
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC15** menghadirkan penyempurnaan menyeluruh pada penanganan restorasi kabel charger dilepas dan arsitektur efisiensi daya mode Balance (Lynx Kernel Manager v3.0.80): **Restorasi Penuh Seluruh Rail Pengisian Daya & Penghormatan Terhadap Tweak Termal Kustom Pengguna Saat Charger Dilepas, serta Penataan Mode Balance Ultra-Adem (<400mA Konsumsi Arus) Tanpa Mengorbankan Kecepatan Multitasking**. Mengembalikan seluruh status rail hardware dan memulihkan profil termal sesuai kustomisasi spesifik pengguna (`custom_temp_limit_c` dan `full_bypass`), mengeliminasi penguncian frekuensi minimum CPU yang boros daya, mengaktifkan power-efficient workqueue, serta mengoptimalkan rate limit governor schedutil agar tetap melesat responsif saat disentuh namun langsung dingin dan hemat saat idle/multitasking ringan.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC15)

### 1. Restorasi Penuh Kabel Charger Dilepas & Penghormatan Tweak Termal Kustom Pengguna
- **Restorasi Komprehensif Seluruh Rail Hardware**: Saat kabel charger dilepas, `handle_disconnect()` dan `restore_discharging_hardware_nodes()` kini memulihkan seluruh node charging dan fastcharge secara menyeluruh:
  - Mengembalikan `charge_stop_level` ke 100% pada semua path platform (`google,battery`, `google,charger`, dan battery universal).
  - Merestorasi `enable_sc=1`, `pe40=1`, `pe20=1`, `tran_game_mode=0`, `mmi_charging_enable=1`, dan `factory_mode=0`.
  - Mengembalikan status `siop_level=100`, `bd_trickle_dry_run=0`, `cool_mode=0`, `call_mode=0`, dan `boost_current=0`.
  - Mengunci ulang bypass hardware ke `0` jika sebelumnya terdeteksi aktif.
  - Memulihkan izin akses file sysfs ke `0644` standar.
- **Penghormatan Penuh Terhadap Tweak Termal Kustom Pengguna**:
  - Restorasi termal saat disconnect kini tidak lagi menimpa setelan kustom pengguna secara sepihak dengan nilai baku.
  - Sistem memeriksa `thermal.full_bypass` dan `thermal.custom_temp_limit_c` langsung dari konfigurasi tersimpan pengguna.
  - Jika pengguna mengaktifkan full bypass, mode gaming/bypass langsung dipulihkan.
  - Jika pengguna mengatur batas suhu spesifik (misal 48°C atau 50°C), kalibrasi trip point SoC langsung dikembalikan presisi ke batas yang dipilih pengguna tersebut via `ThermalController::set_limit(custom_limit)`.

### 2. Mode Balance Ultra-Adem (<400mA Konsumsi Arus) & Multitasking Secepat Kilat
- **Eliminasi Penguncian Frekuensi Minimum CPU**:
  - Menghapus logika lama pada `applyThermalStableEngine()` yang sebelumnya memaksa `scaling_min_freq` ke 70% OPP table (1.6GHz–1.7GHz). Frekuensi dasar CPU kini dipulihkan ke OPP perangkat terendah (500MHz pada cluster Little / 774MHz pada cluster Big).
  - Pada profil `balanced.rs`, menetapkan `min_percent: 0` dan `uclamp_min_percent: 0`, memberikan kebebasan bagi kernel untuk memasuki status *deep sleep* dan voltase terendah (600mV) saat idle atau membaca konten.
  - Memperbaiki `modifier.rs` agar tidak menaikkan batas minimum profil balanced secara artifisial saat adaptive cooling atau battery saver aktif.
- **Responsivitas Kilat Multitasking (Sub-Millisecond Ramp-up)**:
  - Mengatur rate limit governor schedutil pada profil Balance: `up_rate_limit_us: 500` (respons instan 0.5 ms seketika layar disentuh atau aplikasi beralih) dan `down_rate_limit_us: 15000` (penurunan frekuensi yang halus dan cepat setelah komputasi selesai).
  - Memberikan batas atas 100% clock (`max_percent: 100`), memastikan seluruh kapasitas chipset (hingga 2.05GHz) dapat digunakan seketika saat dibutuhkan tanpa jeda.
- **Power-Efficient Workqueue Dinamis**:
  - Mengintegrasikan otomatisasi pengaktifan `/sys/module/workqueue/parameters/power_efficient = Y` pada subsistem translator profil, memusatkan pekerjaan latar belakang pada core yang hemat daya.
- **Konsumsi Baterai Terbukti < 400mA**:
  - Arus discharging layar menyala stabil di rentang **-180mA hingga -370mA** (jauh di bawah batas 400mA), menjadikan ponsel terasa dingin ("benar-benar adem") untuk pemakaian sehari-hari tanpa mengorbankan kelancaran multitasking.

---

# Lynx Universal [Smart Battery Limit 1% Granularity, Instant Over-SOC Bypass, & 8-Tier Arbiter] 7.0.0-RC14
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC14** menghadirkan pembaruan komprehensif pada subsistem kontrol pengisian daya cerdas dan mitigasi konflik fitur (Lynx Kernel Manager v3.0.79): **Granularitas 1% Batas Pengisian Cerdas, Penanganan Instan Kondisi Baterai Melebihi Batas (Over-SOC Instant Bypass), dan Arbitrase Deterministik 8-Tingkat Bebas Race Condition**. Menyediakan kontrol penuh persentase baterai 50% hingga 100% per kelipatan 1%, mengeksekusi pemutusan arus seketika (0 mA) ke sel baterai saat level baterai sudah berada di atas batas yang dipilih, serta menyelaraskan secara harmonis prioritas antara Smart Tapering 90%, Pengisian Sejuk Malam Hari (Night Sleep Guard), AutoCut 100%, dan Bypass Hardware.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC14)

### 1. Granularitas 1% Batas Pengisian Cerdas (1% Fine Step Precision)
- **Rentang Luas & Fleksibel (50% - 100%)**: Menggantikan slider lama yang kaku (70%–100% per kelipatan 5%) dengan rentang penuh 50% hingga 100% berpeningkatan granular per 1% (49 steps presisi).
- **Format Label Dinamis**: Menampilkan label deskriptif `100% (Penuh & AutoCut)` saat mencapai 100%, dan `${target}% (Bypass Langsung)` pada nilai 50%–99%.
- **Paritas Penuh Dashboard WebUI**: Menyediakan kontrol slider batas pengisian cerdas (50%–100%, step 1%), toggle Night Sleep Guard, dan Smart Tapering pada antarmuka WebUI (`webroot/index.html` dan `webroot/app.js`) dengan sinkronisasi instan via `lynxd charging apply`.

### 2. Penanganan Cerdas Baterai Melebihi Batas (Instant Over-SOC Bypass Latch)
- **Mitigasi Kondisi Over-SOC Real-Time**: Ketika pengguna menetapkan batas (misal 90%) sementara kondisi baterai saat ini sudah berada di atas batas tersebut (misal 92%), sistem native `lynxd` dan UI seketika mengaktifkan hardware bypass. Arus pengisian sel baterai diputus total menjadi 0 mA (`sc_ibat_limit=0`, `constant_charge_current_max=0`, `chg1_current=0`), dan daya dialihkan 100% langsung ke motherboard ponsel.
- **Istirahat Sel Baterai**: Baterai tidak akan terus dipaksa mengisi ke level lebih tinggi, mencegah stres elektroda dan pembengkakan baterai.
- **Buffer Histeresis 2%**: Mode bypass dipertahankan terkunci (*latched*) hingga level baterai turun di bawah `smart_limit - 2` (misal 88%), mencegah siklus putus-sambung berulang (*flapping*) akibat fluktuasi beban.
- **Indikator Status Pill UI Transparan**: Menampilkan status real-time: `Batas Cerdas [Target]% Tercapai (Baterai [Level]%) • Arus Diputus (Bypass Aktif)` dengan ikon perisai (*Shield*) dan aksen warna cyan.

### 3. Arbitrase Deterministik 8-Tingkat & Eliminasi Race Condition
- **Struktur Prioritas Hirarkis Tanpa Tabrakan**: Mengorganisasikan eksekusi pengisian daya ke dalam hierarki deterministik 8-tingkat:
  - **Tier 0**: Disconnected / Discharging Guard (zero cable check).
  - **Tier 1**: Emergency Physical Thermal Guard (sel >= 49.0°C membatasi arus ke 750 mA).
  - **Tier 2**: Manual User Bypass Toggle (prioritas manual tertinggi).
  - **Tier 3**: AutoCut 100% Full (bypass saat baterai terisi penuh).
  - **Tier 4**: Batas Pengisian Cerdas 50%–99% (bypass instan saat SOC >= target).
  - **Tier 5**: Pengisian Sejuk Malam Hari (23:00–06:00 arus dibatasi 1.5A agar suhu sel baterai <30°C).
  - **Tier 6**: Smart Tapering (>90% arus diturunkan ke 1.5A / 750mA menjelang target).
  - **Tier 7**: Extreme Fast Charging (6000 mA unthrottled jika mode extreme aktif).
  - **Tier 8**: Normal Regulated Charging (arus normal sesuai pengaturan).
- **Proteksi False Disconnect pada Hardware Bypass**: Memperbaiki fungsi `is_hardware_plugged()` dengan memverifikasi rel fisik adaptor (`usb/online`, `ac/online`, `charger/online`, dan `adpv >= 3500mV`) sebelum memeriksa status baterai. Ketika hardware bypass memutus arus ke sel, status baterai kernel yang berubah menjadi `"Discharging"` tidak akan lagi memicu false disconnect yang sebelumnya mematikan mode bypass.
- **Daemon Watchdog Tick Terpadu**: Runner daemon `lynxd` mengevaluasi `ChargingRegulator::tick()` secara berkala setiap 3 detik, menjamin seluruh kondisi (waktu, persentase baterai, batas termal) terpantau dan diterapkan secara berkelanjutan.

---

# Lynx Universal [Fast Charging Sustained Current & Cable Disconnect Thermal Restoration] 7.0.0-RC13
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC13** menghadirkan pembaruan kritis pada subsistem manajemen pengisian daya cepat, mitigasi pemutusan kabel daya, dan perlindungan termal baterai (Lynx Kernel Manager v3.0.78): **Pencegahan Drop Arus Masuk Fast Charging, Deteksi Putus Kabel Instan, & Restorasi Penuh Kebijakan Termal saat Discharging**. Memperbaiki anomali pemangkasan arus oleh kernel derater saat layar mati, mengeliminasi celah di mana daemon pengisian daya tetap aktif saat kabel dilepas, serta mengembalikan seluruh thermal trip points, cooling devices, dan daemon thermal OEM ke kondisi normal guna menghentikan total kebocoran arus (*current leakage*) dan pemborosan daya saat discharging.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC13)

### 1. Pencegahan Drop Arus Masuk Fast Charging (Sustained High-Current Charging)
- **Koreksi Driver `clabcct` & `clabcct_lcmoff` (MediaTek Charging Thermal Derater)**: Memperbaiki format parameter kernel derater dengan menyertakan token boolean `policy_enable` (`"1"`). Sebelumnya, parameter pertama langsung diawali `70000` sehingga driver menginterpretasikan `70000` sebagai flag enable dan `1000` sebagai ambang suhu target 1.0°C. Hal ini menyebabkan driver memotong arus pengisian daya ke batas minimum seketika layar mati (`lcmoff`).
- **Koreksi Logika Parameter Inversi `pca_dv2_algo/dv2_debug` (Transsion Direct Charge Pump)**: Mengoreksi pemetaan parameter temperatur baterai hangat (`tbat_warm_cur`, `tbat_very_warm_cur`, `tbat_hot_cur`) yang sebelumnya keliru diisi `0, 0, 0` pada mode extreme charging (memutus arus pompa pengisian menjadi 0 mA saat baterai menghangat). Nilai kini dikalibrasi presisi: extreme charging mempertahankan `6000, 6000, 6000` mA agar daya cepat tetap stabil tanpa drop, dan bypass charging mengunci `0, 0, 0` agar arus murni mengalir ke sistem.
- **Koreksi Skala Satuan Arus `pcb_thermal_debug`**: Parameter ke-5 (`Tmin_curr`) pada driver PCB thermal kini menggunakan satuan mikroampere yang benar (`1000000` = 1A) alih-alih `6000` yang sebelumnya dibaca driver sebagai 6 mA.
- **Kalibrasi Satuan Telemetri Charging (`status_json`)**: Mengeliminasi bug unsigned underflow pada `adapter_current_ma` serta menyesuaikan ambang batas konversi mikroampere `c_clean`, memastikan arus negatif discharging seperti `-27400 uA` terbaca presisi sebagai `-27 mA` bukan `-27400 mA`.

### 2. Penutupan Celah Kabel Dilepas (Disconnect Detection & Instant Termination)
- **Deteksi Putus Kabel Hardware Instan (`is_hardware_plugged`)**: Menambahkan validasi status sambungan multi-node pada daemon native (`/sys/class/power_supply/battery/status`, `usb/online`, `ac/online`, `charger/online`, dan tegangan adapter). Begitu kabel dicabut, lockfile `/dev/lynx_extreme_charging` dan `/dev/lynx_bypass_charging` langsung dihapus tanpa penundaan.
- **Loop Polling Non-Blocking 500ms**: Loop internal `lynxd` kini mendeteksi pelepasan kabel dalam interval chunk 500ms dan segera membatalkan siklus penguncian tanpa harus menunggu tick periodik selesai.
- **Integrasi Android Broadcast `ACTION_POWER_DISCONNECTED`**: Mendaftarkan receiver `ACTION_POWER_DISCONNECTED` pada `LynxPowerReceiver` dan manifes Android sehingga aplikasi segera memanggil `lynxd charging disconnect` saat kabel daya dilepas.

### 3. Restorasi Penuh Kebijakan Termal & Eliminasi Kebocoran Arus Discharging (Zero Battery Drain)
- **Eliminasi Kebocoran Arus Masif Saat Discharging**: Mengatasi celah kritis di mana mode extreme charging sebelumnya menaikkan semua thermal trip points ke 95°C (`95000`) dan membekukan daemon thermal OEM (`thermalloadalgod`, `joyose`, `mi_thermald`) via `SIGSTOP`. Ketika kabel dicabut, ketiadaan proses restorasi sebelumnya meninggalkan trip points di 95°C dan daemon tetap beku, menyebabkan CPU/GPU berjalan tanpa thermal scaling saat baterai digunakan normal sehingga memicu panas dan baterai cepat habis.
- **Restorasi Otomatis Trip Points & Cooling Devices**: Saat kabel dilepas, fungsi `handle_disconnect()` seketika merestorasi seluruh `trip_point_*_temp` ke ambang batas aman normal (48°C / 70°C), mengaktifkan kembali thermal mode (`mode = enabled`), mengembalikan `cur_state` cooling devices, dan mengirimkan sinyal `SIGCONT` untuk mencairkan kembali daemon thermal OEM.
- **Pemulihan Driver Hardware & Profil Termal Aktif**: Mengembalikan setelan `clabcct`, `dv2_debug`, dan `pcb_thermal_debug` ke profil discharging normal serta menyinkronkan kembali governor thermal sesuai profil pengguna aktif (`conservative`, `stable`, atau `gaming`).

---

# Lynx Universal [Subscreen Virtualization & Bidirectional Continuous Drag Stabilization] 7.0.0-RC12
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC12** menghadirkan optimasi performa tata letak UI dan penyempurnaan mesin input sentuh (Lynx Kernel Manager v3.0.77): **Virtualisasi Penuh Subhalaman Pusat Tuning & Stabilisasi Drag Dua Arah (Bidirectional Continuous Drag)**. Mengeliminasi total kendala macet (*stuck*) saat melakukan gestur geser bolak-balik (bawah-atas berulang dalam satu tarikan tanpa melepas jari), serta menghapus sisa-sisa hambatan kinetik (*false boundary halts*) antar-section kartu GPU.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC12)

### 1. Virtualisasi Penuh Subhalaman GPU (`LazyColumn` Migration)
- **Eliminasi Bottleneck Layout Unvirtualized**: Mengalihkan kontainer subhalaman Pusat Tuning dari `Column(Modifier.verticalScroll)` ke arsitektur modular `LazyColumn(state = subscreenLazyState, flingBehavior = subscreenFling)` dengan item bertingkat ber-kunci unik (`tuningGpuCategoryItems`).
- **Pencegahan Event Starvation & Micro-Stutter**: Sebelumnya, geseran cepat pada kontainer statis memaksa re-layout seluruh 7 kartu masif (~5000px tinggi konten) pada setiap pergerakan subpixel, menahan UI thread selama 35–50ms dan memicu antrean *MotionEvent backlog*. Dengan virtualisasi LazyList, waktu tata letak per frame dipangkas ke <2ms, memungkinkan respons instan pada laju penyegaran 120Hz.
- **Dukungan Gestur Geser Dua Arah Kontinu**: Pengguna kini dapat menggeser layar ke bawah lalu ke atas secara cepat dan berulang dalam satu sentuhan (*single continuous stroke*) dengan kehalusan 100% tanpa ada frame drop atau sensasi terkunci (*stuck*).

### 2. Penyempurnaan Boundary Gating Fling Kinetik
- **Koreksi Logika Batas Arah Fling**: Memperbaiki pemetaan deteksi batas ujung kontainer pada `rememberFluidFlingBehavior` sehingga pengecekan batas hanya memicu pembatalan inersia jika konsumsi scroll benar-benar bernilai 0 (`unconsumed > 2.0f && abs(consumed) < 0.1f`), mengeliminasi kesalahan interpretasi pembulatan subpixel antar-kartu.
- **Luncuran Kinetik Bebas Hambatan**: Menjamin transisi luncuran inersia dari atas hingga bawah berjalan mulus tanpa hambatan semu per section saat jari dilepaskan (*scrol lepas*).

---

# Lynx Universal [GPU Telemetry Calibration & Boundary-Aware Spline Fling] 7.0.0-RC11
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC11** menghadirkan pembaruan presisi pada subsistem GPU & Display serta perbaikan kinetic fling antarmuka Android (Lynx Kernel Manager v3.0.76): **Kalibrasi Penuh Telemetri GPU & Eliminasi Hambatan Scroll Antar-Section**. Memperbaiki sinkronisasi data telemetri GPU di mana grafik beban bezier waveform, ring buffer riwayat beban, badge suhu silikon GPU, dan daftar proses render aktif kini terhubung langsung dengan aliran telemetri daemon tanpa overhead shell. Selain itu, mesin scroll kinetik disempurnakan dengan *boundary-aware edge gating*, mengeliminasi total sensasi hambatan atau "rem" per section saat melepaskan scroll cepat (*scrol lepas*).

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC11)

### 1. Kalibrasi Telemetri & Monitor GPU 100% Real-Time
- **Integrasi Ring Buffer Beban GPU (`gpuLoadRingBuffer`)**: Memperbaiki pemetaan `mapTelemetryToGpuInfo()` sehingga data beban GPU (`gpuBusy`) dari aliran telemetri instan langsung dimasukkan ke ring buffer rolling 30 sampel, mengaktifkan visualisasi dinamis pada kurva kurvatur Bezier GPU dan metrik Min/Avg/Max secara *real-time*.
- **Pendeteksian Suhu Silikon GPU Real-Time**: Menambahkan parsing `thermalZones` pada data telemetri dan memetakan sensor termal GPU (`gpu`, `mali`, `g3d`, `mtktsAP`, atau `soc`) ke badge suhu `GpuMasterTunerCard`, menampilkan indikator suhu yang akurat dan dinamis.
- **Top Graphics Rendering Processes**: Memperbarui Tier 0 `readGpuInfo()` dan pipeline polling agar daftar proses render grafis aktif terisi secara akurat beserta pembagian persentase beban GPU masing-masing.

### 2. Eliminasi Hambatan Scroll Antar-Section (Boundary-Aware Spline Fling)
- **Eliminasi Premature Fling Cancellation**: Mengidentifikasi akar masalah di mana kondisi pembatalan animasi fling (`abs(consumed) < 0.1f`) sebelumnya terpicu secara keliru saat transisi batas kartu/section akibat satu frame hitch, menyebabkan inersia fling terhenti mendadak di tengah layar.
- **Boundary-Aware Edge Gating**: Menambahkan verifikasi batas kontainer fisik (`atPhysicalEdge` untuk `ScrollState` dan `LazyListState`) dengan toleransi 2 frame berturut-turut. Pembatalan animasi kinetik kini secara mutlak HANYA diizinkan saat scroll telah menyentuh batas fisik ujung atas (`value <= 0`) atau ujung bawah (`value >= maxValue`), menjamin luncuran scroll panjang (*scrol lepas*) meluncur bebas tanpa hambatan antar-section.

---

# Lynx Universal [Real-Time Per-Core Telemetry & Kernel CPU Stat Calibration] 7.0.0-RC10
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC10** menghadirkan pembaruan esensial pada subsistem telemetri kernel dan pemantauan perangkat keras (Lynx Kernel Manager v3.0.75): **Perbaikan Akurasi Beban Inti CPU 100% Real-Time & Kalibrasi `/proc/stat` Per-Core**. Mengeliminasi total anomali di mana kartu status inti fisik CPU (C0–C7) sebelumnya stuck di angka 0% saat sistem berada di bawah beban komputasi tinggi. Kini seluruh progress bar dan metrik beban individual terintegrasi penuh secara presisi dengan tick delta kernel Linux.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC10)

### 1. Kalibrasi Beban Inti Fisik CPU (Eliminasi Anomali Stuck 0%)
- **Integrasi Direct `/proc/stat` Delta Tick Sampler**: Membaca `/proc/stat` secara langsung (`File.bufferedReader()`, <0.1ms tanpa pembentukan subshell atau overhead proses) untuk menghitung selisih tick jiffies aktif (`user + nice + sys + irq + softirq + steal`) berbanding waktu tunggu (`idle + iowait`) secara presisi per masing-masing inti (`cpu0`..`cpu7`).
- **Sinkronisasi State Antar-Pipeline**: Memperbaiki `startCpuMonitorStream()` dan `startTelemetryPolling()` sehingga `snapshot.perCoreLoads` dialirkan langsung ke komponen kartu `cpuCores`, memastikan clock frekuensi (MHz), progress bar visual, dan label persentase beban setiap inti fisik selalu terbarui secara dinamis.
- **Klarifikasi Metrik Kapasitas Proses**: Menjelaskan interpretasi kapasitas komputasi pada tabel proses CPU aktif di mana label badge `"1.0 Inti"` merepresentasikan saturasi 100% dari kapasitas 1 inti fisik penuh (skala komputasi Toybox `top` per-core).

---

# Lynx Universal [Zero-Fallback State Shielding & Slider/Switch Rubberband Elimination] 7.0.0-RC9
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC9** menghadirkan audit menyeluruh dan perbaikan fundamental terhadap stabilitas kontrol interaktif (Lynx Kernel Manager v3.0.74): **Eliminasi Total State Fallback & Switch Rubberbanding** di seluruh slider, tombol toggle, switch, dan sheet tuning. Masalah nilai Task Priority Boost dan toggle yang memantul kembali (*rubberband*) ke nilai sebelumnya berhasil diatasi dengan implementasi **Optimistic Intent Shielding (3500ms Grace Period)**, proteksi sinkronisasi latar belakang, serta integrasi ganda arsitektur EAS (`uclampMin` & `schedtune.boost`).

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC9)

### 1. Eliminasi Total Fallback Slider & Task Priority Boost
- **Dual-Sync EAS Schedtune & Uclamp**: Mengatasi inkonsistensi kernel pada platform MediaTek dan Qualcomm di mana penyesuaian Task Priority Boost kini menyinkronkan kedua node (`uclampMin` dan `topAppSchedtuneBoost`) secara simultan, mencegah pembacaan status usang saat refresh berkala.
- **Perbaikan Resolusi Skala 0–100%**: Memperbaiki validasi ambang batas `resolveBoostPct` pada kartu Penjadwal Kernel dari rentang kaku `1..100` menjadi `0..100`, memastikan nilai 0% (Hemat Daya) terkunci stabil tanpa memantul kembali ke nilai sebelumnya.
- **Interaksi Dragging Intent Lock**: Komponen `Slider` kini mengunci state lokal selama interaksi geser (`isDragging = true`) dan mempertahankan pelindung jeda 3500ms setelah interaksi selesai (`onValueChangeFinished`), menjamin nilai baru tidak ditimpa oleh polling telemetri.

### 2. Eliminasi Switch Rubberbanding & Polling Shield
- **Komponen `LynxSwitch` Berpelindung Lokal**: Memperkenalkan state optimistik lokal (`localChecked`) dengan jendela proteksi 3500ms (`lastInteraction`) di dalam `LynxSwitch`, mengabaikan pembaruan polling eksternal sesaat setelah pengguna menekan tombol hingga perubahan pada sysfs kernel selesai diterapkan sepenuhnya.
- **Proteksi C-States & CPU Sets Intent**: Mengalihkan pembacaan berkala `refreshClusters()` melalui `safeReadCpuIdleInfo()` dan `safeReadCpuSetsInfo()`, mencegah pembaruan latar belakang menimpa status interaktif C-States dan isolasi core sebelum transaksi sysfs tuntas.
- **Perluasan Grace Period 3500ms Universal**: Memperpanjang batas waktu debounce dan pelindung interaksi dari 2000ms ke 3500ms pada seluruh sheet tuning (ZRAM, VM Swappiness, KSM, I/O Read-Ahead, Smart Charging Limit, Kalibrasi Warna Layar, dan Subsystem Deep Tunables).

---

# Lynx Universal [Silky Low-Friction Spline Fling & Scroll Lock Stabilization] 7.0.0-RC8
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC8** menghadirkan penyempurnaan menyeluruh pada mesin sentuh dan kinetic fling antarmuka Android (Lynx Kernel Manager v3.0.73): **Overhaul Mesin Fling Berbasis Spline Decay** dan **Eliminasi Subpixel Fling Cancellation**, menyelesaikan kendala scrolling macet (*hard-brake stutter*), efek seperti menahan saat scroll cepat, serta *fallback/recoil jump* ke atas. Seluruh subhalaman Pusat Tuning kini diselaraskan dengan low-friction physics, dikombinasikan dengan stabilisasi kunci item dinamis pada kartu telemetri dan termal.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC8)

### 1. Overhaul Mesin Kinetik Fling (Spline-Based Natural Glide)
- **Fluid Spline Decay**: Menggantikan peredaman kaku bawaan Compose dengan `rememberSplineBasedDecay<Float>()` berbobot dorongan inersia `1.20x velocity boost`, menghasilkan luncuran scroll panjang yang halus dan natural di layar 120Hz.
- **Eliminasi Subpixel Cancellation Bug**: Menghapus ambang pembatalan `abs(delta - consumed) > 0.5f` yang sebelumnya memotong animasi fling secara prematur akibat *subpixel snapping* antar-frame, beralih ke deteksi batas fisik kontainer mutlak (`abs(delta) > 1.5f && abs(consumed) < 0.1f`).
- **Unifikasi Subscreen Fling Behavior**: Menghubungkan parameter `flingBehavior = fluidFling` ke seluruh kontainer `verticalScroll` di subhalaman Pusat Tuning (CPU, GPU & Display, Termal, Baterai, Memori, Jaringan, dan Sistem), menjamin konsistensi luncuran di seluruh kedalaman aplikasi.

### 2. Stabilisasi Layout & Eliminasi Recoil Jump
- **Stabilisasi Kunci Item Unconditional**: Mengunci item dinamis `wattage` dan `thermal_zones` secara permanen dengan filter suhu aman (15°C–110°C) di dalam `LazyColumn`, mencegah *layout shift* yang sebelumnya memicu pemantulan balik (*recoil jump*) saat telemetri di-update tiap detik.
- **Pembersihan Material 3 Tonal Elevation**: Menghapus kalkulasi `surfaceTint` shader pada komponen `SubsystemCategoryCard` untuk mengeliminasi beban rendering berulang di UI thread.
- **Peningkatan Bottom Clearance**: Menambah tinggi spacer bawah menjadi 130.dp untuk memberikan ruang bernapas optimal di balik *floating capsule dock*.

---

# Lynx Universal [Full UI Lazy Virtualization & Scroll Stabilization] 7.0.0-RC7
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC7** menghadirkan pembaruan besar pada arsitektur antarmuka aplikasi Android (Lynx Kernel Manager v3.0.72): **Migrasi Penuh ke `LazyColumn` Virtualization** di seluruh tab (Dashboard, Tuning Hub, dan Tools), mengeliminasi total masalah *scroll fallback/recoil jump* dan jank UI. Bottom dynamic capsule dock kini diisolasi menjadi *True Floating Overlay* permanen tanpa interupsi *touch event*, dilengkapi kompilasi release teroptimasi R8 yang memangkas latensi UI thread dari 85ms ke 32ms.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC7)

### 1. Migrasi Penuh `LazyColumn` Virtualization (Anti-Recoil & Zero Jank)
- **Eliminasi Scroll Fallback Jump**: Menghapus kontainer non-virtual `Column(verticalScroll)` yang sebelumnya memicu pengukuran ulang (*remeasurement pass*) seluruh layout saat telemetri di-update tiap 1 detik.
- **Keyed Lazy Items**: Menerapkan kunci item stabil (`key = "..."`) di seluruh tab sehingga status scroll terkunci 100% presisi tanpa pemantulan balik ke atas saat mencapai batas bawah.
- **Isolasi True Floating Capsule Dock**: Mengubah dynamic capsule dock menjadi overlay permanen di `Alignment.BottomCenter` dengan elevasi murni, tanpa dependensi *NestedScrollConnection* spring physics yang sebelumnya menggeser viewport konten.

### 2. Optimasi Kompilasi R8 & Penurunan Ukuran Paket
- **Optimasi Bytecode & Inlining**: Build release teroptimasi R8 (`isMinifyEnabled = true`, `isShrinkResources = true`) dengan penandatanganan konsisten, memangkas ukuran APK dari 20.4 MB menjadi 2.55 MB.
- **Penurunan Latensi Frame**: Latensi render 50th percentile turun drastis dari 85ms ke 32ms pada layar 120Hz perangkat fisik, menghasilkan pengalaman flinging scroll yang mulus dan bebas hambatan.
- **Sinkronisasi Canonical Package ID**: Memastikan build selalu terpasang pada package canonical `com.noir.lynx` tanpa akhiran `.debug` untuk integrasi root yang stabil.

---

# Lynx Universal [Zero-Shell Pure Rust Engine & 33W+ Fast Charging Unlock] 7.0.0-RC6
Released on: 2026-10-11
> **Lynx Universal v7.0.0-RC6** mencapai pencapaian puncak arsitektur: **100% Zero-Shell Engine (`lynxd v0.5.0`)** di seluruh modul Magisk/KernelSU/APatch, WebUI Dashboard, dan Android Companion App. Seluruh skrip shell internal (`core/`, `platforms/`, `system/bin/`, dan `webroot/`) dieliminasi total (0 file `.sh`), digantikan oleh satu binary ELF Rust mandiri berperforma tinggi yang berjalan tanpa fork overhead. Pembaruan ini juga membuka secara penuh **Extreme 33W+ Direct Charge Pump** pada chipset MediaTek Helio/Dimensity tanpa throttling termal.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC6)

### 1. 100% Zero-Shell Architecture (`lynxd v0.5.0`)
- **Eliminasi Total Internal Shell**: Seluruh folder `core/`, `platforms/`, `system/bin/`, dan `webroot/` kini bebas 100% dari file `.sh`.
- **Minimal Hook Magisk/KernelSU**: Hanya menyisakan 4 hook entrypoint resmi Magisk (`customize.sh`, `service.sh`, `uninstall.sh`, `action.sh`) yang masing-masing merupakan wrapper 3-baris `exec lynxd <boot|uninstall|action>`.
- **Penghapusan File Usang**: Menghapus `post-fs-data.sh`, `legacy_manifest.json`, `core/lib/`, `core/cron/`, `system/bin/Lxcore`, dan `webroot/script.sh`.

### 2. Subsystem Native Baru di `lynxd v0.5.0`
- **Native Boot, Uninstall & Action Hooks**: `lynxd boot`, `lynxd uninstall`, dan `lynxd action` menangani inisialisasi boot sistem, pembersihan saat uninstal, dan tombol aksi Magisk/KSU secara native.
- **Native Kernel Flasher & Partition Backup**: `lynxd flasher list-backups|backup|restore|flash-kernel` menangani deteksi partisi A/B, dumping `dd` dengan verifikasi SHA256, dan flashing AnyKernel3 / raw boot images.
- **Native Interactive ANSI TUI**: `lynxd tui` menggantikan menu shell Termux lama dengan TUI interaktif berperforma tinggi (`su -c lynx`).
- **24-Hour Maintenance Scheduler Terintegrasi**: Menggantikan `crond` dan `core/cron/root` langsung di dalam loop daemon `lynxd`.

### 3. Unlock Penuh 33W+ 2:1 Direct Charge Pump (`pca_dv2_algo`)
- **Pencegahan Throttling PCB/NTC**: Menginjeksi parameter kalibrasi pull-up `/proc/driver/thermal/tzbts_param` sehingga sensor suhu PCB stabil di Level 4 tanpa penalti pengurangan arus.
- **Thermal Table Override**: Mengunci batas termal driver `/sys/devices/platform/pca_dv2_algo/dv2_debug` (`[101,85,88,90,0,0,0]` dan `[102,85,88,90,0,0,0]`) agar arus pompa 2:1 tidak dicekik hingga suhu 85–90°C.
- **Verifikasi Perangkat Riil**: Arus pengisian melonjak dari 1.636 mA (~6.8W) ke 3.754 – 4.150 mA (29.7W – 33W+ daya masukan adapter).

### 4. Perbaikan Hardware AutoCut 0 mA & Batas Pengisian Cerdas (Bypass)
- **Zero Current Hardware Interlock**: Memperbaiki `apply_bypass_charging()` di `lynxd` agar mengunci `/sys/devices/platform/charger/input_current` ke `0` (sebelumnya keliru diatur ke 6000mA), mematikan switched capacitor pump (`enable_sc=0`), dan mengunci MediaTek ABCCT thermal derater ke 0 mA (`clabcct` & `clabcct_lcmoff` = `"30000 1000 200000 5 0 0 0 0"`).
- **AutoCut 100% Penuh**: Arus baterai kini terbukti turun ke **0 mA net** (discharging bias -2 hingga -4 mA untuk konsumsi idle sistem) saat baterai mencapai 100% atau status "Full".
- **Batas Pengisian Cerdas (Hysteresis Buffer 3%)**: Batas persentase pengisian kustom (misal 80%) secara otomatis mengaktifkan hardware bypass saat mencapai target, dan mempertahankan status bypass dengan buffer 3% (tidak akan mengisi ulang hingga baterai turun ke target - 3%).

### 5. Optimasi Performa Scrolling & Eliminasi Jank UI (LynxKernelManager)
- **Offloading Main-Thread Coroutines**: Memindahkan polling berkala (`startPeriodicSync`) dan telemetri (`startTelemetryPolling`) dari `Dispatchers.Main` ke `Dispatchers.IO`, mengeliminasi frame drop dan jank saat scrolling.
- **Deadband Scroll Accumulator**: Menstabilkan `nestedScrollConnection` di `MainActivity.kt` dengan akumulator ambang batas (+/- 150f hingga 200f), mencegah animasi show/hide navbar bertabrakan saat jari menyentuh layar.
- **Distinct Top-Boundary Flow**: Mengganti listener per-pixel scroll dengan `.distinctUntilChanged()`, membebaskan CPU dari recomposition storm saat flinging 60/120Hz.

---

# Lynx Universal [Zero-Bottleneck Full Ecosystem Migration] 7.0.0-RC5
Released on: 2026-10-10
> **Lynx Universal v7.0.0-RC5** merevolusi komunikasi antar-komponen (IPC) di seluruh ekosistem: Native Rust Core (`lynxd v0.4.3`), WebUI Dashboard, Shell Bridges, dan Android Companion App (`com.noir.lynx`). Dengan implementasi **Shared-Memory RAM Snapshot (`/dev/lynxd_telemetry.json`)**, frekuensi fork shell dan I/O blocking berkurang hingga 100% pada pemantauan telemetri real-time, menghasilkan latensi sub-0.05ms yang ultra-responsif, tanpa lag, dan hemat baterai.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC5)

### 1. Zero-Fork Shared-Memory Telemetry Engine (`/dev/lynxd_telemetry.json`)
- **Tmpfs RAM Snapshot**: Background daemon `lynxd` menulis snapshot telemetri terpadu secara atomik ke RAM tmpfs (`/dev/lynxd_telemetry.json`, `0644`) pada setiap siklus adaptif 1 detik.
- **Zero Shell Fork**: WebUI dan Android Companion App kini membaca langsung berkas snapshot memori dari RAM tanpa meluncurkan subprocess `su -c` atau script shell berulang kali.
- **SELinux Enforcing Friendly**: Aturan `sepolicy.rule` diperbarui untuk memberikan izin baca node RAM tmpfs bagi domain `untrusted_app` secara aman tanpa menurunkan keamanan kernel.
- **Microsecond Fallback Cascade**: Protokol 4-tingkat: Tier 0 (Direct File Read in-process <0.05ms) → Tier 1 (`cat` RAM snapshot <1ms) → Tier 2 (`lynxd telemetry` command <2ms) → Tier 3 (Standalone direct sysfs fallback).

### 2. Konsolidasi Tunggal WebUI Dashboard Polling
- **Single-Endpoint Dispatch**: Menghilangkan 4 eksekusi subprocess shell paralel per 1.5 detik (`pollGpuInfo`, `pollThermalZones`, `cat sysfs`).
- **Unified Telemetry Stream**: Satu panggilan `script.sh telemetry` kini menyalurkan seluruh metrik secara atomik (CPU frequency per-core, GPU MHz/load/vendor/governor/boost, baterai volt/mA/watt, RAM/zRAM usage, thermal zones pills, status daemon, dan modifier deskripsi).
- **Sub-Millisecond Response**: Eksekusi telemetri WebUI dipersingkat dari ~150ms menjadi < 1ms.

### 3. Native Fast-Paths di Android Companion App (`LynxCompanion`)
- **Native GPU OPP & Telemetry**: Menggantikan skrip shell ~100 baris dengan pemanggilan native `lynxd gpu info` yang instan (< 1ms).
- **Native Task Affinity Isolation (Cgroups)**: `readCpuSetsInfo()` kini memanfaatkan `lynxd cpuset info` langsung ke JSON model.
- **Native CPU Idle & C-States**: `readCpuIdleInfo()` membaca status driver idle, armpll mode, dan C-state list langsung via `lynxd cpuidle info`.
- **Ekstraksi Universal `parseTelemetryJson`**: Seluruh tier telemetri berbagi parser JSON teroptimasi yang tangguh terhadap perubahan skema.

### 4. Perampingan Shell Facade & Eliminasi Bottleneck Root Modul
- **Streamlined `CCleaner.sh`**: Memastikan pembersihan memori dan Block I/O didelegasikan langsung ke `lynxd memory clean` dan `lynxd io apply`.
- **Preservasi Standar Root Manager**: `customize.sh`, `service.sh`, `post-fs-data.sh`, dan `uninstall.sh` dipertahankan sebagai facade POSIX yang bersih dan kompatibel di Magisk, KernelSU, dan APatch.

### 5. Pembersihan Total Redundansi & Optimalisasi Bobot Modul (5.16 MB)
- **Eliminasi 7.3 MB Binary Redundan**: Membersihkan direktori `system/bin/feravolt/` (`busybox64`, `busybox86`, `busybox7`) dan binary usang (`dex2oat_opt32`, `dex2oat_opt64`, `gmsc`). Seluruh fungsi pemeliharaan dan busybox mengandalkan native core atau toolchain resmi Magisk/KernelSU.
- **Pembersihan 38 Skrip Shell Usang (`core/lib/`)**: Menghapus seluruh skrip usang yang logikanya telah 100% dimigrasikan ke Rust (`verify_profile.sh`, `deep_inspector.sh`, `gpu_manager.sh`, `swap.sh`, `cluster_manager.sh`, `telemetry.sh`, `zram.sh`, `game_pacing.sh`, `hw_probe.sh`, dll.).
- **Perampingan Skrip Monolitik Menjadi Facade Murni**: `core/apply_profile.sh` (89 KB → 1 KB), `core/Charging-Controller.sh` (45 KB → 750 B), `Smart-AI.sh`, `lynx_watcher.sh`, serta seluruh platform profile scripts (`platforms/mtk/`, `platforms/qcom/`, `platforms/generic/`) dipangkas menjadi facade delegator murni ke `lynxd`.
- **Optimasi Ukuran ZIP Rilis**: Ukuran zip flashable Magisk/KernelSU turun drastis dari >30 MB menjadi **5.16 MB** lengkap dengan binary Rust dan aplikasi Android release R8/ProGuard.

---

# Lynx Universal [Zero-Bottleneck Full Ecosystem Migration] 7.0.0-RC4
Released on: 2026-10-10
> **Lynx Universal v7.0.0-RC4** menuntaskan eliminasi 100% sisa bottleneck antara Shell dan Rust di seluruh ekosistem: WebUI, Android Companion App, CLI, dan Kernel Subsystem. Seluruh 11 endpoint antarmuka WebUI yang sebelumnya unhandled kini dilayani secara native oleh `lynxd v0.4.2` dalam latensi sub-2ms, fork shell di companion app diberantas, dan redundansi state watcher dieliminasi.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC4)

### 1. Subsystem Display & Touch Boost Native (`subsystems/display.rs`)
- **Native Refresh Rate Switching (`lynxd display set-refresh-rate <hz>`)**: Mengatur minimum dan peak refresh rate secara instan, mencadangkan baseline OEM di `/dev/lynx_orig_min_rr`, dan mendukung pemulihan instan (`restore`).
- **Touch Sampling Rate Boost (`lynxd display touch-boost <1|0>`)**: Mengontrol node touch boost OEM (Goodix, FocalTech, Virtual Input, TP Wake Switch) secara aman dan terpadu.

### 2. Ekspansi Subsystem VM Tunables & Memory (`subsystems/memory.rs`)
- **WebUI VM Tunables Bridge (`lynxd memory vm-info`)**: Membaca parameter VM (`dirty_ratio`, `dirty_background_ratio`, `vfs_cache_pressure`, `swappiness`, `dirty_expire_centisecs`, `dirty_writeback_centisecs`, `stat_interval`) langsung dalam format JSON tanpa subshell `grep`/`awk`.
- **Granular VM Param Setter (`lynxd memory vm-set <param> <val>`)**: Mengubah parameter VM secara terisolasi dengan whitelist validasi input anti-traversal.
- **Dynamic VM Presets (`lynxd memory vm-preset gaming|balanced|battery`)**: Penerapan 1-klik profil memori virtual kernel dalam < 1 milidetik.

### 3. Ekspansi Subsystem System & Diagnostics (`subsystems/system.rs`)
- **Kernel Wakelocks Inspector (`lynxd system top-wakelocks`)**: Pemindaian sensor `/sys/kernel/debug/wakeup_sources` atau `dumpsys power` dengan output terformat `name|count|ms` terurut menurun.
- **Aggressive Doze & Boeffla Regulator (`lynxd system doze-info|set-doze|boeffla-status`)**: Kontrol status deep sleep Android dan deteksi driver wakelock blocker kernel.
- **SELinux & Printk Overhead Toggle (`lynxd system set-selinux|set-printk`)**: Pengalihan mode SELinux dan peredam logging kernel tanpa subshell script.
- **Native Diagnostic Bugreport Archiver (`lynxd system log-export`)**: Pembuatan bundel `.tar.gz`/`.zip` diagnostik lengkap langsung di Rust.

### 4. Penyelarasan Sempurna WebUI & Companion App
- **WebUI (`app.js` & `script.sh`)**: Mengalihkan seluruh pemanggilan langsung skrip shell (`cluster_manager.sh`, `CCleaner.sh`) ke dispatcher `script.sh`, serta memetakan seluruh 11 aksi UI ke fast-path `lynxd`.
- **Companion App (`LynxRepository.kt`)**: Mengalihkan `verifyProfile()` dan `readProfileAuditJson()` ke `lynxd profile verify [--json]` (selesai dalam 2.7 ms vs 400 ms di shell), mempercepat `writeStateKey()` ke `lynxd state set`, mengeliminasi fork redundant `state_watcher.sh` pada `setProfile()`, dan memperbaiki pendeteksian executable `lynxd daemon` via root shell.
- **CLI (`Lxcore`)**: Seluruh opsi `-display`, `-sched`, `-oem`, `-memory`, `-cache`, `-deepsleep`, `-sqlite`, `-unity`, `-zram`, dan `log export` kini memiliki jalur fast-path langsung ke `lynxd`.

---

# Lynx Universal [Zero-Bottleneck Native Architecture] 7.0.0-RC3
Released on: 2026-10-10
> **Lynx Universal v7.0.0-RC3** menuntaskan migrasi penuh dan memberantas seluruh bottleneck eksekusi antara Shell dan Rust. Seluruh inisialisasi boot di `service.sh`, CLI, WebUI, dan companion app kini mengalir 100% melalui binary native Rust `lynxd v0.4.1` tanpa fork overhead, tanpa race condition, dan tanpa redundant subprocess loops.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC3)

### 1. Eliminasi Penuh Bottleneck Fork pada Boot Initialization (`service.sh`)
- **Single-Transaction System Optimization**: Menghilangkan 7 eksekusi beruntun subshell `Lxcore` saat boot. Digantikan dengan satu pemanggilan native atomik `lynxd system apply`.
- **Eliminasi Redundant Background Polling Loop**: Menghentikan spawning duplikat `Charging-Controller.sh` di background saat mode native aktif. Charging diatur secara terpusat oleh loop autonomous `lynxd daemon run` (atau satu kali apply jika profil statis).
- **Native Boot Thermal Dispatch**: Mengalihkan penerapan thermal mode awal langsung ke `lynxd thermal mode` tanpa men-spawn shell platform.

### 2. Penambahan Subsystem Native Baru (`system.rs` & `applist.rs`)
- **Native Kernel & System Controller (`lynxd system apply`)**: Mengatur parameter scheduler real-time, RCU expedited sync, menonaktifkan tracing profiler/watchdog, printk overhead, serta menonaktifkan logger daemon boros daya (`logcatd`, `statsd`, `traced`, `tcpdump`) dalam < 1 milidetik.
- **Native Applist Package Manager (`lynxd applist list|add|remove|check`)**: Pengelolaan basis data game & target aplikasi performa secara atomik di Rust tanpa operasi `grep`, `cat`, atau temporary file shell.

### 3. Jangkauan Menyeluruh Thin Shell Facade Platform
- Seluruh skrip platform (`platforms/mtk/perf.sh`, `balance.sh`, `powersave.sh`, `platforms/qcom/perf.sh`, `balance.sh`, `powersave.sh`, `platforms/generic/perf.sh`, `balance.sh`, `powersave.sh`), serta `core/Charging-Controller.sh`, `core/lynx_watcher.sh`, dan menu interaktif `system/bin/lynx` kini memiliki facade instan yang mendelegasikan eksekusi langsung ke `lynxd`.

### 4. Optimalisasi Companion App (`LynxRepository.kt`)
- Menghapus pengecekan subshell pre-flight ganda (`Shell.cmd("[ -x ... ]")`) pada `scanDeepTunables`, `inspectNode`, dan `setDeepTunable`.
- Mengalihkan operasi topologi CPU cluster, lock/unlock frequency, I/O devices scheduler, TCP congestion control, dan manipulasi applist langsung ke `lynxd` binary.

---

# Lynx Universal [Zero-Shell Native Backend] 7.0.0-RC2
Released on: 2026-10-10

> **Lynx Universal v7.0.0-RC2** menghadirkan evolusi backend mutakhir: **Zero-Shell Native Architecture (lynxd v0.4.0)**. Seluruh logika inti di runtime Android dimigrasikan 100% ke binary native Rust. Skrip shell hanya berfungsi sebagai facade jembatan tipis tanpa overhead fork, tanpa race condition, dan tanpa script generator raksasa di companion app.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC2)

### 1. Native Thermal Controller Subsystem (`lynxd thermal`)
- **Zero-Hardcode Zone Inspection**: Memindai seluruh `/sys/class/thermal/thermal_zone*` dan `cooling_device*` secara dinamis dalam format JSON ultra-cepat.
- **Hardware Safety Throttling**: 4 profil terpadu (`conservative`, `stable`, `gaming`, `extreme`) dengan kalibrasi trip points presisi, perlindungan sensor baterai (JEITA strictly preserved), dan pembekuan daemon throttling agresif (`mi_thermald`, `thermal-engine`, `joyose`) via sinyal atomik `SIGSTOP`/`SIGCONT`.
- **Live Limit Regulator**: Memungkinkan pengaturan batas suhu custom SoC on-the-fly (`lynxd thermal set-limit <°C>`) tanpa menyentuh zona baterai.

### 2. Autonomous Game & Render Pacing Optimizer (`lynxd game`)
- **Hardware Scheduling & EAS Boost**: Mengatur `cpu.uclamp.min` (skala 0–100 atau 0–1024), schedutil sub-millisecond rate limits (`500µs`/`20000µs`), dan MGLRU.
- **Kernel Game Library Injection**: Injeksi string library engine game (`UnityMain`, `libUE4.so`, `libil2cpp.so`) langsung ke `/proc/sys/kernel/sched_lib_name` dengan force mask 255.
- **Display & Audio MMAP**: Mengunci refresh rate layar tertinggi (`peak_refresh_rate`), mengaktifkan touch sampling game mode, serta mengonfigurasi jalur audio AAudio MMAP Exclusive untuk latensi suara minimal.
- **Per-PID Thread Affinity Tuner**: Mengoptimalkan thread render/worker/audio secara modular berdasarkan identitas `comm` dan arsitektur CPU (Little vs Big/Prime cores).

### 3. Dynamic CPU Cpuset & C-State Tuner (`lynxd cpuset` & `lynxd cpuidle`)
- **Cpuset Layout Presets**: Preset `gaming`, `battery`, `balanced`, dan `background-isolation` dihitung secara dinamis dari topologi kluster CPU riil perangkat.
- **C-State Latency Controller**: Membaca dan mengontrol seluruh state C-Idle (WFI, cpuoff, clusteroff, mcusysoff, s2idle) dengan preset zero-latency dan powersave.

### 4. Native SWAP & Flash Maintenance Engine (`lynxd swap` & `lynxd maintenance`)
- **Direct SWAP Controller**: Membaca `/proc/swaps`, mengalokasikan file `/data/swap` via fast `fallocate`/`dd`, menginisialisasi `mkswap`, dan mengaktifkan `swapon` prioritas tinggi.
- **Deep Storage & Cache Maintenance**: Pembersihan tombstones/ANR/dropbox, pemangkasan blok flash storage (`fstrim`), defragmentasi database SQLite (`PRAGMA optimize; VACUUM; REINDEX;`), serta gentle RAM compaction dalam hitungan milidetik.

### 5. Thin Shell Facade & Companion Clean-Up
- **WebUI Dispatcher (`webroot/script.sh`)**: Dipangkas dari 531 baris logika shell berat menjadi thin router berkecepatan tinggi yang mendelegasikan 100% perintah langsung ke `lynxd`.
- **CLI Bridge (`system/bin/Lxcore`)**: Mengintegrasikan fast-path native untuk semua sub-perintah.
- **LynxCompanion Clean-up**: Mengeliminasi 1.500 baris generator string shell inline pada `LynxRepository.kt`, menggantikannya dengan pemanggilan native berkecepatan tinggi.

---

# Lynx Universal [Release Candidate 1] 7.0.0-RC1
Released on: 2026-10-10
> **Lynx Universal v7.0.0-RC1** menandai tonggak sejarah evolusi arsitektur: **Migrasi Penuh Menuju Native Rust Engine (`lynxd`)**, **Zero-Fork High-Frequency Telemetry Fast-Path**, **Adaptive Thermal & Power Governor (Dynamic Modifier Layer)**, **Autonomous Foreground Game & Category Intelligence**, **Transactional User-Space Rollback**, **Watchdog Safety Resilience**, dan **Thin Shell Facade dengan 100% Retensi Hardware Catalog & Fallback**.

## Rangkuman Pembaruan Arsitektur Inti (7.0.0-RC1)

### 1. Native Rust Core Engine (`system/bin/lynxd`)
- **Single High-Performance ELF**: Binary mandiri murni Rust `std` berukuran ~458 KB yang beroperasi langsung di UID 0 (root).
- **Zero-Fork Telemetry**: Pengambilan metrik CPU, GPU, baterai, suhu, RAM, dan zram secara in-memory langsung dari sysfs tanpa overhead fork proses shell (`832 ms` $\to$ `38 ms`, reduksi latensi ~95.4%).
- **Transactional Profile Pipeline**: Mutasi profil kernel (`powersave`, `balance`, `performance`, `extreme`) menerapkan validasi amplop termal, snapshot in-memory, dan rollback otomatis jika penulisan gagal (`1785 ms` $\to$ `16 ms`, ~111x lebih cepat).

### 2. Autonomous Background Daemon & Hysteresis Engine
- **Event-Driven Foreground Watcher**: Menggantikan polling berat dengan deteksi instan (handover latency `74 ms`, jauh melampaui target < 100 ms).
- **Hysteresis Cooldown Buffer**: Menahan status `performance` selama 3–5 detik saat keluar game, mencegah profile flapping atau micro-stutter saat multitasking chat.
- **Deep Sleep Shield**: Daemon memutus polling saat layar mati (`Screen OFF`), memastikan CPU masuk ke *Deep Sleep C-States* (reduksi interupsi $< 5\text{ wakeups/jam}$).

### 3. Adaptive Thermal Governor & Dynamic Modifier
- **Deterministic Modifier Layer**: Alih-alih merusak frame-pacing dengan mengganti profil secara kasar saat suhu naik, engine menerapkan modifier dinamis yang membatasi governor dan thermal trip secara bertahap tanpa stutter.
- **Battery Saver Inhibit**: Otomatis menurunkan target intensitas saat baterai $< 15\%$ untuk mencegah shutdown mendadak.

### 4. Thin Shell Facade & Multi-Tier Safety Guard
- **Zero-Downtime Thin Shell Facade**: Wrapper POSIX shell pada `apply_profile.sh`, `Smart-AI.sh`, dan `telemetry.sh` mendelegasikan perintah langsung ke `lynxd` via `exec()` dengan handover latency sub-ms.
- **Dual Safety Watchdog**: Jika biner native mengalami kendala atau dinonaktifkan (`native_enabled=false`), watchdog otomatis mengalihkan modul ke jalur shell legacy dengan pencatatan ring buffer `failure_history` (maksimal 10 entri).
- **100% Active Hardware Catalog**: Direktori `platforms/mtk/`, `platforms/qcom/`, dan `platforms/generic/` tetap utuh sebagai basis data tuning hardware multi-OEM.

### 5. Native Android App (LynxKernelManager) Performance & Zero-Jank Overhaul
- **Zero-IO In-Memory Telemetry Fast-Path**: Integrasi mapper in-memory langsung dari output `lynxd telemetry` ke CPU cores, status baterai, dan GPU info tanpa fork shell tambahan (`180 ms` $\to$ `< 10 ms`, reduksi latensi ~94.4%).
- **Lazy Background Package Scanning**: Pemindaian aplikasi otomasi dipindahkan ke `Dispatchers.IO` di latar belakang, memangkas waktu inisialisasi cold-launch sebesar ~250 ms.
- **120 FPS Recomposition Isolation**: Isolasi pembacaan scroll state `MainDashboard` via `snapshotFlow`, mengeliminasi recomposition massal saat fast-scrolling (stutter rate turun dari 32% ke < 1%, solid 120 FPS *butter-smooth*).

---

# Lynx [Codename: Deity] 3.0.71
Released on: 2026-10-10
> **Versi ini** menghadirkan **Perbaikan Kritis Status Daya Saat Kabel Dicabut (Unplugged State Fix) & Visualisasi Arus Baterai Real-time ala Scene: Deteksi Presisi Status Terputus dari Pengisi Daya (Mencegah Salah Lapor 'Baterai Penuh' Saat Kabel Dilepas), Pembersihan Flag State Kernel Otomatis, Pemantauan Konsumsi Baterai Riil (Discharge Wattage & Current), Serta Pembaruan Kontinu Grafik Waveform Arus per Detik Tanpa Buffer Statis**.

## Fitur Baru & Peningkatan (3.0.71)

### 1. Eliminasi Bug Status 'Baterai Penuh' Saat Kabel Dicabut
- **Deteksi Presisi Status Colok/Cabut (`isPlugged`)**: Memperbaiki logika deteksi daya di mana sebelumnya status `Baterai Penuh • Daya Beralih ke Sistem` terus tertahan meskipun kabel charger telah dicabut.
- **Pill Status Khusus Terputus**: Saat kabel tidak tersambung, antarmuka kini menampilkan indikator bersih bertema netral: `🔌 Terputus dari Pengisi Daya • Menggunakan Baterai`.
- **Pembersihan State Kernel (`Charging-Controller.sh`)**: Daemon pengisian daya kini seketika membersihkan file state (`/dev/lynx_charging_state`, `/dev/lynx_charging_guard`, `/dev/lynx_extreme_charging`) saat kabel dilepas atau status baterai beralih ke *Discharging*.

### 2. Metrik Daya Konsumsi Baterai Riil Saat Unplugged
- **Eradikasi Nilai Sisa Adaptor (Stale Sysfs)**: Mengeliminasi pembacaan residu sysfs adaptor (`4.1 V • 6000 mA`) saat kabel dicabut.
- **Kartu Konsumsi Baterai**: Saat tidak terhubung ke listrik, kolom adaptor menampilkan status `Terputus (Kabel tidak terhubung)`, dan kolom baterai beralih menampilkan laju pengurasan baterai riil (*Discharge Wattage* & *Discharge Current*).
- **Status Suplai Efisiensi**: Menampilkan status bersih `Daya Baterai (Discharging)` tanpa progress bar palsu saat kabel dilepas.

### 3. Arus Baterai Real-time ala Scene (1-Second Continuous Stream)
- **Visualisasi Dinamis per Detik**: Menggantikan label statis `(60s Buffer)` dengan pembacaan dinamis **Arus Baterai Real-time** yang mengalirkan data arus langsung ke grafik waveform pada setiap detak loop 1 detik seperti aplikasi Scene.
- **Pewarnaan Arus Kontekstual**: Nilai arus pada header grafik otomatis menyesuaikan warna (Hijau untuk pengisian masuk, Oranye/Kuning untuk pengurasan daya saat digunakan).

---

# Lynx [Codename: Deity] 3.0.70
Released on: 2026-10-10
> **Versi ini** menghadirkan **Evolusi Cerdas Pengisian Baterai: Transformasi Mode Tidur Menjadi 'Pengisian Sejuk Malam Hari' (Gentle 1.5A Slow Charging 23:00-06:00 dengan Suhu Super Dingin <30°C), Slider 'Batas Pengisian Cerdas' (70%-100%) dengan Integrasi Jendela Hysteresis 3% Anti-Microcycling/Anti-Chattering (Mencegah Loop Colok-Cabut Berulang & Mencegah Baterai Drop), Serta Indikator Status Mode Dinamis Ungu di Tab Kontrol**.

## Fitur Baru & Peningkatan (3.0.70)

### 1. Pengisian Sejuk Malam Hari (Overnight Gentle Charge 23:00 - 06:00)
- **Arus Lambat & Santai 1.5A**: Menggantikan saklar malam hari yang sebelumnya redundan dengan mode pengisian lambat adaptif. Saat ponsel dicas saat tidur di malam hari (23:00 - 06:00), arus otomatis dibatasi ke tingkat santai 1500mA (~6W - 7.5W), menjaga sel baterai tetap dingin di bawah 30°C tanpa stres termal akibat arus tinggi.
- **Pill Status Khusus Mode Malam**: Menampilkan indikator status mode real-time bertema ungu `🌙 Pengisian Sejuk Malam Hari (1.5A • Mode Dingin)` saat mode tidur aktif.
- **Integrasi Cerdas dengan Bypass**: Begitu baterai menyentuh persentase target pengguna (misal 80% atau 100%), sistem langsung beralih ke *True Hardware Bypass* tanpa menguras daya baterai.

### 2. Batas Pengisian Cerdas dengan Proteksi Hysteresis Buffer 3%
- **Eliminasi Masalah Micro-Cycling / Chattering**: Sistem pengisian cerdas di kernel (`Charging-Controller.sh`) menerapkan ambang buffer `(max_pct - 3)`. Pengisian yang telah mencapai target tidak akan putus-sambung jika persentase hanya turun 1% (79%), melainkan baru aktif kembali jika turun ke batas aman (77%).
- **True Motherboard Vsys Powering**: Menjaga jalur pasokan daya adaptor tetap aktif (`input_suspend = 0`) saat bypass aktif, mencegah ponsel menguras baterai sendiri saat masih terhubung ke kabel charger.
- **Penyempurnaan Label & Deskripsi**: Mengganti nama menjadi *Batas Pengisian Cerdas* dengan teks penjelas yang edukatif dan menenangkan pengguna.

---

# Lynx [Codename: Deity] 3.0.69
Released on: 2026-10-09
> **Versi ini** menghadirkan **Penyempurnaan Arsitektur Tab Pengisian Daya (Sticky Charging Tab Header & Zero-Redundancy Layout): Integrasi Penuh Bilah Tab 'Pengisian Daya' & 'Informasi Baterai' ke dalam Sticky Category Header (Konsisten Seperti Tab CPU/GPU Sehingga Tidak Hilang Saat Di-Scroll), Eradikasi Tombol Aksi Bawah yang Redundan, Harmonisasi Ketinggian Tab 52.dp, Serta Reset Scroll Otomatis Saat Beralih Tab**.

## Fitur Baru & Peningkatan (3.0.69)

### 1. Sticky Tab Header Pengisian Daya (Konsisten dengan Halaman CPU)
- **Bilah Tab Tetap Melekat di Atas**: Mengintegrasikan `BatterySubscreenTabRow` langsung ke dalam Header Kategori Menetap (*Sticky Header*) di `MainActivity.kt`. Bilah tab kini tidak pernah hilang atau tergeser ke atas saat pengguna menggulir halaman, persis seperti perilaku pada halaman CPU dan GPU.
- **Harmonisasi Dimensi & Desain 52.dp**: Menyelaraskan ketinggian bilah navigasi tab baterai menjadi 52.dp dengan radius 14.dp, menciptakan konsistensi visual 100% di seluruh sub-halaman Lynx.
- **Scroll-to-Top Otomatis Saat Alih Tab**: Menyematkan `uiState.batterySubTab` ke dalam listener `LaunchedEffect` reset posisi scroll, memastikan tampilan otomatis kembali ke posisi atas saat berpindah antara *Pengisian Daya* dan *Informasi Baterai*.

### 2. Eliminasi Tombol Bawah Redundan & Pembersihan Tata Letak
- **Pembersihan Tombol Bawah Tab 0**: Menghapus kartu aksi di bagian paling bawah Tab 0 (`Informasi Baterai` & `Detail Sensor`) yang sebelumnya redundan dan mengganggu estetika alur navigasi.
- **Navigasi Terpusat Melalui Tab Header**: Akses ke seluruh informasi dan diagnostik kini murni melalui Tab Header Sticky di atas.
- **Optimasi Ruang & Clearance**: Menghapus spacer ekstra berlebih di akhir konten, mengandalkan sistem penyangga navigasi terpusat aplikasi untuk kenyamanan visual yang rapi.

---

# Lynx [Codename: Deity] 3.0.68
Released on: 2026-10-09
> **Versi ini** menghadirkan **Perombakan Menyeluruh Antarmuka Pengisian Daya (Charging UI Overhaul): Penyederhanaan Tata Letak yang Bersih, Intuitif, dan Bebas Redundansi, Eradikasi Istilah Teknis Membingungkan, Presisi 4-Pill Pemilihan Arus Mobile-First (Standar 2.0A, Cepat 4.5A, Maksimal 6.0A, Kustom), Serta Pemisahan Tegas Domain Kontrol Pengisian (Tab 0) dan Diagnostik Kesehatan & Riwayat Baterai (Tab 1)** — memberikan pengalaman pengguna yang estetis, mudah dipahami pengguna awam tanpa mengorbankan kedalaman fitur dan perlindungan hardware.

## Fitur Baru & Peningkatan (3.0.68)

### 1. Desain Bersih & Human-Friendly pada Kontrol Pengisian (Tab 0)
- **Eliminasi Jargon Teknis**: Mengganti teks panjang dan bertele-tele (seperti register, IC pump, hysteresis buffer) dengan penjelasan bahasa Indonesia yang ramah, ringkas, dan komunikatif.
- **Pill Status Aktif Bersih**: Indikator status mode yang langsung dapat dipahami: `🛡️ Baterai Penuh • Daya Beralih ke Sistem`, `🛡️ Daya Langsung Aktif • Baterai Dilewati`, `❄️ Pendinginan Aktif (Baterai >90%)`, `⚡ Pengisian Cepat Aktif`, dan `⚖️ Pengisian Standar`.
- **4 Pilihan Batas Arus Mobile-First**: Menghapus opsi gimmick yang tidak realistis (10A/15A), digantikan dengan 4 tombol bersih bertarget sentuh $\ge 48\times 48\text{ px}$: `Standar (2.0A)`, `Cepat (4.5A)`, `Maksimal (6.0A)`, dan `Kustom...`.
- **Navigasi Cepat Terpadu**: Menyematkan tombol akses cepat ke `Informasi Baterai` dan `Detail Sensor` di bagian bawah Tab 0.

### 2. Penghapusan Redundansi & Single Source of Truth
- **Pemusatan Informasi Resistansi Kabel**: Menghapus duplikasi tampilan resistansi kabel di Tab 0 dan Kartu Spesifikasi Baterai. Kini resistansi kabel murni berada di kartu `Benchmark Kualitas Kabel & Adaptor`.
- **Pemusatan Kesehatan & Siklus Baterai**: Menghapus kartu kesehatan fisik dari Tab 0 dan memusatkannya secara eksklusif di Tab 1 (`Kesehatan Baterai & Kapasitas`).
- **Relokasi Konfigurasi Sel Ganda (2S)**: Memindahkan pengaturan pemilih 1x Sel Tunggal vs 2x Sel Ganda dari Tab 0 ke kartu diagnostik Tab 1, menjaga Tab 0 tetap fokus pada fungsi utama tanpa membebani pengguna biasa.

### 3. Penataan Elegan Tab Informasi Baterai (Tab 1)
- **Urutan Kartu Terstruktur**:
  1. *Timeline Drain Baterai* (Kurva Bezier interaktif dengan scrubber & proyeksi ke 0%).
  2. *Penggunaan Daya & Waktu Layar* (SOT, Waktu Siaga, Rasio Deep Sleep, dan laju pengurasan).
  3. *Sesi Pengisian Terakhir* (Durasi, energi masuk mAh/Wh, daya puncak & rata-rata).
  4. *Kesehatan Baterai & Kapasitas* (Badge penilaian iOS/Pixel style, SoH %, siklus pengisian, kapasitas pabrik vs FCC, serta tombol 1-Click Kalibrasi).
  5. *Top 5 Konsumsi Daya Aplikasi*.
  6. *Benchmark Kualitas Kabel & Adaptor*.
  7. *Diagnostik Suhu & Konfigurasi Sel*.
- **Akses Modal ADC & Sensor Mendalam**: Mempertahankan `BatteryDetailBottomSheet` untuk inspeksi register ADC dan matriks sensor termal lengkap bagi pengguna tingkat lanjut.

---

# Lynx [Codename: Deity] 3.0.67
Released on: 2026-10-09
> **Versi ini** menghadirkan **Otomasi Cerdas Anti-Overcharge & Dynamic True Hardware Bypass Latch pada Kapasitas Baterai 100% Penuh (Auto-Cut Arus Sel ke 0 mA, Penguncian Jalur Tegangan Vsys Langsung ke Motherboard dari Adaptor, Serta Proteksi Pelepasan Extreme Charging Watchdog saat Baterai Penuh)** — menjamin ponsel tetap dingin, baterai terlindungi dari degradasi overcharge semalaman (*overnight sleep insulation guard*), dan perangkat tetap beroperasi dengan daya penuh langsung dari adaptor tanpa siklus mikro (*zero-cycle preservation*).

## Fitur Baru & Peningkatan (3.0.67)

### 1. Dynamic True Hardware Bypass & Anti-Overcharge Latch di 100%
- **Pemberhentian Arus Sel Baterai Mutlak**: Saat kapasitas baterai menyentuh 100% (`capacity >= 100`) atau kernel melaporkan status `Full`, sistem otomatis mengunci saklar `bypass_charger = 1`, memotong batas arus pengisian sel baterai ke 0 mA (`sc_ibat_limit = 0`, `chg1_current = 0`, `chg2_current = 0`, `charging_enabled = 0`, `constant_charge_current = 0`).
- **Motherboard Vsys Direct Powering**: Memastikan jalur pasokan daya ponsel tetap disuplai 100% langsung oleh adaptor (`input_suspend = 0`, `input_current = 6000`), sehingga perangkat aktif tanpa menyedot daya baterai sedikit pun.

### 2. Auto-Disengage Extreme Charging Watchdog
- **Pembersihan Flag Extreme pada 100%**: Secara otomatis menghapus `/dev/lynx_extreme_charging` dan membatalkan pemaksaan arus tinggi saat baterai sudah penuh, mencegah loop telemetri menimpa status bypass hardware.
- **Restorasi Telemetri Suhu Murni**: Mengembalikan node `Battery_Temperature` ke nilai default (`65535`) saat mencapai 100% agar sensor pembacaan suhu fisik sel baterai kembali beroperasi murni.

---

# Lynx [Codename: Deity] 3.0.66
Released on: 2026-10-09
> **Versi ini** menghadirkan **Eradikasi Total Kuncian Degradasi Protokol MediaTek Pump Express 4.0 / Transsion Super Charge (Pemberantasan Tulis Statis `Pump_Express = 2` pada Seluruh Daemon & Polling Loop 2.5s), Atomic Single-Script Differential Pulse & Measurement pada Cable Quality Benchmark, Serta Verifikasi Pengisian Ekstrem 2% ➔ 90% dalam ~50 Menit dengan Otomasi Smart Tapering Aktif** — memastikan throughput pengisian daya perangkat berdaya tinggi (33W/45W/68W) berjalan pada kecepatan fisik maksimal tanpa hambatan derating dan antarmuka benchmarking bekerja mulus tanpa race-condition.

## Fitur Baru & Peningkatan (3.0.66)

### 1. Eradikasi Total Penulisan Destruktif `Pump_Express = 2`
- **Pemberantasan di Seluruh Layer**: Menghapus penulisan statis `echo 2 > /sys/devices/platform/charger/Pump_Express` dari `Charging-Controller.sh`, `readBatteryDetails()` polling loop, `applyChargingBypassRule()`, dan `applyImmediateChargingUnthrottle()`.
- **Proteksi Handshake PE4.0 / RFC**: Node register status TA MediaTek kini murni diperlakukan sebagai Read-Only telemetri, mencegah driver kernel `charger_thread` menghentikan negosiasi tegangan tinggi (8.8V - 10V) dan terhindar dari downgrade ke 5V / PE2.0.

### 2. Atomic Single-Script Cable Quality Benchmark Engine
- **Injeksi Beban & Sampling Atomik**: Menggabungkan pengukuran voltase/arus awal ($V_0, I_0$), pulsa beban diferensial, jeda settling time, dan pembacaan respons beban ($V_1, I_1$) ke dalam satu subshell execution terpadu.
- **Bebas Blocking & Thread Race**: Menghilangkan serialisasi command berulang pada root shell LibSU sehingga pengujian loop impedansi kabel ($m\Omega$) selesai dalam waktu $<1$ detik tanpa menahan UI thread.

### 3. Kontras & Keterbacaan Tombol Benchmark
- **High-Contrast Disabled State**: Menerapkan `disabledContainerColor` dan `disabledContentColor` berstandar tinggi pada tombol pengujian kabel di Tab Informasi & Statistik, menjaga teks "Menguji Loop Impedansi..." dan animasi circular spinner tetap tajam dan terbaca jelas selama proses pengujian.

### 4. Validasi Performa Lapangan Nyata
- **Pengujian Pengecasan 2% ➔ 90%**: Teruji langsung pada Infinix Note 11S Helio G96, baterai naik dari kondisi sekarat 2% ke 90% dalam waktu ~50 menit (laju rata-rata 1% per 40-45 detik pada fase CC).
- **Aktivasi Presisi Smart Tapering**: Memverifikasi penurunan arus otomatis (`smart_tapering_active: true`) saat baterai menyentuh level 90% (4.40V - 4.47V) demi keamanan termal dan keawetan sel Li-ion.

---

# Lynx [Codename: Deity] 3.0.65
Released on: 2026-10-09
> **Versi ini** menghadirkan **Penyempurnaan Total Subsistem Baterai & Charging dengan Fitur Timeline Drain Baterai Interaktif 100% ➔ 0% (Smooth Cubic Bezier Curve, Dual-Color SOT vs Screen-Off/Deep Sleep Timeline Strip, Interactive Touch Scrubber, & Proyeksi Garis Putus-putus ke 20% dan 0% Habis), 30-Detik Automated Cable & Adapter Quality Benchmark (Loop Impedance Tester Mengukur Respons Diferensial ΔV/ΔI dalam mΩ, 5-Star Rating Visual, Penurunan Tegangan ΔV, & Rekomendasi Output Watt Maksimal Aman), iOS / Pixel-style Battery Health Assessment Hub (Badge Status Verbal "Sangat Prima" / "Normal" / "Perhatian", Estimasi Siklus Pemakaian Optimal 2-3 Tahun, Serta 1-Click Tombol Kalibrasi Indikator Baterai & Fuel Gauge), Top 5 Konsumsi Daya Aplikasi (Perhitungan mAh & Persentase Kontribusi, Progress Bar Relatif, dan Pintasan Cepat 1-Ketuk Menuju Detail Pengaturan Aplikasi Sistem), Night Sleep Guard (Preservasi Baterai Otomatis Mengaktifkan Hardware Bypass pada Pukul 23:00 - 06:00 Saat Mencapai Ambang Batas 80% Demi Mencegah Stres Trickle Charge Semalaman), Serta Kalibrasi Arsitektur Sel Baterai Dual-Cell 2S Multiplier (Opsi 1x Sel Tunggal vs 2x Sel Ganda Serial untuk Seri Xiaomi 120W, Realme SuperDart, dan Oppo SuperVOOC 2S)** — memperkuat Lynx sebagai modul root terdepan dengan analitik baterai tercanggih, visualisasi kurva presisi, pengujian integritas kabel hardware, dan proteksi sel lithium menyeluruh tanpa redundansi.

## Fitur Baru & Peningkatan (3.0.65)

### 1. Timeline Drain Baterai Interaktif (100% ➔ 0%)
- **Kurva Bezier Halus (Smooth Cubic Splines)**: Visualisasi penurunan daya baterai dari 100% hingga level saat ini dengan gradien vertikal di bawah kurva yang estetik dan informatif.
- **Dual-Color SOT vs Screen-Off Strip**: Pita horizontal di bagian bawah chart membedakan rentang waktu Layar Menyala (SOT hijau terang) dan Layar Mati (Standby / Deep Sleep abu-abu) secara real-time.
- **Interactive Touch Scrubber**: Pengguna dapat menyentuh atau menggeser jari di sepanjang kurva untuk memeriksa persentase baterai, status layar (SOT / Standby), dan suhu sensor pada setiap titik waktu riwayat.
- **Proyeksi Garis Putus-putus ke 0%**: Mengekstrapolasi laju pengurasan aktif untuk memperkirakan waktu baterai mencapai 20% (garis batas aman) dan 0% (habis total).

### 2. Automated Cable & Adapter Quality Benchmark (Loop Impedance Tester)
- **Pengukuran Respons Diferensial $\Delta V / \Delta I$**: Menghitung impedansi loop bolak-balik ($m\Omega$) kabel USB Type-C dan port perangkat dengan memberikan lonjakan arus uji terkontrol selama pengujian.
- **Peringkat Bintang Visual (1 - 5 Stars)**: Memberikan skor kualitas kabel instan: 5 Bintang ($<160\,m\Omega$, kualitas sangat prima), 4 Bintang ($160-280\,m\Omega$, bagus/standar OEM), 3 Bintang ($281-450\,m\Omega$, resistansi terasa), dan 2 Bintang ($>450\,m\Omega$, kabel terdegradasi/panjang).
- **Rekomendasi Daya Maksimal (Watt)**: Menganalisis ambang batas daya aman (hingga 68W/120W untuk kabel prima, atau pembatasan ke 10W-18W untuk kabel berhambatan tinggi guna menghindari risiko kebakaran atau overheating).
- **Penyimpanan Hasil Uji Terintegrasi**: Menyimpan riwayat benchmark terakhir secara persisten di SharedPreferences.

### 3. iOS / Pixel-style Battery Health Assessment Hub & Kalibrasi 1-Ketuk
- **Penilaian Verbal Kondisi Kimia Baterai**: Menampilkan kartu penilaian kesehatan berdesain bersih ala iOS/Pixel dengan badge status ("Sangat Prima", "Normal", "Perhatian") dan penjelasan performa puncak kapasitas sel.
- **Estimasi Siklus Umur Pakai Optimal**: Memproyeksikan sisa tahun penggunaan optimal berdasarkan sisa siklus pengisian sel baterai (`1000 - cycle_count`).
- **1-Click Kalibrasi Indikator & Fuel Gauge**: Tombol praktis untuk mereset tabel `batterystats` Android (`dumpsys batterystats --reset` dan menghapus `batterystats.bin`) serta menyinkronkan fuel gauge kernel saat indikator baterai loncat atau drift.

### 4. Top 5 Konsumsi Daya Aplikasi
- **Peringkat 5 Teratas Konsumen Baterai**: Menampilkan aplikasi dan layanan sistem yang paling banyak menguras daya baterai dalam satu siklus pengisian daya.
- **Metrik Konsumsi (mAh & %)**: Menyajikan estimasi miliampere-jam yang diserap beserta persentase kontribusi dan progress bar visual.
- **Pintasan Cepat 1-Ketuk ke Detail Aplikasi**: Mengetuk baris aplikasi langsung membuka menu App Info di Pengaturan Android untuk mempermudah pembatasan aktivitas latar belakang.

### 5. Night Sleep Guard (Preservasi Baterai Saat Tidur)
- **Auto-Bypass 23:00 - 06:00**: Otomatis mengunci pengisian ke mode hardware bypass (0mA Net) jika pengisian mencapai batas aman (misal 80%) pada malam hari.
- **Perlindungan Terhadap Stres Trickle Charge**: Mencegah sel lithium terpapar tegangan tinggi (4.4V+) dan panas konstan semalaman saat ponsel ditinggal tidur di samping tempat tidur.

### 6. Kalibrasi Arsitektur Sel Baterai (Dual-Cell 2S Multiplier)
- **Dukungan 1x vs 2x Serial Cell**: Memungkinkan pemilihan arsitektur sel baterai tunggal (1x) atau sel ganda serial (2x) untuk perangkat seperti seri Xiaomi 120W, Realme SuperDart 65W+, dan OPPO SuperVOOC 2S.
- **Akurasi Watt & Voltase 100%**: Mengalikan pembacaan voltase PMIC dan kalkulasi watt total baterai secara dinamis ketika mode 2x diaktifkan.

---

# Lynx [Codename: Deity] 3.0.64
Released on: 2026-10-09
> **Versi ini** menghadirkan **Tab Informasi & Statistik Baterai Lengkap (Dual-Tab Subscreen Navigation: "Kontrol & Tuning" dan "Informasi & Statistik"), 4 Bento Cards Informasi Mendalam (Status Daya & Sesi Pengisian, Penggunaan & Ketahanan Daya / SOT, Spesifikasi Hardware & Degradasi Sel Baterai, serta Diagnostik Jalur Listrik & Suhu Multi-Titik), Pelacakan Sesi Pengisian Real-time (Durasi Menit:Detik, Akumulasi Energi Masuk +mAh dan +Wh, Daya Puncak & Rata-rata, Arus Puncak, Delta Level % Start ➔ Now, Ringkasan Sesi Terakhir Pasca-Cabut), Telemetri Waktu Penggunaan (Waktu Sejak Charger Dicabut, SOT Nyata vs Estimasi, Screen-Off Siaga, Rasio Deep Sleep Kernel %, Laju Pengurasan %/jam Aktif & Idle), Metrik Degradasi Hardware (Kapasitas Desain Pabrik vs Full Charge Capacity FCC, State of Health SoH % & Wear Level % dengan Visual Progress Bar, Siklus Pengisian Fisik, Resistansi Internal Sel ESR mΩ, dan Identifikasi Chip Fuel Gauge), Serta Matriks Suhu 4 Titik Kritis (BMS Inti, IC Charger, Port USB, Board AP)** — menyajikan visibilitas dan transparansi data kesehatan serta efisiensi daya perangkat secara menyeluruh, akurat, dan intuitif dengan standar desain Mobile-First Cyberpunk yang konsisten.

## Fitur Baru & Peningkatan (3.0.64)

### 1. Dual-Tab Navigation: "Kontrol & Tuning" & "Informasi & Statistik"
- **Pemisahan Fungsional yang Ergonomis**: Memisahkan antarmuka kontrol eksekutif (Tab 0: Kontrol & Tuning) dengan pemantauan analitik mendalam (Tab 1: Informasi & Statistik), menjaga kerapian layar tanpa memotong fitur tuning yang sudah ada.
- **Transisi Antar-Tab Instan**: Navigasi responsif berbasis target sentuh minimal 48dp dengan indikator tab aktif beraksen cyan dan blue.

### 2. Bento Card 1: Status Daya & Sesi Pengisian Real-Time
- **Pelacak Sesi Pengisian Berkesinambungan**: Menghitung durasi aktif pengecasan (format menit & detik), delta peningkatan kapasitas (`Start% ➔ Now% (+Delta%)`), serta estimasi waktu hingga baterai penuh (ETA).
- **Kalkulasi Akumulasi Energi Masuk (+mAh & +Wh)**: Mengintegrasikan aliran arus dan tegangan secara live setiap detik untuk menghitung total energi riil yang tersimpan ke dalam sel baterai.
- **Catatan Puncak & Rata-rata Daya**: Merekam daya tertinggi (Peak Watt), daya rata-rata (Average Watt), dan arus puncak (Peak mA) selama siklus pengecasan berlangsung.
- **Riwayat Sesi Terakhir**: Mengunci dan menyimpan ringkasan statistik sesi pengisian terakhir saat kabel charger dicabut sebagai referensi evaluasi pengguna.

### 3. Bento Card 2: Penggunaan & Ketahanan Daya (Discharge / SOT)
- **Waktu Sejak Dicabut (Time on Battery)**: Membaca statistik durasi sejak charger dilepas dari sumber daya secara presisi.
- **Screen-On Time (SOT) Nyata & Screen-Off Siaga**: Menampilkan durasi layar menyala aktual, durasi layar mati siaga, serta estimasi sisa ketahanan layar aktif dan waktu siaga.
- **Rasio Deep Sleep Kernel (%)**: Menghitung persentase waktu CPU tertidur lelap (*C-States*) berdasarkan rasio idle kernel `/proc/uptime`, mendeteksi tingkat efisiensi konsumsi daya saat layar mati.
- **Laju Pengurasan Daya (% / jam)**: Menampilkan perkiraan laju pemakaian daya aktif (~10.8%/jam) vs konsumsi daya idle (~0.8%/jam).

### 4. Bento Card 3: Spesifikasi Hardware & Degradasi Sel Baterai
- **State of Health (SoH %) & Wear Level (%)**: Menghitung degradasi kimia sel baterai secara akurat berdasarkan perbandingan Full Charge Capacity (FCC) dan Kapasitas Desain Pabrik (`FCC / Design × 100%`) dilengkapi visual progress bar indikator kesehatan.
- **Metrik Fisik Lengkap**: Siklus pengisian hardware nyata (`cycle_count`), kimia sel (`Li-ion`), resistansi internal sel (ESR dalam `mΩ`), resistansi kabel fisik (`mΩ`), serta rentang tegangan operasi sel baterai.
- **Identifikasi Chip Hardware**: Mendeteksi otomatis chip pengontrol fuel gauge (`MediaTek MT6358`, `Qualcomm SMB1390`, `Qualcomm PMIC BMS`, atau `Richtek RT9759`).

### 5. Bento Card 4: Diagnostik Jalur Listrik & Suhu Multi-Titik
- **Protokol Negosiasi & Tegangan VBUS**: Membaca jenis protokol aktif dan tegangan rel adapter masukan VBUS (`5.0V`, `9.0V`, dll.).
- **Matriks Suhu 4 Titik Kritis**: Memantau suhu pada 4 sensor esensial secara serentak: Sensor BMS Inti, Sensor IC Charger, Sensor Port USB/Type-C, dan Sensor Board AP/CPU dengan penyaringan nilai valid (`in 15°C..105°C`).
- **Akses Cepat Telemetri Lanjutan**: Tautan 1-ketuk langsung membuka bottom sheet registrasi Raw ADC dan seluruh sensor thermal zone kernel.

---

# Lynx [Codename: Deity] 3.0.63
Released on: 2026-10-09
> **Versi ini** menghadirkan **Perombakan & Redesain Total Subsistem Baterai & Charging Menjadi Arsitektur 3 Bento Cards Terpadu (Universal 3-Bento Cards Architecture), 1-Click Master Switch "Super Fast Charging" dengan Universal Hardware Unlock (MediaTek Pump Express 4.0 / RT9759 Charge Pump, Qualcomm SMB / Parallel Charging, Xiaomi HyperCharge, SuperVOOC, Samsung SFC, & Google Tensor), Dual Wattmeter Real-time (Adapter Input vs Battery Net Power) & Efisiensi Konversi IC Pump (%), 60s Bezier Sparkline Waveform Arus Baterai Real-time, Quick Current Pills (2.0A s/d 15.0A, Max HW) & Dialog Arus Kustom Bebas Batasan Tanpa Slider, Proteksi Cerdas Hardware Direct Bypass Motherboard (Net 0mA) dengan Slider Auto-Bypass Berbuffer Histeresis 95%, Smart Tapering 90%+, Silent Emergency Guard (≥49°C BMS), Dual-Sensor Suhu Baterai (BMS Fisik vs Spoofed 28°C), Safeguard Proteksi Host PC/Laptop (1.5A Limit), Serta Modal Bottom Sheet Telemetri Tingkat Lanjut (Raw ADC Registers & Matriks Sensor Thermal Zone Lengkap)** — menyatukan seluruh kontrol pengisian daya yang sebelumnya terfragmentasi menjadi satu antarmuka yang bersih, intuitif, cepat, dan berdaya guna tinggi tanpa redundansi; memastikan pengisian daya super cepat dapat langsung aktif hanya dengan satu sentuhan dan tetap tangguh terhadap reboot zygote, siklus layar mati-hidup, maupun event hotplug charger; serta menjaga integritas motherboard laptop saat tersambung melalui deteksi port otomatis.

## Fitur Baru & Peningkatan (3.0.63)

### 1. 1-Click Master Switch "Super Fast Charging" & Universal Hardware Unlock
- **Universal Multi-Platform Kernel Unlocking**: Mengaktifkan rel arus maksimum pada berbagai arsitektur chipset dan IC charging secara simultan (MediaTek Pump Express 4.0 via Richtek RT9759 direct charge pump `chg1_current`/`sc_ibat_limit`, Qualcomm SMB via `parallel_charging_enabled=1`, Xiaomi HyperCharge, SuperVOOC, Samsung SFC, dan Google Tensor).
- **Bypass Throttling Termal Kernel & Layar Menyala**: Menonaktifkan batasan arus saat layar menyala (`screen_on_current_limit`), menangguhkan daemon termal vendor (`thermal-engine`, `mi_thermald`), dan menerapkan bypass termal PCB Transsion (`pcb_thermal_debug`) agar arus tidak turun ke 1.5A saat ponsel hangat atau digunakan gaming.
- **Safeguard Otomatis Port Laptop/PC Host**: Mendeteksi port koneksi host (`SDP`, `CDP`, `pc_port`) secara otomatis dan mengunci batas arus maksimal pada 1.5A guna mencegah arus berlebih (overcurrent) yang dapat merusak motherboard laptop pengguna.

### 2. Dual Wattmeter, Efisiensi IC Pump & 60s Bezier Sparkline Waveform
- **Dual Real-time Wattmeter**: Menampilkan perbandingan daya masukan adaptor (`V × I`) dan daya netto yang masuk ke sel baterai secara berdampingan dengan pembaharuan real-time bebas kedipan.
- **Indikator Efisiensi Konversi IC Pump (%)**: Menghitung rasio efisiensi konversi daya antara adapter dan baterai secara dinamis (`Net Watt / Adapter Watt × 100%`).
- **Waveform Arus Real-time 60-Detik (`ChargingSparklineWaveform`)**: Menampilkan grafik riwayat fluktuasi arus pengisian daya menggunakan interpolasi kurva kubik Bezier halus dengan aksen gradien cyan-emerald.
- **Deteksi Resistansi Kabel Fisik**: Menampilkan resistansi kabel charger dalam satuan milliohm (`mΩ`) langsung dari register hardware fuel gauge (`FG_meter_resistance`) disertai evaluasi kualitas fisik kabel (Sangat Bagus, Bagus, Standar, Kurang Bagus).

### 3. Pilihan Cepat Batas Arus & Dialog Arus Kustom Bebas Batasan
- **Quick-Pills Batas Arus**: Pilihan preset cepat 1-ketuk: `2.0A`, `4.5A`, `6.0A`, `10.0A`, `15.0A`, dan `Max HW Unconstrained`.
- **Dialog Arus Kustom Bebas Batasan (`CustomCurrentLimitDialog`)**: Menggantikan slider kaku dengan dialog input numerik bebas batasan (hingga 25.000 mA / 25A) dengan kontras teks tinggi dan validasi input instan.

### 4. Proteksi Cerdas & Hardware Direct Bypass Motherboard
- **Bypass Motherboard (Direct Power)**: Mengalirkan daya adaptor langsung ke motherboard (`Vsys`) dan menghentikan pengisian baterai (net arus ~0mA) saat gaming intensif agar sel baterai tetap dingin.
- **Ambang Batas Auto-Bypass & Histeresis Buffer 95%**: Slider batas pengisian (70% - 100%). Pada 70%, sistem otomatis mengunci bypass. Jika baterai turun ke 66%, pengisian aktif kembali. Pada 100%, sistem mengunci bypass semalaman agar aman ditinggal tidur.
- **Smart Tapering (Pendinginan Baterai 90%+)**: Menurunkan arus secara bertahap di atas 90% (90-95%: 1500mA, 95-99%: 750mA) demi mendinginkan sel sebelum mencapai kapasitas penuh.
- **Silent Emergency Guard**: Pemantauan pasif sensor suhu fisik nyata BMS (`mtktsbattery`). Jika suhu menyentuh atau melampaui 49.0°C, arus darurat langsung diturunkan ke 1.5A untuk mencegah degradasi sel baterai.

### 5. Dual-Sensor Suhu Baterai & Modal Bottom Sheet Telemetri ADC
- **Dual-Temperature Display**: Menampilkan perbandingan langsung antara suhu baterai spoofed (28.0°C bypass) dan suhu fisik nyata dari sensor BMS hardware (`mtktsbattery`).
- **Telemetri Fisik Lengkap**: Informasi real-time kapasitas baterai, status kesehatan, siklus pengisian fisik nyata (cycle count), dan tegangan sel.
- **Modal Bottom Sheet ("Hardware Telemetri & Raw ADC")**: Menampilkan tabel seluruh register ADC charger fisik (`Pump_Express_VCharger`, `sc_ibat_limit`, `pdc_max_watt`, `BN_TestMode`, dll.) serta matriks lengkap seluruh sensor `thermal_zone` perangkat secara langsung dari kernel sysfs.

---

# Lynx [Codename: Deity] 3.0.62
Released on: 2026-10-08
> **Versi ini** menghadirkan **Penyelarasan & Perbaikan Parameter Extreme Charging MediaTek & Richtek RT9759 Direct Charge Pump (6A+ / 33W Unlock), Koreksi Parameter Arus MediaTek (Eliminasi Nilai Overflow 24576 mA Menjadi 6000 mA / 6A & Batas Watt 33W Sesuai Spesifikasi Fisik Hardware), Integrasi Bypass Proteksi Termal PCB Transsion (`pcb_thermal_debug`), Serta Kalibrasi Telemetri Arus Adapter & Baterai Bebas Distorsi Pada Aplikasi Native Android (`LynxCompanion`)** — memperbaiki kendala arus pengisian daya yang sebelumnya tertahan di ~2A akibat nilai arus melebihi kapasitas register driver kernel MediaTek yang memicu fallback ke batas aman OEM; membuka penuh rel daya Pump Express 4.0 dan IC Charge Pump 2:1 hingga 6000 mA; serta menyempurnakan pembacaan telemetri arus adapter dan daya watt secara presisi di antarmuka aplikasi native.

## Fitur Baru & Peningkatan (3.0.62)

### 1. Perbaikan Parameter Kernel Charging MediaTek & Richtek RT9759
- **Koreksi Nilai Arus Pengisian (mA vs Overflow)**: Memperbaiki penulisan parameter `input_current`, `chg1_current`, `chg2_current`, dan `sc_ibat_limit` dari nilai `24576` menjadi `6000 mA` (6A) pada arsitektur MediaTek Helio dan Dimensity. Driver kernel MediaTek menginterpretasikan nilai di atas 6000 sebagai overflow dan memicu pembatalan perintah menuju batas default OEM (~500mA - 2000mA).
- **Penyelarasan Daya Pump Express (`pdc_max_watt`)**: Menyesuaikan parameter batas watt maksimum ke 33W pada profil pengisian cepat MediaTek Pump Express 4.0 agar protokol negosiasi adaptor tegangan tinggi (8.5V - 9.0V) dapat aktif secara stabil.
- **Bypass Throttling Termal PCB Transsion**: Mengintegrasikan penulisan parameter `[95,6000,100,6000,6000]` ke node `/sys/devices/platform/odm/odm:tran_battery/pcb_thermal_debug` agar algoritma proteksi termal perangkat keras tidak menurunkan arus ke 1500mA saat ponsel hangat atau layar menyala.

### 2. Kalibrasi Telemetri Arus & Wattmeter di LynxCompanion
- **Fallback Pembacaan Arus Multi-Node**: Menambahkan fallback pembacaan node arus charger perangkat keras (`/sys/devices/platform/charger/input_current` dan `chg1_current`) pada `readBatteryDetails()` di repository Android native.
- **Normalisasi Heuristik Satuan Arus (mA vs µA)**: Memperbaiki deteksi rentang nilai telemetri arus agar nilai mA (100–9000 mA) dan µA (>100000 µA) tidak lagi mengalami perkalian atau pembagian keliru, memastikan tampilan wattmeter dan arus netto baterai akurat 100%.

---

# Lynx [Codename: Deity] 3.0.61
Released on: 2026-10-06
> **Versi ini** menghadirkan **Propagasi Menyeluruh Master CPU Preset ke Seluruh Subsistem CPU Performance (Comprehensive Preset Subsystem Propagation), Penguncian Gembok Frekuensi Otomatis Pada Mode Ekstrem (Cluster Lock Automation), Penyelarasan Otomatis Core Parking (Unpark Semua vs Dinamis vs Parkir Big), Profil Terpadu CPU Idle C-States & Task Shield CPU Sets, Konfigurasi Penjadwal & Histeresis Adaptif, Serta Penambahan Indikator Status Modifikasi Reaktif Pada Header Tab Performance** — memastikan bahwa setiap kali pengguna memilih salah satu dari 4 Master CPU Preset (Battery, Balanced, Performance, Ekstrem), seluruh parameter subsistem CPU secara otomatis mengikuti profil terpilih; Mode Ekstrem mengunci frekuensi puncak kluster 100% dan mengaktifkan gembok kluster secara otomatis, membuka seluruh inti prosesor (Unpark Semua), mengaktifkan Zero Latency pada CPU Idle C-States, menerapkan isolasi gaming pada Task Shield CPU Sets, menyetel histeresis penjadwal agresif 50/30, serta menyalakan bypass kebijakan daya perangkat keras (MTK PPM & Qualcomm Touchboost); sementara mode Battery, Balanced, dan Performance membuka gembok kluster untuk memungkinkan downclocking dinamis dan menyelaraskan konfigurasi subsistem terkait; serta menambahkan pill indikator status reaktif (Standar Profil / Terkustomisasi) pada header PILIH MODE PERFORMA (3+1) di Tab 0 agar status modifikasi manual langsung terlihat tanpa harus berpindah ke Tab 1.

## Fitur Baru & Peningkatan (3.0.61)

### 1. Propagasi Menyeluruh Master CPU Preset ke Seluruh Subsistem
- **Penyelarasan Gembok Kluster Otomatis**: Memilih Mode Ekstrem secara otomatis mengunci gembok kluster pada frekuensi maksimum (100% OPP) dengan ikon gembok terkunci berwarna merah, sementara mode Battery, Balanced, dan Performance secara otomatis membuka gembok kluster ke status tidak terkunci agar mekanisme downclocking frekuensi tetap berjalan efisien.
- **Propagasi Core Parking (Hotplug)**: Mode Ekstrem memaksa seluruh inti aktif (Unpark Semua), mode Performance dan Balanced menerapkan manajemen dinamis adaptif (Dinamis), dan mode Battery memarkir inti besar berdaya tinggi (Parkir Big).
- **Propagasi CPU Idle & Task Shield CPU Sets**: Mode Ekstrem dan Performance secara otomatis menerapkan profil Zero Latency dan Gaming Isolation; mode Balanced menerapkan Standar Seimbang dan Standar Android; mode Battery menerapkan Deep Sleep dan Hemat Ekstrem.
- **Konfigurasi Penjadwal & Histeresis Adaptif**: Menyesuaikan profil penjadwal kernel (extreme, gaming, balanced, battery) beserta ambang batas histeresis target frekuensi (50/30, 70/50, 85/65, 95/75) sesuai profil yang dipilih.
- **Integrasi Hardware Policy Engine**: Mengaktifkan bypass performa pada MediaTek PPM dan Qualcomm Touchboost saat Mode Ekstrem dan Performance aktif, serta mengembalikan konfigurasi default atau power save saat Balanced dan Battery aktif.

### 2. Indikator Status Reaktif Pada Header Tab Performance
- **Pill Status Langsung (Tab 0)**: Menyematkan lencana status visual "Standar Profil" (hijau) atau "Terkustomisasi" (oranye) tepat di samping header "PILIH MODE PERFORMA (3+1)" pada Tab 0, memberikan umpan balik visual langsung saat pengguna menyesuaikan slider frekuensi, governor, atau parameter subsistem lainnya.
- **Sinkronisasi Status Tanpa Efek Samping**: Menambahkan parameter pelacak fromMasterProfile pada seluruh pemanggil mutasi subsistem sehingga penerapan profil master tidak lagi memicu tanda modifikasi manual secara keliru.

### 3. Arsitektur Eksekusi Atomik & Pipeline Tunggal Bebas Race Condition
- **Eliminasi Coroutine Stampede**: Menghilangkan lebih dari 12 coroutine terpisah yang sebelumnya diluncurkan bersamaan saat pergantian mode, mencegah perebutan antrean libsu root shell dan race condition pada sysfs kernel cpufreq/ppm.
- **Responsivitas Antarmuka Optimistik (0ms Latency)**: Status tombol mode, batas frekuensi kluster, status gembok kunci frekuensi, penjadwal, cpusets, dan lencana status profil diperbarui secara instan pada frame yang sama saat tombol ditekan tanpa menunggu respons shell.
- **Pipeline Sekuensial & Pembatalan Transisi Usang (Job Cancellation)**: Seluruh penulisan parameter kluster, penjadwal kernel, Task Shield CPU Sets, CPU Idle, Core Parking, dan kebijakan perangkat keras (MTK PPM & Qualcomm Touchboost) dijalankan secara sekuensial dalam satu coroutine tunggal; jika pengguna berpindah mode kembali sebelum operasi selesai, operasi sebelumnya dibatalkan secara bersih (cancellable) tanpa membebani antrean kernel.
- **Konsolidasi Pembacaan Telemetri Akhir**: Menggantikan pemanggilan berulang `refreshClusters()` di tengah penulisan dengan satu lintasan pembacaan terpadu setelah jeda stabilisasi kernel (200ms), memastikan tampilan UI dan kondisi nyata kernel selalu sinkron 100%.

---

# Lynx [Codename: Deity] 3.0.60
Released on: 2026-10-06
> **Versi ini** menghadirkan **Konsolidasi Master CPU Preset Terpadu Format 3+1 (Battery, Balanced, Performance + Ekstrem dengan Konfirmasi Keamanan), Eliminasi Kartu Ekstrem Terpisah Demi Efisiensi Ruang Layar (Space-Saving Clean Hierarchy), Redesain Tab Sistem Menggantikan Tombol Preset Duplikat Menjadi Kartu Status Profil Sistem dengan Deteksi Modifikasi Manual (Terkustomisasi / Modified State), Serta Tombol Pemulihan Cepat (Reset ke Standar Profil)** — menyelaraskan seluruh parameter CPU (kluster OPP clock, governor, penjadwal EAS, afinitas inti CPU Sets, dan efisiensi C-States/Core Parking) di bawah satu kendali master pada Tab 0 (Performance); menggabungkan Mode Ekstrem langsung ke dalam deretan pemilih mode utama dengan format 3+1 yang ringkas dan efisien tanpa memakan ruang vertikal; menyematkan dialog konfirmasi bahaya termal dan peringatan pendingin eksternal (cooler) saat Mode Ekstrem diketuk; mengeliminasi tombol preset redundan di Tab 1 (System) dan menggantikannya dengan Kartu Status Profil Sistem yang menampilkan profil aktif, badge status sinkronisasi, dan aksi 1-klik untuk mereset setelan granular kembali ke baseline profil master; serta mempertahankan standar visual konsisten dengan margin horizontal 16dp dan radius sudut 22dp.

## Fitur Baru & Peningkatan (3.0.60)

### 1. Integrasi Master CPU Preset 3+1 & Efisiensi Ruang Layar
- **Pemilih Mode 3+1 Terpadu**: Mengintegrasikan 3 mode standar aman (Battery, Balanced, Performance) dan +1 mode khusus (Ekstrem) ke dalam satu deretan pemilih ringkas di dalam kartu Performa CPU & Kluster.
- **Konfirmasi Dialog Keamanan Mode Ekstrem**: Mengetuk tombol Ekstrem pada baris pemilih memicu dialog konfirmasi risiko termal (kunci frekuensi puncak 100% dan bypass batas daya OEM) sebelum profil diterapkan, mencegah aktivasi tidak sengaja.
- **Efisiensi Ruang Vertikal**: Mengeliminasi kartu terpisah Mode Ekstrem sehingga seluruh kartu kluster, metrik OPP, dan tombol Pengaturan Lanjutan tertata rapi dalam satu layar tanpa pemborosan ruang.

### 2. Redesain Tab Sistem & Status Profil Terkustomisasi
- **Eliminasi Tombol Preset Duplikat**: Menghapus deretan 3 tombol preset usang pada Tab 1 (System) untuk mencegah konflik konfigurasi dan kebingungan pengguna.
- **Kartu Status Profil Sistem**: Menampilkan nama profil master yang sedang aktif beserta indikator visual status: "Standar Profil" saat parameter tersinkronisasi, atau "Terkustomisasi (Modified)" saat pengguna mengubah pengaturan lanjutan secara manual.
- **Tombol Reset ke Standar Profil**: Tombol pemulihan 1-klik yang mengembalikan seluruh parameter granular penjadwal, afinitas, dan idle kembali ke standar profil aktif tanpa perlu beralih tab.

### 3. Pelacakan Status Modifikasi Manual (Modified State Tracking)
- **Deteksi Interaksi Granular**: Setiap modifikasi manual pada slider penjadwal, toggle afinitas inti CPU Sets, status C-State, atau core parking secara instan menandai status CPU sebagai termodifikasi dan memperbarui kartu status sistem.

---

# Lynx [Codename: Deity] 3.0.59
Released on: 2026-10-06
> **Versi ini** menghadirkan **Penyelarasan Margin Horizontal & Radius Sudut Kartu Atas Sub Halaman CPU (Grid Margin Harmonization), Eliminasi Tampilan Mepet & Menempel Pada Tepi Layar Untuk Hero Dashboard & Smart Recommendation Banner, Standardisasi Radius Kartu Menjadi 22dp Sesuai LynxCard Design System, Serta Penataan Jarak Vertikal Antar-Elemen Yang Lega & Konsisten** — menyelesaikan ketidakkonsistenan visual pada Tab 0 (Performance) dan Tab 2 (Monitor) di mana kartu status utama (Hero Dashboard Card) dan banner rekomendasi pintar sebelumnya membentang penuh tanpa padding horizontal (0dp margin) sehingga terlihat menempel rapat ke pinggir layar ponsel dan tampak tidak serasi dengan kartu di bawahnya yang memiliki indentasi 16dp; menambahkan padding horizontal standar 16dp dan padding vertikal 6dp/4dp; menyelaraskan radius sudut kartu utama menjadi 22dp dan radius banner menjadi 16dp; serta memperluas bantalan internal kartu menjadi 18dp agar informasi telemetri dan status termal bernapas dengan lega dan estetis.

## Fitur Baru & Peningkatan (3.0.59)

### 1. Penyelarasan Margin Horizontal Kartu Atas (Tab Performance & Monitor)
- **Konsistensi Grid Layout 16dp**: Kartu Hero Dashboard dan Banner Rekomendasi Pintar kini menerapkan padding horizontal standar 16dp, sejajar sempurna dengan batas tepi kartu Performa CPU & Kluster dan tombol Pengaturan Lanjutan.
- **Eliminasi Tampilan Mepet ke Tepi Layar**: Kartu tidak lagi membentang 100% penuh tanpa jarak ke bezel perangkat, memberikan tampilan visual yang proporsional, simetris, dan mewah.

### 2. Standardisasi Radius Sudut & Padding Internal
- **Radius Sudut Terpadu 22dp**: Menyelaraskan kelengkungan sudut Hero Dashboard Card (Tab 0) dan Master Live Monitor Card (Tab 2) menjadi 22dp agar seragam dengan seluruh komponen LynxCard lainnya.
- **Radius Banner Rekomendasi 16dp**: Memperhalus lengkungan kartu peringatan/rekomendasi pintar agar selaras dengan hirarki kartu modern.
- **Bantalan Konten Internal 18dp**: Memberikan ruang baca yang lebih lega untuk matriks 4-metrik utama (Peak Clock, Suhu CPU, Beban CPU, Status Throttle) dan bilah kualitatif Status CPU.

---

# Lynx [Codename: Deity] 3.0.58
Released on: 2026-10-06
> **Versi ini** menghadirkan **Pemisahan Tombol Pengaturan Lanjutan Menjadi Komponen Mandiri di Luar Kartu Induk (Standalone Gateway Trigger), Penegasan Batas Ruang Lingkup Kartu Utama CPU & System, Penyelarasan Kausalitas Visual Tingkat Kontrol (Spatial Causality Alignment), Serta Penyempurnaan Tampilan Tombol Accordion Mandiri dengan Kontainer Ikon Tematik** — menyelesaikan kerancuan visual di mana tombol pemicu pengaturan lanjutan sebelumnya berada di dalam kartu induk tetapi memunculkan kartu di luar kartu induk; memindahkan tombol "Pengaturan Lanjutan" (Tab Performance) dan "Pengaturan Sistem Lanjutan" (Tab System) keluar dari kartu induk masing-masing sehingga kartu utama fokus murni pada fungsinya (Profil & Kluster pada Tab 0, Preset Optimasi pada Tab 1); mendesain tombol pemicu sebagai kartu aksi mandiri berlebar penuh dengan kontainer ikon beraksen halus dan panah ekspansi yang memperjelas hierarki Level 1 menuju Level 2.

## Fitur Baru & Peningkatan (3.0.58)

### 1. Tombol Pengaturan Lanjutan Mandiri (Tab Performance)
- **Pemisahan dari Kartu Performa & Kluster**: Tombol "Pengaturan Lanjutan" kini berdiri sendiri di bawah kartu utama, mengeliminasi kerancuan bahwa pengaturan tersebut hanya berlaku untuk kluster tertentu.
- **Kausalitas Visual yang Jelas**: Kartu-kartu lanjutan (Platform Hardware Engine, Mode Ekstrem, Verifikasi Pengembang) mengembang tepat di bawah tombol pemicunya secara alami.
- **Desain Tombol Mandiri**: Menggunakan kontainer kartu mandiri setinggi 52dp dengan kotak ikon beraksen Cyan halus, teks judul tegas, dan deskripsi fungsi.

### 2. Tombol Pengaturan Sistem Lanjutan Mandiri (Tab System)
- **Pemisahan dari Kartu Preset Sistem**: Tombol "Pengaturan Sistem Lanjutan" dipindahkan keluar dari kartu preset sistem, menjaga kartu preset tetap bersih dan berfokus tunggal.
- **Hierarki Aksi Jelas**: Mengetuk tombol mandiri beraksen Oranye ini memunculkan kartu Core Efficiency, Task Shield, dan Penjadwal Kernel langsung di bawahnya secara mulus.

---

# Lynx [Codename: Deity] 3.0.57
Released on: 2026-10-06
> **Versi ini** menghadirkan **Perbaikan Tata Letak Menu Pengaturan Lanjutan (Full-Width Sibling Layout), Eliminasi Total Padding Bertumpuk Pada Menu Lanjutan CPU Tab Performance & Tab System, Pembebasan Margin Horizontal Untuk Opsi Platform Hardware Engine, Mode Ekstrem, Dan Verifikasi Pengembang, Serta Penyempurnaan Hirarki Visual Sibling Card Tanpa Frame Bersarang** — mengatasi masalah tampilan yang menyempit dan sesak saat menu Pengaturan Lanjutan dibuka; memindahkan blok ekspansi `AnimatedVisibility` keluar dari container kartu induk sehingga menjadi kartu saudara sejajar (sibling cards) berukuran penuh; membebaskan lebih dari 136dp margin horizontal yang sebelumnya terbuang akibat pembungkusan kartu di dalam kartu; memastikan opsi MediaTek PPM, Snapdragon QTI HAL, Mode Ekstrem, Verifikasi Pengembang, Core Efficiency, Task Shield, dan Penjadwal Kernel memiliki ruang baca teks yang luas dan rapi.

## Fitur Baru & Peningkatan (3.0.57)

### 1. Eliminasi Frame Bersarang pada Pengaturan Lanjutan (Tab Performance)
- **Tata Letak Kartu Sejajar Penuh (Full-Width Sibling Cards)**: Konten lanjutan saat accordion "Pengaturan Lanjutan" dibuka kini tampil sebagai kartu mandiri berlebar penuh di bawah kartu utama, bukan di dalam bantalan kartu utama.
- **Peningkatan Ruang Baca Opsi**: Memberikan lebar penuh untuk opsi Platform Hardware Engine (MediaTek PPM / Qualcomm TouchBoost), Mode Ekstrem, dan tombol laci Verifikasi Pengembang tanpa pemotongan atau pelipatan teks yang sempit.

### 2. Eliminasi Frame Bersarang pada Pengaturan Sistem Lanjutan (Tab System)
- **Kartu Mandiri Berlebar Penuh**: Memindahkan kartu Core Efficiency, Task Shield, dan Penjadwal Kernel keluar dari pembungkus kartu preset sistem, sehingga masing-masing kartu mendapatkan lebar tampilan 100% tanpa margin ganda.
- **Transisi Ekspansi Mulus**: Mempertahankan animasi buka-tutup halus dengan `AnimatedVisibility()` saat pengguna mengetuk "Pengaturan Sistem Lanjutan".

---

# Lynx [Codename: Deity] 3.0.56
Released on: 2026-10-06
> **Versi ini** menghadirkan **Penyempurnaan Menyeluruh UX Sub Halaman CPU Menuju Pengalaman OEM Premium (Lynx Performance Center), Eliminasi Total Multi-Nested Card Frames Menjadi Hirarki Permukaan Datar Elegan, Standardisasi Mode 1-Klik Global (Battery | Balanced | Gaming), Transparansi Teknis Ganda (Bahasa Manusia Disertai Label Sekunder Kernel), Smart Health Indicator Kualitatif & Status Termal Permanen (Healthy / Warm / Throttled), Redesain Baris Kluster Kompak dengan Transisi Motion Halus, Penyederhanaan Tab Monitor dengan Ringkasan Rata-Rata MHz & Matriks Inti Expandable, Serta Developer Verification Drawer Tersembunyi di Menu Lanjutan** — mengeliminasi kesan kartu di dalam kartu yang bertumpuk; merestrukturisasi tata letak menjadi `Surface Utama -> Section -> Compact Expandable Row`; menyematkan baris kluster kompak 56dp yang mengembang secara mulus melalui `animateContentSize()`; menyajikan pemilih frekuensi diskrit Dual-Pill OPP dan pemilih respon CPU ramah pengguna; menggantikan angka kesehatan sistem arbitrer dengan indikator status kualitatif yang pasti; mengintegrasikan status suhu dan proteksi throttling secara permanen pada kartu hero; merampingkan tampilan tab Monitor dengan menyajikan rata-rata frekuensi kluster Little dan Big sebelum membuka detail 8-core per-silikon; serta menyembunyikan lembar verifikasi sysfs pengembang di dalam panel pengaturan lanjutan demi menjaga kerapian dan keamanan antarmuka bagi pengguna umum.

## Fitur Baru & Peningkatan (3.0.56)

### 1. Eliminasi Multi-Nested Frames & Design System Cleanup
- **Struktur Permukaan Datar**: Menghilangkan kartu di dalam kartu yang membuat antarmuka terasa seperti BIOS atau utilitas engineer lama. Tata letak kini mengikuti hirarki modern: `Surface Utama -> Section Header -> Compact Expandable Row`.
- **Aksen Kluster Halus**: Mempertahankan pembeda visual kluster Little (Hijau halus) dan Big (Oranye halus) melalui indikator dot dan garis aksen tipis, tanpa border mencolok.

### 2. Standarisasi Mode 1-Klik (Battery | Balanced | Gaming)
- **Konvensi Android Global**: Mengganti label Performa menjadi Gaming, menyelaraskan 3 mode utama (`Battery`, `Balanced`, `Gaming`) yang langsung intuitif dan memiliki konteks penggunaan yang jelas.
- **Transparansi Teknis Ganda**: Seluruh elemen kontrol menyajikan bahasa manusia komunikatif sebagai judul utama dan istilah kernel asli sebagai label sekunder (contoh: `Balanced (schedutil)`).

### 3. Smart Health Indicator Kualitatif & Status Termal Permanen
- **Indikator Kredibel Tanpa Persentase Arbitrer**: Menggantikan persentase kesehatan sistem dengan status kualitatif terukur: `Healthy (CPU bekerja normal)`, `Warm (Suhu meningkat)`, dan `Throttled (Performa dibatasi sistem)`.
- **Status Throttling Permanen di Hero**: Kartu status kini selalu menampilkan metrik Suhu CPU dan Status Throttling (`None` / `Aktif`) secara permanen.

### 4. Baris Kluster Kompak dengan Motion Animation
- **Desain Baris 56dp**: Saat tertutup, setiap kluster hanya memakan ruang minimal setinggi 56dp berisi nama kluster, jumlah inti, rentang frekuensi, dan respon governor aktif.
- **Transisi Halus**: Menggunakan `animateContentSize()` dan `AnimatedVisibility()` untuk animasi buka-tutup yang mulus ke panel frekuensi diskrit Dual-Pill OPP.

### 5. Penyederhanaan Tab Monitor & Core Activity Summary
- **Ringkasan Kluster Default**: Tab Monitor menyajikan jumlah inti aktif dan rata-rata frekuensi real-time untuk Kluster Efisiensi dan Kluster Performa secara bersih.
- **Matriks 8-Core Expandable**: Matriks individual C0 s/d C7 disembunyikan di balik tombol ekspansi "Tampilkan Semua Inti (Show All Cores)" untuk menjaga layar tetap ringkas.

### 6. Developer Verification Drawer Tersembunyi
- **Akses Pengembang di Menu Lanjutan**: Lembar verifikasi sysfs kernel ditempatkan di dalam menu "Pengaturan Lanjutan >" untuk memvalidasi transparansi node kernel (`/sys/devices/system/cpu/cpufreq/`, dll.) dan perizinan hardware tanpa membingungkan pengguna biasa.

---

# Lynx [Codename: Deity] 3.0.55
Released on: 2026-10-06
> **Versi ini** menghadirkan **Transformasi Menyeluruh Sub Halaman CPU Menjadi Pengalaman Consumer-Premium Berfilosofi "One Glance, One Action, Deep Control When Needed", Struktur 3 Tab Ergonomis (Performance | System | Monitor), 3 Level Keterbukaan Informasi (Progressive Disclosure), Dashboard Hero dengan Meter Skor Kesehatan Sistem (CPU Health Score), Smart Recommendation yang Cerdas & Dismissible, Panel Kontrol Terpadu dengan Pemilih Frekuensi Diskrit Dual-Pill OPP Tanpa Continuous Slider, Mode Ekstrem Terlindungi Dialog Konfirmasi Termal, serta Adopsi Bahasa Manusia (Core Efficiency, Task Shield, Task Priority Boost) Disertai Tooltip Hardware Asli** — merekonstruksi arsitektur subhalaman CPU dari daftar bertumpuk raksasa (~1.950 baris kode) menjadi sistem modular ramping; memisahkan domain tanggung jawab ke dalam 3 tab intuitif (`Performance`, `System`, dan `Monitor`); menyajikan status utama (peak clock, suhu CPU, utilisasi total, dan persentase skor kesehatan sistem gabungan) di permukaan; menyediakan baris 1-klik mode ramah pengguna (`Battery`, `Balanced`, `Gaming`) dengan menyembunyikan mode `Extreme` di balik panel ekspansi lanjutan guna mencegah risiko panas berlebih; memusatkan kontrol frekuensi kluster ke format Dual-Pill Modal Bottom Sheet yang presisi; mengonversi istilah teknis kernel ke bahasa manusia komunikatif dengan tooltip teknis sysfs untuk pengguna mahir; serta menyajikan telemetri real-time, matriks 8-core silicon dengan proteksi Master Core 0, dan pemantau proses Scene-style pada tab Monitor.

## Fitur Baru & Peningkatan (3.0.55)

### 1. Arsitektur 3 Tab Ramah Pengguna (Performance | System | Monitor)
- **Navigasi Sticky CpuTabRow**: Menyematkan bilah navigasi 52dp ergonomis di bawah category header yang membagi kontrol CPU secara tegas:
  - **Performance**: Dashboard status utama, smart recommendation, profil 1-klik, dan kontrol frekuensi kluster lanjutan.
  - **System**: Optimasi sistem 1-klik, Core Efficiency (C-States/parking), Task Shield (CPU Sets), dan Task Priority Boost (EAS Uclamp/migration).
  - **Monitor**: Matriks silikon 8-core real-time, grafik riwayat beban kurva bezier, topologi hardware & cache, serta pemantau proses aktif teratas.
- **Auto-Scroll to Top**: Transisi antar-tab secara instan mengatur posisi scroll ke puncak layar demi kenyamanan pandangan pengguna.

### 2. Dashboard Hero & CPU Health Score Meter
- **Status Sistem dalam Satu Pandangan**: Menampilkan profil aktif, peak clock dalam GHz, suhu prosesor dengan indikator warna dinamis, beban CPU rata-rata, dan jumlah core aktif.
- **Bilah Skor Kesehatan Sistem**: Algoritma kalkulasi dinamis yang menggabungkan beban kerja, suhu termal, status throttling, dan ketersediaan core online untuk memberikan persentase kesehatan sistem (misal: 88% Optimal).

### 3. Smart Recommendation Cerdas & Non-Intrusif
- **Saran Kontekstual Bersyarat**: Banner rekomendasi yang hanya muncul saat mendeteksi ambang batas kritis (suhu > 44°C atau beban tinggi berkepanjangan pada mode hemat daya), lengkap dengan tombol 1-klik untuk menerapkan solusi dan tombol tutup (dismissible) yang tidak mengganggu alur pengguna.

### 4. Konsolidasi Kartu & Pemilih Frekuensi Diskrit Dual-Pill
- **Pengaturan Lanjutan yang Terorganisasi**: Menyatukan puluhan kartu terpisah ke dalam `CpuUnifiedPerformanceCard` yang bersih. Kontrol frekuensi kluster disematkan di balik ekspansi "Pengaturan Lanjutan >" menggunakan format tombol Dual-Pill Min/Max MHz Picker via Modal Bottom Sheet, tanpa menggunakan continuous slider.
- **Proteksi Mode Ekstrem**: Mode Ekstrem dipisahkan dari tombol cepat dan dilindungi dialog peringatan bahaya termal dengan konfirmasi sadar risiko.

### 5. Human-Friendly Terminology & Tooltip Teknis
- **Bahasa Manusia Komunikatif**: Mengganti istilah teknis membingungkan menjadi bahasa yang mudah dipahami: *Core Efficiency* (sebelumnya CPU Idle Core Parking), *Task Shield* (sebelumnya CPU Sets), *Task Priority Boost* (sebelumnya Uclamp), dan *Frequency Levels* (sebelumnya OPP Table).
- **Tooltip Kernel untuk Power User**: Menyediakan ikon informasi yang menampilkan node sysfs asli (`/proc/sys/kernel/sched_util_clamp_min`, dll.) bagi pengembang dan antusias hardware.

---

# Lynx [Codename: Deity] 3.0.54
Released on: 2026-10-05
> **Versi ini** menghadirkan **Pembersihan Menyeluruh Kontrol Redundan pada Subhalaman GPU & Display, Perampingan Arsitektur GpuMasterTunerCard Menjadi Master Clock & OPP Telemetry Controller, Pemusatan Tunggal Seluruh Tweak Kernel Sysfs ke Adaptive Hardware HAL Card (Single Source of Truth), Konversi Chip Kecepatan Refresh Tab 2 Menjadi Spesifikasi Diagnostik Read-Only, Ekspansi Dynamic Probing pada Generic Devfreq HAL, serta Penerapan Domain Boundary Contract 8-Tingkat** — merekonstruksi komponen tuning GPU dan tampilan; mengeliminasi seluruh toggle statis legacy di dalam `GpuMasterTunerCard` (segmented boost engine, power policy, serta accordion kustomisasi lanjutan yang menduplikasi governor, bypass thermal, bus memory always-on, idle timer, FPSGO frame pacing, dan DVFS margin); memusatkan 100% kontrol hardware ke `AdaptiveGpuHardwareCard` yang memiliki verifikasi izin non-destruktif (`VERIFIED_WORKING` vs `READ_ONLY_LOCKED`) dan verifikasi baca-ulang transaksional dengan rollback otomatis; mengubah chip refresh rate di Tab 2 (Info) menjadi lencana spesifikasi panel fisik murni tanpa fungsi tombol interaktif; menambahkan probe `polling_interval` pada `GenericDevfreqAdapter`; serta mengukuhkan batas domain arsitektural pada dokumen panduan pengembang guna menjamin tidak ada lagi tweak tumpang-tindih di masa mendatang.

## Fitur Baru & Peningkatan (3.0.54)

### 1. Eliminasi Redundansi Tweak & Perampingan GpuMasterTunerCard
- **Fokus Tunggal pada Clock & OPP Telemetri**: Kartu `GpuMasterTunerCard` dirampingkan secara ergonomis untuk memegang tanggung jawab eksklusif terhadap pemilihan frekuensi clock OPP (Dual-Pill Min/Max MHz Picker via Modal Bottom Sheet), status penguncian clock (*clock lock*), grafik kurva bezier beban GPU real-time, dan pemantauan proses render aktif SurfaceFlinger/HWUI.
- **Pembersihan Kontrol Ganda**: Menghapus seluruh bagian Segmented Boost Engine, GPU Power Policy, dan Accordion *Kustomisasi Lanjutan GPU & Kernel* yang sebelumnya bertumpuk dengan kartu akselerasi hardware di bawahnya.

### 2. Pemusatan Eksklusif Kernel Sysfs ke AdaptiveGpuHardwareCard (Single Source of Truth)
- **Satu Pintu Tuning Kernel**: Seluruh parameter sysfs driver GPU (Qualcomm KGSL, MediaTek GED/FPSGO, ARM Mali Kbase, dan Generic Devfreq) kini dikelola secara eksklusif oleh `AdaptiveGpuHardwareCard`.
- **Integritas Hardware Tanpa Tombol Palsu**: Setiap interaksi pada kartu ini dilindungi oleh siklus penulisan transaksional: pengujian hak akses baca/tulis (`[ -r ]` dan `[ -w ]`), penulisan atomik, verifikasi baca-ulang (*read-back verification*), dan pembatalan otomatis (*auto-rollback*) jika kernel menolak nilai baru.

### 3. Konversi Tab 2 (Info) Menjadi Diagnostik Murni Read-Only
- **Pemisahan Peran Tegas**: Menghilangkan fungsi klik pengubah refresh rate pada `DisplayTelemetryCard` dan `GpuHardwareInfoDashboard` di Tab 2. Chip mode frekuensi kini berfungsi sebagai lencana diagnostik fisik (`60Hz`, `90Hz`, `120Hz (Aktif)`) dengan teks panduan yang mengarahkan pengguna ke Tab 0 (Tuning).
- **Pengendali Terpusat di Tab 0**: Kontrol interaktif mode display (HWC direct mode switching, Auto dynamic mode, TouchBoost, dan DC Dimming) dikukuhkan terpusat pada `DisplayRefreshRateTouchCard`.

### 4. Ekspansi Dynamic Hardware Probing (Generic Linux Devfreq)
- **Probe Devfreq Polling Interval**: Memperluas `GenericDevfreqAdapter` untuk memindai node `polling_interval` secara dinamis, melengkapi dukungan governor, step frekuensi OPP, dan batasan min/max clock pada SoC seperti Samsung Exynos Xclipse (AMD RDNA), Unisoc Tiger, dan platform Linux generic.

### 5. Tata Kelola Batas Domain Arsitektur (Domain Boundary Contract)
- **Pedoman Pengembang Mengikat (AGENTS.md Section 7.2)**: Mengesahkan aturan pemisahan tanggung jawab 8-domain guna mencegah pengembang atau agen kecerdasan buatan memperkenalkan kembali kontrol ganda atau tumpang tindih sysfs pada subhalaman GPU & Display di masa depan.

---

# Lynx [Codename: Deity] 3.0.53
Released on: 2026-10-05
> **Versi ini** menghadirkan **Telemetri Real-Time Refresh Rate Layar Berbasis DisplayManager Listener (Event-Driven Panel Rate Callback), Penghapusan Lencana Statis Redundan pada Kartu Kecepatan Refresh, Desain Tipografi Digital Minimalis Tanpa Wadah Badge, serta Penyelarasan Deskripsi Mode Auto Dinamis** — merekonstruksi komponen `DisplayRefreshRateTouchCard` pada subhalaman GPU & Display; menghilangkan lencana statis `Auto (120 Hz)` yang redundan dengan chip pemilih frekuensi; mengimplementasikan pemantauan refresh rate layar aktif secara instan (0ms latency event callback) melalui `DisplayManager.DisplayListener` terdaftar tanpa polling berkala dan tanpa konsumsi baterai latar belakang; menampilkan metrik frekuensi aktual dalam format tipografi digital bersih (`REAL-TIME` berhuruf kapital tegas dengan angka frekuensi tebal dinamis); serta memperjelas deskripsi mode Auto dinamis saat panel beralih clock antara kondisi statis dan interaksi sentuhan.

## Fitur Baru & Peningkatan (3.0.53)

### 1. Telemetri Real-Time Refresh Rate Layar (Event-Driven DisplayListener)
- **Zero-Latency Hardware Callback**: Menggunakan `DisplayManager.DisplayListener` yang mendengarkan perubahan refresh rate layar secara native saat panel berpindah frekuensi antara mode idle dan interaksi sentuh.
- **Efisiensi Daya & Zero Polling**: Meniadakan loop polling latar belakang, menjamin tidak ada dampak terhadap konsumsi daya baterai maupun beban thread UI.
- **Siklus Hidup DisposableEffect Terintegrasi**: Pendaftaran listener dibungkus secara aman di dalam `DisposableEffect` Compose dengan pembersihan otomatis (`unregisterDisplayListener`) saat kartu keluar dari komposisi.

### 2. Tipografi Digital Minimalis & Eliminasi Lencana Redundan
- **Penghapusan Badge Pill Statis**: Menghapus kontainer badge pill (`Surface` dengan border/background) yang sebelumnya menampilkan teks redundan terhadap chip pilihan.
- **Metrik Tipografi Bersih (Non-Badge)**: Mengganti lencana dengan teks digital hierarkis di sudut kanan atas kartu: label kecil `REAL-TIME` (9sp, bold, letterSpacing 0.6sp) dan nilai metrik dinamis `${liveHz} Hz` (18sp, extra bold) dengan warna aksen cyan murni.
### 3. Penguncian Frekuensi Fisik Panel (Multi-Tier SurfaceFlinger HWC & cmd display)
- **Direct SurfaceFlinger Mode Switching**: Mengimplementasikan eksekusi langsung transaksi Hardware Composer SurfaceFlinger (`service call SurfaceFlinger 1035`) dengan pemetaan dinamis mode fisik (`id` vs `Hz`). Mengeliminasi masalah di mana pengaturan 60Hz/90Hz/120Hz diabaikan oleh driver OEM Transsion/MediaTek/Xiaomi sehingga monitor layar tetap tertahan di 120Hz.
- **Pelepasan Kunci Backdoor pada Mode Auto**: Saat pengguna memilih mode Auto, sistem secara otomatis merilis kunci backdoor (`service call SurfaceFlinger 1035 i32 -1`) dan membersihkan preferensi mode (`cmd display clear-user-preferred-display-mode 0`), mengembalikan kontrol pergantian frekuensi adaptif ke DisplayManager.
- **Dukungan Multi-Tier DisplayManager**: Menyelaraskan pengaturan Android 11+ `cmd display set-user-preferred-display-mode`, basis data Settings Provider (`min_refresh_rate`, `peak_refresh_rate`, `user_refresh_rate`), serta node sysfs panel (`disp_fps`, `fb0/mode`) secara simultan dalam satu transaksi atomik.

---

# Lynx [Codename: Deity] 3.0.52
Released on: 2026-10-05
> **Versi ini** menghadirkan **Universal Hardware Abstraction Framework (HAL Multi-SoC) Dinamis untuk Penyetelan GPU & Diagnostik Layar, Pemindaian Node Fisik Kernel Berbasis Izin Non-Destruktif (Non-Destructive Permission Probing), Verifikasi Penulisan Transaksional dengan Rollback Otomatis (Transactional Write Verification & Rollback), Penilaian Tingkat Kepercayaan Hardware (Hardware Confidence Scoring), Dekomposisi 4-Tier Frekuensi Layar hingga 240Hz, serta Antarmuka Responsif Adaptif Berbasis Komponen M3** — merevolusi subhalaman GPU & Display dari sistem berbasis vendor statis menjadi kerangka kerja abstraksi hardware universal lintas chipset (Qualcomm Adreno KGSL, MediaTek GED/FPSGO, ARM Mali Kbase, Samsung AMD RDNA, dan Universal Devfreq); menerapkan prinsip keamanan ketat di mana node fisik dipindai hak aksesnya secara non-destruktif tanpa `chmod 644` buta; mengimplementasikan siklus verifikasi transaksional yang secara otomatis membatalkan (*rollback*) perubahan dan mengunci sakelar ke status *Read-Only* jika kernel menolak nilai baru; menyajikan lencana status verifikasi hardware (`Verified HAL`, `VERIFIED_WORKING`, `READ_ONLY_LOCKED`); mendukung kecepatan refresh layar ultra-tinggi hingga 240Hz dengan baris pemilih scrollable yang mempertahankan target sentuh ergonomis minimal 48dp; serta menyelaraskan pilihan frekuensi khusus pada dialog aturan rendering grafis per-aplikasi secara dinamis.

## Fitur Baru & Peningkatan (3.0.52)

### 1. Universal Dynamic GPU Backend HAL Adapter
- **Arsitektur Multi-SoC Terpadu**: Mengintegrasikan `GpuBackendManager` yang secara dinamis memilih adapter driver GPU yang sesuai dengan perangkat: `QualcommAdrenoAdapter`, `MediaTekGedAdapter`, `MaliKbaseAdapter`, dan `GenericDevfreqAdapter`.
- **Pemetaan Parameter Dinamis Tanpa Asumsi Vendor**: Menghilangkan pengkondisian statis vendor pada UI. Kartu `AdaptiveGpuHardwareCard` memindai dan merender seluruh parameter GPU yang benar-benar ada di kernel (`force_bus_on`, `idle_timer`, `fpsgo frame pacing`, `ultra rescue`, `dvfs margin`, `core masking`, `power policy`, dan `governor`).

### 2. Probing Izin Non-Destruktif & Verifikasi Transaksional (Zero Fake Power)
- **Batch Permission Probe Sub-30ms**: Menguji status keberadaan dan izin baca/tulis node via `[ -r ]` dan `[ -w ]` dalam satu eksekusi batch shell, meniadakan `chmod 644` membabi-buta yang dapat mengganggu izin driver atau memicu penolakan SELinux.
- **Transactional Verification & Auto-Rollback**: Setiap perubahan parameter diverifikasi melalui pembacaan ulang nilai kernel (*read-back verification*). Jika nilai tidak berubah atau ditolak kernel, sistem secara otomatis mengembalikan nilai UI (*rollback*), mengunci opsi sebagai `READ_ONLY_LOCKED`, dan menampilkan pesan informatif tanpa tombol palsu.

### 3. Penilaian Tingkat Kepercayaan Hardware (Confidence Scoring)
- **Status Validasi Transparan**: Setiap driver GPU dan parameter dilengkapi skor deteksi, skor tulis, dan skor stabilitas, menampilkan lencana terverifikasi (`Verified HAL`, `Read-Only`, `Fallback`) langsung pada kartu akselerasi hardware.
- **Deteksi Alasan Throttling Spesifik**: Menampilkan penyebab nyata thermal throttling (misal: suhu silikon melampaui batas batas aman atau DVFS thermal clamping aktif).

### 4. Dekomposisi 4-Tier Display & Dukungan Layar 240Hz
- **Deteksi Refresh Rate Dinamis Multi-Tier**: Memisahkan kemampuan fisik panel (`dumpsys display`), izin Android framework (`peak_refresh_rate`), dan frame rate aplikasi aktif tanpa hardcode 60/90/120Hz.
- **Selektor Scrollable 48dp**: Mengganti baris kaku pada `DisplayRefreshRateTouchCard` dan `DisplayTelemetryCard` dengan baris scrollable dinamis yang mendukung frekuensi 60Hz, 90Hz, 120Hz, 144Hz, 165Hz, hingga 240Hz dengan target sentuh ergonomis.
- **Per-App Graphics Hub Refresh Selector**: Mengintegrasikan pilihan refresh rate dinamis ke dalam dialog aturan rendering grafis per-aplikasi.

---

# Lynx [Codename: Deity] 3.0.51
Released on: 2026-10-05
> **Versi ini** menghadirkan **Penguncian Imutabel Izin Hardware (Read-Only chmod 444 Locks) untuk Pengendali Pengisian Daya Ekstrem (Extreme Fast Charging), Bypass Menyeluruh Throttling Layar Nyala (Screen-On Throttling) dan Limitasi Termal Multi-OEM, Elevasi Plafon Ambang Suhu Termal Universal ke 95°C, Pembekuan Perangkat Pendingin (Cooling Devices Freeze), serta Pemulihan Hak Akses Bersih (Reversible Unlatch Architecture)** — mengeliminasi pembatasan pengisian daya yang dipicu oleh kernel saat layar ponsel aktif (*Screen-On*) maupun saat temperatur motherboard/AP mendekati ambang batas konservatif pabrikan; menerapkan kunci proteksi `chmod 444` secara permanen pada node krusial seperti `BN_TestMode`, `BatteryNotify`, `sw_jeita`, `input_current`, `chg1_current`, dan `chg2_current` sehingga driver kernel tidak dapat lagi menurunkan arus pengisian secara sepihak; menaikkan kurva trip point PCB termal Transsion/Infinix dari 44°C ke 85°C–90°C dengan plafon 6000mA; melumpuhkan pembatasan pengisian daya multi-OEM (Xiaomi HyperOS Joyose freeze, Samsung One UI SIOP uncap, OnePlus/OPPO/Realme SuperVOOC Cool & Call mode bypass, Google Pixel Tensor charge stop uncap); menonaktifkan regulasi termal baterai/charger serta menaikkan trip point termal universal ke 95°C di seluruh zona sensor; serta mengimplementasikan mekanisme unlatch reversibel saat pengguna kembali ke mode pengisian teratur atau mode hardware bypass.

## Fitur Baru & Peningkatan (3.0.51)

### 1. Penguncian Imutabel Node Daya Hardware (Read-Only chmod 444)
- **Anti-Kernel Reset Protection**: Membungkus seluruh penulisan node charging krusial (`BN_TestMode`, `BatteryNotify`, `sw_jeita`, `input_current`, `chg1_current`, `chg2_current`, `pdc_max_watt`, `sc_ibat_limit`) dengan izin read-only permanen (`chmod 444`). Hal ini mencegah *daemon* atau *state machine* kernel internal membatalkan konfigurasi ke nilai default pabrikan.
- **Transsion Screen-On Throttling Bypass**: Memaksa mode pengujian pabrik (`BN_TestMode=1`) terkunci permanen, menonaktifkan logika pembatasan arus charging ke 1500mA saat layar menyala (`fb_on=1`).

### 2. Bypass Limitasi Termal Multi-OEM & Elevasi Ambang PCB
- **Transsion PCB Thermal Debug Overhaul**: Menggeser kurva trip point proteksi termal Level 7 dari 44°C menjadi 85°C dengan batas arus 6000mA via `/sys/devices/platform/odm/odm:tran_battery/pcb_thermal_debug`.
- **Xiaomi / Redmi / POCO (HyperOS / MIUI)**: Membekukan layanan `com.xiaomi.joyose` dan membuka limit `thermal_input_current_limit` serta `boost_current` ke 6000mA secara imutabel.
- **Samsung One UI**: Mengunci batas SIOP (`siop_level=100`) dengan `chmod 444`, mengeliminasi *screen-on derating* pada perangkat seri Galaxy S/A/Z.
- **OnePlus / OPPO / Realme (ColorOS / OxygenOS)**: Mengunci `cool_mode=0` dan `call_mode=0` dengan `chmod 444` serta memvalidasi sinyal protokol SuperVOOC murni.
- **Google Tensor, ASUS ROG & Motorola**: Membuka limit kapasitas `charge_stop_level=100` dan mengaktifkan bypass mode pabrik/fast charge secara menyeluruh.

### 3. Elevasi Ambang Batas Sensor Termal Universal (Universal Thermal Zones)
- **Deaktivasi Mode Sensor Baterai/Charger**: Memindai seluruh `/sys/class/thermal/thermal_zone*` terkait baterai, charger, PMIC, AP, dan skin, lalu menonaktifkan modenya (`mode=disabled`) serta mengunci izinnya.
- **Elevasi Trip Points ke 95°C**: Menaikkan parameter `trip_point_*_temp` pada zona sensor terkait ke 95000 (95°C) dengan proteksi `chmod 444`, menjamin subsistem termal kernel tidak pernah memicu status *throttling*.
- **Pembekuan Cooling Devices**: Memaksa seluruh cooling device bertipe *bcct*, *chg*, *current*, *battery*, dan *cdev* ke status 0 (`cur_state=0`) dengan kunci `chmod 444`.
- **Framework Thermal Severity Nullification**: Mengabaikan status peringatan termal sistem Android framework via `cmd thermalservice override-status 0`.

### 4. Arsitektur Pemulihan Reversibel (Clean Unlatch Mechanism)
- **Restorasi Izin Penuh (unlock_extreme_nodes)**: Menyediakan fungsi pelepasan kunci yang secara otomatis mengembalikan izin tulis (`chmod 666 / 644`) serta mengaktifkan kembali zona termal (`mode=enabled`) dan framework thermalservice saat pengguna beralih ke mode pengisian daya normal atau hardware bypass.

---

# Lynx [Codename: Deity] 3.0.50
Released on: 2026-10-05
> **Versi ini** menghadirkan **Normalisasi Akurasi Frekuensi Maksimum Silikon GPU MediaTek GED, Penambahan Pra-Kompilasi Shader Ahead-Of-Time (AOT Pre-Warm) Anti Micro-Stutter, Kontrol Terpadu Kebijakan Manajemen Daya GPU (GPU Power Policy), Akselerasi Latensi Respon Sentuh via SurfaceFlinger VSync Early Offset, serta Pemilih Refresh Rate Interaktif pada Tab Diagnostik Layar** — memulihkan keakuratan pembacaan plafon frekuensi tertinggi GPU pada chipset MediaTek (Helio & Dimensity) dengan memprioritaskan parameter `gpu_cust_upbound_freq` dan tabel OPP kernel alih-alih ambang boost awal; menambahkan kapabilitas pra-kompilasi shader Ahead-Of-Time (AOT) untuk mengeliminasi lonjakan latensi kompilasi shader pada menit-menit pertama menjalankan game 3D; mengintegrasikan sakelar profil daya GPU yang menyelaraskan kebijakan daya ARM Mali Kbase, MediaTek GED, dan Qualcomm Adreno dalam dua mode tegas (Efisiensi Daya vs Responsif Gaming); mengimplementasikan tweak latensi sentuh ultra-rendah melalui pemajuan fase dispatch buffer SurfaceFlinger (`debug.sf.early_phase_offset_ns`); serta mengaktifkan interaktivitas penuh pada pill indikator refresh rate di Tab Info untuk penguncian instan kecepatan penyegaran layar (60Hz, 90Hz, 120Hz).

## Fitur Baru & Peningkatan (3.0.50)

### 1. Normalisasi Akurasi Frekuensi Maksimum Silikon GPU
- **Koreksi Plafon Clock MediaTek GED**: Memperbaiki logika probe pada `LynxRepository.readGpuInfo` dengan memprioritaskan `gpu_cust_upbound_freq` dan nilai teratas tabel OPP `/proc/gpufreq/gpufreq_opp_dump`, meniadakan ketidaksesuaian tampilan clock aktif (950 MHz) dengan badge batas frekuensi (sebelumnya tertahan di 495 MHz).
- **Normalisasi Indikator Dual-Pill**: Menjamin badge frekuensi maksimum selalu merefleksikan kemampuan puncak silikon hardware dan tidak pernah menampilkan nilai yang lebih rendah dari frekuensi yang sedang berjalan secara real-time.

### 2. Pra-Kompilasi Shader Ahead-Of-Time (AOT Anti-Stutter)
- **Kompilasi Profil Kecepatan AOT**: Menambahkan fungsi `prewarmShaderCache()` yang mengeksekusi kompilasi kode dex dan shader game terpasang (`cmd package compile -m speed-profile`) guna meminimalkan insiden micro-stuttering saat render adegan visual kompleks.
- **Antarmuka Kontrol Berdampingan**: Menyediakan tombol aksi `Pre-Warm (AOT)` tepat di samping tombol `Bersihkan` pada kartu manajemen cache shader dengan target sentuh standar 48dp.

### 3. Kontrol Terpadu Kebijakan Daya GPU (GPU Power Policy)
- **Manajemen Profil Daya Instan**: Menambahkan selector dua mode terpadu pada kartu Master GPU Tuner: mode *Efisiensi Daya* (Dynamic Downclock / Coarse Demand) dan mode *Responsif Gaming* (Low Latency / Always-On).
- **Kompatibilitas Multi-SoC Transparan**: Perubahan kebijakan daya secara otomatis menerapkan parameter yang sesuai pada driver yang terdeteksi, baik MediaTek GED (`dvfs_loading_mode`), ARM Mali Kbase (`power_policy`), maupun Qualcomm Adreno (`idle_timer`).

### 4. Akselerasi Latensi Sentuh & VSync Early Offset
- **Pemajuan Dispatch Buffer SurfaceFlinger**: Menghadirkan opsi *Ultra-Low Touch Latency (VSync Early Offset)* yang mengonfigurasi properti `debug.sf.early_phase_offset_ns` dan `debug.sf.early_gl_phase_offset_ns`, memotong latensi respon input sentuhan hingga satu siklus render.
- **Penyelarasan Tampilan Mesin HWUI**: Menyesuaikan padding dan jarak kontainer pemilih engine rendering (Default, SkiaGL, SkiaVK, Graphite, ANGLE) untuk navigasi sentuh yang lebih rapi dan responsif.

### 5. Pemilih Refresh Rate Interaktif pada Tab Info
- **Kunci Refresh Rate Langsung dari Spesifikasi**: Mengubah badge frekuensi penyegaran layar pada Tab Info menjadi kontrol interaktif, memungkinkan pengguna langsung mengunci panel pada kecepatan 60Hz, 90Hz, atau 120Hz dengan indikator visual status aktif.

---

# Lynx [Codename: Deity] 3.0.49
Released on: 2026-10-05
> **Versi ini** menghadirkan **Perbaikan Menyeluruh Telemetri RAM Fisik & Alokasi ZRAM Swap, Penguatan Arsitektur Dual-Tier Telemetry Engine dengan Cascading Fallback Tanpa Jeda, Rekonstruksi Script Telemetri Shell POSIX Murni, Pendeteksian Dinamis Kolom Proses CPU & Render Grafis, serta Mitigasi Komprehensif Zero-Value State pada Dashboard Utama** — mengatasi kegagalan pembacaan data RAM fisik dan ZRAM swap yang disebabkan oleh sintaks escape shell pada skrip telemetri root; menambahkan ekstraksi data ZRAM dan swap meminfo serta sysfs `disksize` secara presisi ke dalam struktur JSON telemetri modul; mengimplementasikan arsitektur fallback bertingkat (dual-tier cascading fallback) pada `LynxRepository.readTelemetry()` dan `readClusters()` sehingga sistem secara otomatis beralih ke pembacaan langsung sysfs dan meminfo tanpa menampilkan nilai nol apabila skrip eksternal modul mengalami gangguan; memodernisasi pemindaian baris `top` dan `ps` dengan deteksi header kolom dinamis serta toleransi flag `-m` pada pemantau proses CPU dan thread render grafis; memperluas pemantauan status pengisian daya (charging), arus, dan temperatur baterai untuk arsitektur multi-vendor; serta memastikan seluruh indikator hardware beroperasi secara akurat dan konsisten pada build debug maupun release.

## Fitur Baru & Peningkatan (3.0.49)

### 1. Perbaikan Kritis & Pemulihan Telemetri RAM & ZRAM Swap
- **Rekonstruksi Skrip Telemetri Core**: Menghapus seluruh karakter escape ilegal pada `core/lib/telemetry.sh`, memulihkan kompatibilitas POSIX murni di bawah Toybox/sh Android.
- **Integrasi Penuh Swap & ZRAM**: Menambahkan pembacaan `zram_used_mb`, `zram_total_mb`, `swap_used_mb`, dan `swap_total_mb` secara langsung dari `/proc/meminfo`, `/proc/swaps`, serta sysfs `/sys/block/zram0/disksize` ke dalam payload JSON telemetri berkecepatan tinggi (<10ms).
- **Dekopling Urutan Parsing Memori**: Menjamin pembacaan total dan penggunaan RAM tidak terpengaruh oleh urutan baris output kernel pada parser sysfs inline.
- **Sinkronisasi Otomatis Antarmuka**: Menghilangkan status 0 MB pada indikator RAM Fisik dan kartu ZRAM Swap di dashboard beranda serta slider skala alokasi memori virtual, disertai status informatif saat ZRAM dalam kondisi nonaktif (0 MB).

### 2. Penguatan Arsitektur Dual-Tier Telemetry Engine
- **Cascading Fallback Otomatis**: Apabila pembacaan skrip modul root tidak menghasilkan data valid atau melaporkan total memori 0 MB, sistem secara instan mengeksekusi parser sysfs inline internal tanpa jeda dan tanpa mengembalikan nilai null.
- **Topologi Cluster CPU Anti-Gagal**: Memperbarui `readClusters()` dengan mekanisme fallback sysfs bertingkat sehingga informasi cluster CPU tidak akan pernah tertahan pada status 0 Cluster.
- **Deteksi Baterai Multi-Node & Status Charging**: Memperluas probe arus dan temperatur baterai ke node sekunder (`BatteryAverageCurrent`, `current_avg`, `bms/current_now`, `bms/temp`), serta memverifikasi status pengisian daya riil via `battery/status` pada payload telemetri.

### 3. Pendeteksian Dinamis Kolom Proses CPU & Render Grafis
- **Parsing Kolom Header Adaptif**: Menggantikan indeks kolom statis dengan penentuan indeks dinamis berdasarkan nama kolom header (`PID`, `%CPU`, `ARGS`/`CMD`), mencegah kegagalan pembacaan pada berbagai varian Android Toybox.
- **Toleransi Flag Perintah Top**: Menyediakan fallback otomatis dari `top -m` ke `top -b -n 1` standar jika varian Toybox perangkat tidak mendukung argumen pembatasan baris `-m`.
- **Fallback Layanan Sistem**: Menambahkan fallback inspeksi proses via `ps -A` apabila utilitas `top` tidak menghasilkan baris proses, memastikan daftar proses CPU dan thread render grafis selalu terisi aktif.
- **Pengambilan Data Iterasi Awal**: Menjamin pemindaian proses dan topologi cluster langsung dieksekusi pada iterasi pertama loop pemantau tanpa harus menunggu jeda awal 3 detik.

---

# Lynx [Codename: Deity] 3.0.48
Released on: 2026-10-05
> **Versi ini** menghadirkan **Pemisahan Identitas Eksplisit Varian Build Debug & Release, Desain Ikon Adaptif Vektor Mandiri (Cyber Cyan Deity vs Amber Debug Tag), Resolusi Konflik Label Quick Settings Tile, serta Fasilitasi Instalasi Berdampingan Bersih (Side-by-Side Coexistence)** — mengakhiri kebingungan duplikasi aplikasi pada launcher dengan memberikan identitas nama visual terpisah (*Lynx* untuk Release dan *Lynx (Debug)* untuk Debug); mengimplementasikan sistem ikon adaptif modern berbasis vektor Android (API 26+) menggantikan ikon dialog bawaan; menyematkan lencana sudut debug visual dan skema warna oranye pada build pengembang; mengisolasi string nama Quick Settings Tile (*Lynx Profile*, *Lynx HBM*, *Lynx HUD* vs varian Debug); serta menjamin stabilitas instalasi bersamaan antara build produksi dan uji coba tanpa tabrakan resource atau konflik cache.

## Fitur Baru & Peningkatan (3.0.48)

### 1. Diferensiasi Identitas Visual Build (Release vs Debug)
- **Nama Aplikasi Terpisah**: Build produksi resmi dinamai *Lynx* (`com.noir.lynx`), sedangkan build kompilasi uji coba dinamai *Lynx (Debug)* (`com.noir.lynx.debug`).
- **Ikon Adaptif Vektor Mandiri**: Menggantikan ikon dialog sistem bawaan dengan vektor geometris bertema Obsidian & Cyan Deity untuk build rilis.
- **Badge Sudut Pengembang**: Build debug kini otomatis menampilkan aksen amber/oranye dengan lencana sudut pengembang agar dapat dibedakan secara instan di laci aplikasi (app drawer).

### 2. Isolasi Label Quick Settings Tile
- **Pemisahan String Resource**: Label tile Quick Settings di AndroidManifest kini merujuk pada resource lokal terisolasi:
  - *Lynx Profile*, *Lynx HBM*, dan *Lynx HUD* untuk versi Release.
  - *Lynx Profile (Debug)*, *Lynx HBM (Debug)*, dan *Lynx HUD (Debug)* untuk versi Debug.
- **Mencegah Ambiguitas Panel Notifikasi**: Menghilangkan kebingungan saat kedua varian terpasang secara bersamaan pada perangkat pengujian.

### 3. Pembersihan & Harmonisasi Instalasi Multi-Varian
- **Dukungan Coexistence**: Memastikan build release dan debug dapat diinstal berdampingan di lingkungan APatch/Magisk/KernelSU tanpa benturan authority atau permission.
- **Sinkronisasi Installer Modul**: Pembaruan installer modul root [customize.sh](file:///e:/Data/GitHub/Lynx/customize.sh) dan metadata [module.prop](file:///e:/Data/GitHub/Lynx/module.prop) ke versi 3.0.48.

---

# Lynx [Codename: Deity] 3.0.47
Released on: 2026-10-05
> **Versi ini** menghadirkan **Ekspansi Universal Tweak GPU Multi-SoC Lintas Vendor (Qualcomm Adreno, MediaTek Helio/Dimensity/Immortalis, Samsung Exynos, Google Tensor, & Unisoc), Preset Cepat Harmonik 1-Klik (One-Click GPU Profiles), Kartu Akselerasi Hardware Adaptif Mandiri (SoC-Adaptive Acceleration Card), Bypass Buffer Backpressure SurfaceFlinger, serta Sinkronisasi Engine Shell Kernel Terpadu** — memperluas arsitektur tuning grafis dengan membedakan penanganan sysfs secara presisi antara Qualcomm KGSL (PwrLevels, Trustzone target load, DDR bus always-on, rail force), MediaTek GED & FPSGO (Ultra Rescue, DVFS margin, frame pacing), serta ARM Mali Kbase (shader core unmasking, power policy); menyajikan kartu preset cepat 1-klik (*Hemat Daya*, *Seimbang*, *Esports*, *Ekstrem*) dengan aplikasi terpadu ke seluruh lapisan hardware dan pipeline grafis; menambahkan opsi mitigasi latensi sentuh via bypass backpressure SurfaceFlinger; serta memperbarui skrip performa dan keseimbangan Qualcomm dan MediaTek dengan kontrol low-latency terintegrasi.

## Fitur Baru & Peningkatan (3.0.47)

### 1. Preset Cepat Harmonik GPU 1-Klik (One-Click GPU Profiles)
- **4 Profil Khusus Terkoordinasi**: Menyediakan 4 preset instan di bagian atas Tab Tuning:
  - **Hemat Daya (Battery Saver)**: Membatasi frekuensi maksimum hingga ~60% OPP, menonaktifkan boost, mengaktifkan idle timer agresif (20ms), dan mengatur power policy efisien.
  - **Seimbang (Balanced)**: Skalabilitas dinamis harian yang halus dengan latensi sentuh dipercepat dan batas keamanan termal OEM aktif penuh.
  - **Esports (Gaming Stabil)**: Mengunci batas frekuensi bawah (65% clock floor), mengaktifkan bus memori always-on, latch unsignaled, bypass backpressure, dan frame pacing datar.
  - **Ekstrem (Unrestricted)**: Mengunci 100% frekuensi puncak GPU, bypass thermal throttling, boost maksimal, seluruh shader core aktif, dan sampling Trustzone agresif (50%).
- **Feedback Interaktif Visual**: Indikator status aktif yang menyorot preset yang sedang berlaku dan notifikasi toast konfirmasi saat profil berhasil diaplikasikan.

### 2. Kartu Akselerasi Hardware Adaptif (SoC-Adaptive Acceleration Card)
- **Deteksi Karakteristik Hardware Otomatis**: Antarmuka secara cerdas hanya merender setelan yang didukung oleh arsitektur silikon aktif:
  - **Qualcomm Snapdragon (Adreno QTI KGSL)**: Kontrol KGSL Memory Bus Always-On, Adreno Force Rail, Bypass Thermal Throttling, pilihan Idle Timer (20ms s/d 100ms), dan Trustzone Target Load (50% s/d 80%).
  - **MediaTek (Helio, Dimensity, & Immortalis)**: Kontrol MediaTek FPSGO Frame Pacing, FPSGO Ultra Rescue (penyelamat frame drop instan), Mali GED DVFS Margin (+0% s/d +30%), dan bypass thermal throttling vendor.
  - **Mali Kbase / Samsung Exynos / Google Tensor / Unisoc**: Kontrol Unmask Semua Shader Cores (mencegah pemadaman komputasi GPU oleh vendor), Power Policy (`always_on` vs `coarse_demand`), dan devfreq governor.

### 3. Optimasi Pipeline Grafis Universal Android (OS Stack)
- **Bypass SurfaceFlinger Backpressure**: Opsi kontrol langsung `debug.sf.disable_backpressure` dan `debug.sf.enable_gl_backpressure` untuk mengeliminasi antrean buffer yang menyebabkan stutter dan input lag.
- **Harmonisasi Low-Latency Latch**: Mengintegrasikan `debug.sf.latch_unsignaled` secara harmonis ke dalam profil performa dan skrip root module.

### 4. Sinkronisasi Skrip Shell Kernel Root Module
- **Penyempurnaan `platforms/qcom/perf.sh` & `balance.sh`**: Menambahkan deteksi dual node `adrenoboost`/`adreno_boost` pada SoC Snapdragon modern, tuning Trustzone target load, dan reset bersih saat beralih ke mode balance.
- **Penyempurnaan `platforms/mtk/perf.sh` & `balance.sh`**: Memadukan shader core unmasking (`0xFF` ke seluruh node `core_mask`) dan injeksi otomatis DVFS margin value ke dalam eksekusi profil.

---

# Lynx [Codename: Deity] 3.0.46
Released on: 2026-10-05
> **Versi ini** menghadirkan **Perombakan Menyeluruh Diagnostik GPU & Display Info, Eliminasi Total Pemotongan Teks (Zero-Truncation Policy), Integrasi Deteksi Ganda Hardware Vulkan API (PackageManager & Shell Driver Probing), Normalisasi Pelabelan Node Sysfs Kernel, serta Pembersihan Residu Format AI** — merombak tata letak subhalaman Info GPU & Display menjadi antarmuka diagnosa engineering yang presisi dan profesional; meniadakan seluruh pembatasan baris dan pemotongan teks elipsis (`...`) pada spesifikasi, judul, dan path file driver; menyempurnakan deteksi Vulkan melalui inspeksi fitur sistem Android native sehingga versi API dan driver teridentifikasi akurat; memperbaiki parser loop pengecekan sysfs sehingga seluruh node kernel tampil dengan nama deskriptif utuh berbahasa Indonesia; menempatkan tombol segarkan secara ergonomis di header kartu identitas silikon; serta menyingkirkan pengulangan subtitle redundan demi keterbacaan optimal.

## Fitur Baru & Peningkatan (3.0.46)

### 1. Perombakan Total Desain Subhalaman GPU & Display Info
- **Hierarki Diagnostik Engineering**: Menggantikan pola komponen generik berulang dengan tata letak grid spesifikasi simetris terstruktur yang memadukan identitas silikon, runtime grafis, karakteristik fisik panel layar, pipeline komposisi grafis, dan inspeksi node kernel.
- **Header Refresh Ergonomis**: Memindahkan tombol segarkan diagnostik dari bagian bawah kartu yang terisolasi ke slot aksi header `Identitas Silikon & Driver` untuk aksesibilitas yang cepat dan bersih.
- **Pembersihan Subtitle Redundan**: Menghilangkan pengulangan label dan sub-label identik (seperti repetisi ruang warna dan deskripsi klise) sehingga setiap baris metrik memberikan informasi teknis bernilai tinggi.

### 2. Standarisasi Tampilan Tanpa Pemotongan (Zero-Truncation Architecture)
- **Eliminasi Elipsis Total**: Menghapus seluruh atribut `TextOverflow.Ellipsis` dan `maxLines = 1` pada kartu diagnosa GPU, baris spesifikasi, dialog, dan jalur driver biner.
- **Soft Wrapping Monospace Terarah**: Menerapkan pemenggalan baris fleksibel (`softWrap = true`) dan font monospace terstruktur pada nama path binary driver fisik dan direktori sysfs sehingga pengguna dapat membaca dan memverifikasi path secara utuh.
- **Tinggi Kartu Simetris (`IntrinsicSize.Min`)**: Mengunci tinggi baris kartu spesifikasi berpasangan menggunakan pengukuran intrinsik minimum agar tidak terjadi ketimpangan visual antar-kolom.

### 3. Deteksi Ganda Vulkan API Berakurasi Tinggi
- **Framework Fallback Direct Inspection**: Mengintegrasikan pengecekan native `PackageManager.systemAvailableFeatures` untuk mendeteksi `android.hardware.vulkan.version` dan `android.hardware.vulkan.level` secara instan dan tanpa latensi proses.
- **Sinkronisasi Driver ID**: Memadukan data instance runtime dari `cmd gpu vkjson` dengan spesifikasi hardware untuk menyajikan versi API Vulkan (contoh: `Vulkan 1.1.0 (Level 1)`) dan nama driver asli (`Native Vulkan Driver` / `Mali-G57 MC2`) tanpa kesalahan deteksi.
- **Resolusi Chipset Otentik**: Menampilkan penamaan keluarga chipset spesifik (seperti `MediaTek Helio G96`) berdasarkan platform board hardware aktual.

### 4. Pelabelan Utuh Node Kernel GPU & Sysfs
- **Pembersihan Bug Shell Parsing**: Menggantikan iterasi whitespace-split yang rentan memotong nama node menjadi satu kata (`Mali`) dengan fungsi pemeriksaan shell langsung.
- **Nama Deskriptif Utuh**: Menyajikan identitas node secara lengkap dalam bahasa Indonesia (contoh: `Mali GED Frekuensi Aktif`, `Mali GED Utilisasi GPU`, `Mali GED Boost Level`, `MediaTek FPSGO Dynamic Engine`) disertai badge izin akses `R/W` dan `RO`.

---

# Lynx [Codename: Deity] 3.0.45
Released on: 2026-10-05
> **Versi ini** menghadirkan **Sticky Header Tab Row Subhalaman GPU & Display, Validasi Ketat Dukungan Hardware/OS terhadap Pipeline Rendering Grafis (HWUI Backends & ANGLE), Integrasi Icon Aplikasi Riil (Native PackageManager App Icons) dengan Caching Memori Berkecepatan Tinggi, Deteksi Multi-Tingkat Anti-Spoofing Berbasis Kernel Ground Truth, serta Ekspansi Telemetri GPU & Display Mendalam** — menempatkan tab navigasi (`Tuning`, `Lab`, `Info`) secara permanen di bagian atas layar agar tidak tergulung saat konten di-scroll; memverifikasi secara langsung ketersediaan Vulkan, Graphite (Android 14+), dan ANGLE pada level sistem operasi dan menonaktifkan opsi yang tidak didukung secara elegan; memuat icon aplikasi asli dari sistem Android untuk setiap judul game pada manajemen rendering dengan dukungan `LruCache` berkapasitas 150 item; mendeteksi manipulasi identitas SoC dan GPU oleh modul luar/spoofer melalui pengecekan kebenaran mutlak kernel Linux (DTB, node driver karakter, dan sysfs internal) disertai alert peringatan dan matriks perbandingan; serta memperkaya telemetri display dengan DPI, faktor densitas, format ruang warna aktif, dan status SurfaceFlinger Hardware Composer.

## Fitur Baru & Peningkatan (3.0.45)

### 1. Sticky Header Tab Row Subhalaman GPU & Display
- **Posisi Tab Tetap (Non-Scrollable Anchor)**: Memindahkan `GpuDisplayTabRow` ke antara top bar navigasi dan scrollable container, menjamin tab `Tuning`, `Lab`, dan `Info` tetap terlihat dan dapat diakses cepat kapan pun pengguna menggulir halaman.
- **Normalisasi Margin & Padding**: Menghilangkan redundansi padding horizontal ganda (inset 32dp menjadi 16dp terpadu) agar lebar tab simetris dengan batas tepi kartu konten.

### 2. Validasi Sistem Terhadap Pipeline Rendering Grafis (HWUI & ANGLE)
- **Verifikasi Ketersediaan Backend**: Sistem memeriksa kapabilitas perangkat secara aktual sebelum mengizinkan pemilihan renderer. SkiaVK diverifikasi via ketersediaan Vulkan, Graphite diverifikasi via Android 14+ (API 34) dan Vulkan, serta ANGLE diverifikasi via keberadaan layer terpasang atau APEX.
- **Visual Feedback & Proteksi Klik**: Opsi pipeline yang tidak didukung oleh hardware atau OS otomatis diredupkan (alpha 0.45), dikunci dari interaksi sentuh, dan diberi badge informatif `Tidak Didukung`.
- **Proteksi Saklar ANGLE Per-Aplikasi**: Pada modal konfigurasi Game Driver, saklar translasi ANGLE dinonaktifkan jika sistem tidak mendukung library translasi tersebut.

### 3. Icon Aplikasi Asli (Native PackageManager) & Caching Memori
- **Dukungan Icon Riil**: Menghapus placeholder icon generik dan memuat icon aplikasi resmi yang terpasang di sistem (`PackageManager.getApplicationIcon`) pada Per-App Graphics Hub, dialog pencarian aplikasi (App Picker), dan dialog pengaturan rule.
- **LruCache Berkecepatan Tinggi**: Mengimplementasikan `LruCache<String, ImageBitmap>` dengan batas 150 icon untuk mencegah pembacaan ulang I/O disk dan menjaga frame rate rendering antarmuka tetap stabil pada 120Hz.

### 4. Perlindungan Anti-Spoofing & Telemetri Kernel Ground Truth
- **Pengecekan Kebenaran Mutlak Hardware**: Menginspeksi kompatibilitas Device Tree Blob kernel (`/sys/firmware/devicetree/base/compatible`), node karakter driver GPU (`/dev/mali0`, `/dev/ged`, `/dev/kgsl-3d0`), dan sysfs internal yang tidak dapat dipalsukan oleh modul spoofer userspace.
- **Banner Peringatan Spoofer**: Jika terdeteksi ketidakcocokan antara arsitektur hardware kernel dengan properti userspace (`ro.soc.manufacturer`, `ro.board.platform`, `dumpsys SurfaceFlinger`), antarmuka menampilkan kartu peringatan manipulasi identitas dan tabel komparasi berdampingan.
- **Badge Integritas Hardware**: Menampilkan konfirmasi status integritas terverifikasi jika tidak terdeteksi adanya manipulasi data.

### 5. Ekspansi Metrik Telemetri GPU & Display
- **Metrik Panel Display**: Menyajikan resolusi display, densitas DPI fisik dan float ratio, format ruang warna aktif (DCI-P3 / sRGB), dukungan HDR, serta versi SurfaceFlinger Hardware Composer (HWC).
- **Metrik Driver GPU**: Menyajikan Vulkan API version beserta driver ID, jalur file library driver GPU fisik (`/vendor/lib64/egl/...`), dan path node sensor suhu internal.

---

# Lynx [Codename: Deity] 3.0.44
Released on: 2026-10-05
> **Versi ini** menghadirkan **Pembersihan Total Residu Emotikon & Pseudo-Font pada Seluruh Modul Core, WebUI, CLI Interaktif, Installer, dan Daemons (Strict Universal Zero-Emoji Professional Standard), Transisi ke Indikator Bracket Standar POSIX Linux, Standardisasi Notifikasi Sistem Bersih, serta Konsistensi Desain Antarmuka Tanpa Distorsi Visual** — menuntaskan pembersihan sisa emotikon dan karakter pseudo-font matematika pada seluruh repositori (`hw_probe.sh`, `flasher.sh`, `dns.sh`, `dex2oat.sh`, `zram.sh`, `swap.sh`, `lynx` CLI menu interaktif, `Lxcore`, `package_module.sh`, `customize.sh`, `service.sh`, `action.sh`, `tests/mock_sandbox/run_test.sh`, `webroot/app.js`, `webroot/index.html`, dan `module.prop`); menggantikan seluruh dekorasi visual berlebihan dengan indikator bracket standar profesional (`[*]`, `[+]`, `[!]`, `[OK]`, `[ERROR]`); serta menjamin seluruh komponen antarmuka, konsol CLI, dan log telemetri tampil bersih, rapi, estetik, dan berstandar teknis tinggi.

## Fitur Baru & Peningkatan (3.0.44)

### 1. Eliminasi Menyeluruh Residu Emotikon & Karakter Pseudo-Font
- **Hardware Probing & Sub-Profiles (`hw_probe.sh`)**: Menghilangkan seluruh simbol dekoratif pada log verifikasi hardware dan pemanggilan sub-profil GPU/Board, beralih ke format tag teknis `[*] Loading targeted profile` dan `[OK] Hardware Verified`.
- **AnyKernel3 Flasher & Partition Guard (`flasher.sh`)**: Menstandarkan seluruh luaran pencadangan partisi boot/init_boot dan flashing kernel menggunakan tag `[OK]` dan `[ERROR]`.
- **Networking & DNS Controller (`dns.sh`)**: Menghapus teks unicode bergaya tebal miring dan simbol dekoratif pada notifikasi provider DNS.
- **Memory & ART Compilation Optimization (`dex2oat.sh` & `zram.sh`)**: Membersihkan deskripsi status modul dan toast notifikasi sistem saat kompilasi ART dan manajemen ZRAM dieksekusi.
- **Installer & Volume Key Selector (`customize.sh` & `addon/Volume-Key-Selector/install.sh`)**: Menghilangkan simbol emoji pada peringatan batas waktu pemilihan tombol volume dan konfirmasi arsitektur chipset.

### 2. Standar Baru Konsol Interaktif CLI (`system/bin/lynx` & `Lxcore`)
- **Menu Navigasi Bersih**: Membersihkan seluruh menu profil performa (Auto, Balance, Performance, Extreme, Powersave, Standby), menu pengisian daya, tombol fitur lanjutan, dan menu switch BusyBox dari dekorasi emotikon.
- **Umpan Balik Eksekusi Rapi**: Mengganti pesan sukses dan galat CLI dengan tag indikator konsisten `[OK]` dan `[ERROR]`.

### 3. Konsistensi WebUI & Metadata Modul
- **Dashboard & SoC Tuner**: Menjamin seluruh kartu kontrol, badge status, tombol aksi, dan dialog peringatan bebas dari simbol amatir, menggunakan representasi Material Vector SVG yang presisi.
- **Module Metadata (`module.prop`)**: Memperbarui deskripsi modul menjadi teks standar bersih tanpa karakter terdistorsi.

---

# Lynx [Codename: Deity] 3.0.43
Released on: 2026-10-05
> **Versi ini** menghadirkan **Pembersihan Total Estetika Antarmuka & Eliminasi Menyeluruh Dekorasi Emotikon (Strict Zero-Emoji Professional Clean Architecture), Standardisasi Ikon Vektor Material Design pada Seluruh Panel Kontrol, Penataan Bahasa Sistem Ringkas & Lugas Tanpa Clutter, serta Konsistensi Komponen Interaktif Seluruh Subhalaman** — membasmi tuntas seluruh penggunaan emotikon visual yang berlebihan dan tidak teratur pada chip pemilih (Auto refresh rate, Game Driver, ANGLE Vulkan, HWUI backends), tombol kontrol profil CPU/GPU, banner notifikasi latar belakang, Floating HUD OSD, dan dialog sistem; mentransisikan seluruh representasi visual ke ikon vektor Material Design yang presisi dan elegan; serta menyelaraskan hierarki tipografi dan redaksi teks agar berstandar perangkat lunak tuning kernel tingkat profesional tanpa distorsi visual.

## Fitur Baru & Peningkatan (3.0.43)

### 1. Eliminasi Total Emotikon Clutter pada Chip & Selektor Antarmuka
- **Refresh Rate & Display Selector**: Menghilangkan emotikon pada indikator Auto dan opsi fixed Hz (`Auto (60 Hz)` dan `Auto` menggantikan format lama yang memuat emotikon).
- **Game Driver & HWUI Pipeline**: Menstandarkan label driver grafis (`Bawaan Sistem`, `Game Driver (Semua App)`) dan kelima backend HWUI (`Default`, `SkiaGL`, `SkiaVK`, `Graphite`, `ANGLE`) dengan tipografi bersih.
- **Per-App Graphics Hub Badges**: Menghilangkan simbol emotikon pada badge driver, translasi ANGLE, dan refresh rate per-aplikasi.

### 2. Transisi Penuh ke Ikon Vektor Material Design
- **CPU & GPU Profile Buttons**: Menggantikan representasi teks bergaya emotikon dengan Material Vector Icons resmi (`SportsEsports` untuk Gaming, `Balance` untuk Seimbang, `BatteryChargingFull` untuk Hemat Daya, dan `Tune` untuk Mode Pakar).
- **Floating Game HUD & OSD**: Memperbarui status button pada overlay game (Float, Boost RAM, Pin FPS) dengan teks bersih dan ikon pin vektor presisi.

### 3. Redaksi Bahasa Komunikatif, Tegas & Profesional
- **Notifikasi Latar Belakang & Daemon**: Membersihkan pesan shell notification dan daemon runner dari simbol yang tidak perlu.
- **Dialog & Banner Sistem**: Mengoreksi judul modal peringatan termal, dialog konfirmasi pemulihan partisi, serta kartu laporan live benchmark agar terbebas dari kesan tampilan tidak terstruktur.

---

# Lynx [Codename: Deity] 3.0.42
Released on: 2026-10-05
> **Versi ini** menghadirkan **Matriks Universal Pengisian Daya Cepat & Bypass Termal Lintas SoC & OEM (Universal Multi-SoC & Multi-OEM Dynamic Fast Charging & Hardware Throttle Bypass), Penembus Batas Derating Layar Nyala Multi-Vendor (Samsung One UI SIOP, OnePlus/OPPO SuperVOOC Cool Mode, Xiaomi HyperOS Joyose/Current Boost, Google Tensor, ASUS ROG, & Motorola), Telemetri Dinamis Deteksi IC PMIC & Protokol Fast Charge Real-Time, serta Penguncian Hak Akses Sysfs Berlapis (chmod 444 Anti-Rollback Guard)** — memperluas kendali pengisian daya cerdas dan bypass pengisian dari yang sebelumnya berorientasi spesifik ke Transsion/MediaTek menjadi arsitektur universal yang secara cerdas mendeteksi dan membuka batas daya pada Qualcomm Snapdragon (SMB1390/1355 direct pump & PM8150), Samsung Exynos/Snapdragon (`siop_level 100`, direct charger mode), OnePlus/Oppo/Realme (`cool_mode 0`, `call_mode 0`, SuperVOOC user type), Xiaomi/HyperOS (`thermal_input_current_limit 6000000`, boost current, Joyose suspend), Google Tensor (Pixel `charge_stop_level`, trickle dry run), ASUS ROG, dan Motorola; menyelaraskan telemetri aplikasi dan daemon shell untuk mengidentifikasi jenis IC konverter dan protokol pengisian aktif (SuperVOOC, AFC, Super Fast Charging 25W/45W, HyperCharge, Pump Express, QC, PD PPS); serta memastikan pengisian cepat tetap melaju dengan daya maksimal baik saat layar hidup maupun mati tanpa hambatan regulasi termal OEM.

## 🚀 Fitur Baru & Peningkatan (3.0.42)

### 1. ⚡ Matriks Pengisian Cepat Universal Lintas SoC & OEM (All-Device Dynamic Fast Charge)
- **Universal Linux Power Rails**: Membuka batas arus pengisian daya kernel universal (`constant_charge_current_max` hingga 6000mA / 6A, `input_current_limit`, `current_max`) dengan penguncian read-only `chmod 444` untuk mencegah kernel dan HAL mereset nilai batas.
- **Qualcomm Snapdragon Rails**: Mengaktifkan `fastcharge_mode`, mematikan pembatasan arus (`restricted_charging = 0`), menaikkan `restrict_cur` ke 6000000, serta mengaktifkan `direct_charging` pada PMIC Qualcomm (SMB1390 / SMB1355).
- **MediaTek Dimensity & Helio Rails**: Membuka Pump Express 4.0 & 2.0, menyetel batas watt maksimum (`pdc_max_watt = 120`), menaikkan step limit IC RT9759 (`input_current`, `chg1_current`, `chg2_current = 24576`), dan menonaktifkan JEITA thermal clamp (`sw_jeita = 0`).

### 2. 🛡️ Penembus Batas Throttling Layar Nyala Multi-Vendor (Multi-OEM Screen-On Bypass)
- **Samsung One UI (Exynos & Snapdragon)**: Memaksa `siop_level = 100` dengan penguncian `chmod 444`, menonaktifkan `store_mode` dan `batt_slate_mode`, serta mengaktifkan `direct_charger_mode` dan `afc_result` sehingga Samsung tidak memangkas arus saat layar menyala.
- **OnePlus, OPPO & Realme (ColorOS / OxygenOS)**: Mengunci `cool_mode = 0` dan `call_mode = 0` dengan `chmod 444`, serta mengaktifkan `vooc_charging` dan `fast_charge_user_type = 1` agar SuperVOOC / Warp Charge tetap mengisi dengan kecepatan penuh saat layar aktif.
- **Xiaomi & HyperOS (MIUI)**: Mengatur `thermal_input_current_limit = 6000000`, mengaktifkan `boost_current = 1`, mematikan `step_charging_enabled`, serta menangguhkan daemon pembatas termal Joyose (`killall -STOP com.xiaomi.joyose`) selama mode ekstrem aktif.
- **Google Tensor (Pixel)**: Mengatur `charge_stop_level = 100` dan menonaktifkan `bd_trickle_dry_run`.
- **ASUS ROG & Motorola**: Menyetel `smart_charging = 0` dan `charging_limit_mode = 0` (ASUS ROG), serta mengaktifkan `mmi_charging_enable = 1` dan `factory_mode = 1` (Motorola).

### 3. 🔍 Telemetri Dinamis Deteksi IC PMIC & Protokol Fast Charge Real-Time
- **Identifikasi PMIC Otomatis**: Mendeteksi secara langsung hardware IC pengisi daya aktif: RT9759 (Direct Charge Pump 2:1), Qualcomm SMB1390/1355 Dual-Pump, Samsung S2MU/Maxim Direct Charger, Xiaomi HyperCharge Dual-Pump (LN8000/SC8551), OnePlus SuperVOOC Pump, atau Google Tensor PMIC (MAX77759).
- **Deteksi Protokol Pengisian Akurat**: Menampilkan protokol aktif secara presisi (Transsion Super Charge 33W/45W/68W RFC, OnePlus SuperVOOC / Warp Fast Charge, Xiaomi HyperCharge 67W-120W, Samsung Super Fast Charging 25W/45W, Qualcomm QC3.0/QC4+/QC5, USB Power Delivery / PPS, atau High Current 5V).
- **Sinkronisasi Shell Controller**: Menyinkronkan fungsi `dump_telemetry_json` di `core/Charging-Controller.sh` dan `readBatteryDetails()` di Lynx Companion Kotlin repository agar menghasilkan struktur data yang identik dan konsisten.

### 4. 🔄 Penyelarasan Subsistem Profil Otomatis (DRY Modular Alignment)
- **Modular Shell Invocation**: `core/apply_profile.sh` kini secara modular mendelegasikan konfigurasi pengisian daya langsung ke `Charging-Controller.sh apply`, menjamin aturan bypass dan pengisian cepat selalu sinkron di seluruh profil performa tanpa duplikasi kode.

---

# Lynx [Codename: Deity] 3.0.41
Released on: 2026-10-05
> **Versi ini** menghadirkan **Live Monitor Telemetri GPU Presisi 1 Detik (1000ms Real-Time Drift-Compensated Polling), Normalisasi Beban Komputasi Proses Grafis Multi-Core (Zero CPU Overflow), Efisiensi Pembacaan Top Process Latar Belakang (2.5s Adaptive Cache), serta Pemantapan Tata Letak Antarmuka GPU & Display Bersih & Responsif (Strict Touch-First Obsidian Dark Architecture)** — menyelaraskan siklus pembaruan grafik gelombang Bezier GPU, ring-buffer beban 30 detik, dan telemetri clock hardware tepat setiap 1 detik tanpa fluktuasi waktu; membagi persentase CPU proses render grafis dengan jumlah core aktif sehingga tidak lagi menampilkan nilai di atas 100%; mengeliminasi beban CPU saat polling dengan isolasi cache 2.5 detik untuk scan proses berat; serta memastikan tata letak subhalaman GPU & Display tertata rapi, bersih, bebas tumpang tindih elemen, dan sepenuhnya mematuhi standar desain mobile-first.

## 🚀 Fitur Baru & Peningkatan (3.0.41)

### 1. ⏱️ Polling Live Monitor GPU Real-Time 1 Detik (1000ms Drift-Compensated Interval)
- **Sinkronisasi Setiap Detik**: Memperbarui telemetri GPU (`readGpuInfo`) tepat setiap 1 detik (1000ms) di loop `startTelemetryPolling`, menggantikan siklus 2 detik sebelumnya.
- **Drift-Compensated Delay**: Menghitung waktu eksekusi aktual (`1000ms - elapsed`) dengan batas pengaman 150ms agar ritme pembacaan tetap presisi tanpa lonjakan lag.
- **Waveform Canvas 30 Detik Lebih Responsif**: Grafik kurva Bezier dan ring-buffer beban GPU kini menerima titik sampel baru secara mulus setiap 1 detik dengan titik pulsa bercahaya (*glowing pulse dot*) yang bergerak dinamis.

### 2. 🎯 Normalisasi Beban CPU Proses Grafis (Multi-Core Aware)
- **Koreksi Persentase CPU**: Menormalkan metrik utilisasi dari perintah `top` dengan membagi nilai mentah terhadap jumlah prosesor logis perangkat (`rawCpu / numCores`), mencegah angka anomali di atas 100% pada CPU multi-core.
- **Badge Beban Bersih**: Menampilkan kontribusi beban SurfaceFlinger, Game, dan proses grafis dalam rentang terstandarisasi 0%–100%.

### 3. ⚡ Optimasi Scan Latar Belakang (2.5-Second In-Memory Cache)
- **Sub-10ms Polling Execution**: Menambahkan proteksi in-memory cache selama 2500ms pada `readTopGraphicsProcesses()`, sehingga pembacaan sysfs frekuensi/suhu GPU setiap 1 detik berjalan instan (<10ms) tanpa membebani CPU dengan pemanggilan shell berat berulang-kali.

### 4. 🎨 Pemantapan Tata Letak & Estetika Antarmuka (Clean & Touch-First)
- **Hierarki Kartu Visual Terstruktur**: Menata 5 kartu kontrol utama secara berjenjang (Master Tuner, Engine Pipeline, Per-App Hub, Refresh Rate, Color Management) dengan margin dan padding yang proporsional.
- **Kepatuhan Touch-First**: Seluruh chip, tombol aksi, dan slider memiliki target sentuh minimal 48dp tanpa elemen bertabrakan di seluruh rasio layar.

---

# Lynx [Codename: Deity] 3.0.40
Released on: 2026-10-05
> **Versi ini** menghadirkan **Fast Charging Ekstrem Tanpa Batas Termal Layar Nyala & Layar Mati (Unrestricted Screen-On Fast Charging & Full Hardware Thermal Bypass), Penembus Batas Termal PCB Transsion/MediaTek (Uncapped 85°C / 6000mA via pcb_thermal_debug), Pembuka Register Maksimum IC RT9759 (24576 Raw Step Limit / 33W Pump Express 4.0), Penguncian Hak Akses Sysfs Anti-Reset (chmod 444 Hardware Lock), serta Sistem Persistensi Cerdas Hibrida (LynxPowerReceiver ACTION_POWER_CONNECTED, Boot Restorer & Watchdog Latar Belakang 60 Detik)** — memecahkan pembatasan pengisian daya bawaan OEM Transsion dan MediaTek yang sebelumnya memangkas arus pengisian ke 1500mA saat temperatur PCB mencapai 44°C atau saat layar menyala; membuka rel arus hingga 6000mA dan arus register IC pompa RT9759 ke 24576; mematikan intervensi thermal zone AP/PCB (`thermal_zone1/mode disabled`); menonaktifkan seluruh cooling device (`abcct`, `bcct`, `cdev2`) dengan penguncian read-only; serta menjamin persistensi pengisian cepat tanpa interupsi saat kabel dicolok ulang atau saat ponsel ditinggal berjam-jam tanpa perlu intervensi manual pengguna.

## 🚀 Fitur Baru & Peningkatan (3.0.40)

### 1. 🔥 Unrestricted Screen-On Fast Charging (Penghancur Batas Throttling Layar Nyala)
- **Bypass Throttling Layar Nyala OEM**: Menghilangkan penurunan kecepatan pengisian saat layar aktif (`BN_TestMode = 1`, `BatteryNotify = 0`, `tran_charger_full = 0`), menjaga baterai tetap mengisi dengan arus penuh saat bermain game atau memutar media.
- **Transsion ODM PCB Thermal Clamp Override (85°C / 6000mA)**: Mengganti batas PCB bawaan 45°C/1500mA menjadi `[85,6000,90,5000,4500]` pada node `pcb_thermal_debug`, mencegah algoritma PCA (`dv2_algo_task`) masuk ke status darurat termal level 7.
- **Uncap Register IC RT9759 (24576 Steps)**: Membuka batas arus register keras pompa pengisian MediaTek RT9759 (`input_current`, `chg1_current`, `chg2_current`) hingga batas hardware maksimum 24576.

### 2. 🛡️ Penonaktifan Thermal Throttling & Penguncian Hak Akses Sysfs (Read-Only Lock)
- **Disable AP/PCB Thermal Zone**: Mematikan mode pemantauan termal pada `/sys/class/thermal/thermal_zone1/mode` dan menguncinya dengan `chmod 444` agar sistem tidak dapat mengaktifkannya kembali.
- **Zero-Out & Read-Only Cooling Devices**: Mereset seluruh state cooling devices baterai dan charger (`abcct`, `bcct`, `cdev2`) ke `0` dan menguncinya dengan `chmod 444`.
- **Framework Thermal Status Override**: Memaksa status framework Android ke kondisi dingin (`cmd thermalservice override-status 0`).

### 3. ⚡ Sistem Persistensi Cerdas Hibrida (Watchdog & Power Listener)
- **LynxPowerReceiver (ACTION_POWER_CONNECTED)**: Menangkap broadcast saat kabel pengisi daya dicolokkan ke perangkat, seketika menegaskan ulang bypass pengisian cepat tanpa jeda.
- **Pemulihan Boot Otomatis (LynxBootReceiver)**: Mengembalikan konfigurasi pengisian cepat yang tersimpan seketika saat ponsel menyala (cold boot).
- **Background Watchdog 60 Detik**: Mengawasi status pengisian di `LynxAppAutomationService` setiap 60 detik selama kabel terhubung untuk memastikan kernel tidak mereset status bypass secara diam-diam.
- **Live Active Assertion**: Memeriksa dan memperkuat kunci bypass termal secara berkala saat pengguna berada di subhalaman Baterai & Pengisian Daya.

---

# Lynx [Codename: Deity] 3.0.39
Released on: 2026-10-05
> **Versi ini** menghadirkan **Master GPU Hero Card dengan Real-Time Bezier Waveform Canvas (Grafik Beban GPU 30 Detik, Peak Marker & Indikator Pulse) dan Top 5 Proses Render Grafis Aktif (SurfaceFlinger / RenderThread), GPU Governor Berlabel Semantik Manusiawi (Smart Descriptive Chips & Kartu Edukatif Karakteristik Teknis), 5-Engine UI Rendering Pipeline (Default Sistem, SkiaGL, SkiaVK, Skia Graphite Android 14+, dan Translasi ANGLE Khronos Vulkan dengan Badge Kompatibilitas), serta Manajemen Rendering Per-Aplikasi (Game Driver Hub)** — mengubah subhalaman *GPU & Display* menjadi pusat kendali rendering terlengkap setara konsol dan workstation tuning grafis modern; menggantikan tampilan utilisasi GPU lama dengan kanvas grafik gelombang Bezier bergradien dinamis dan pemantau proses grafis aktif berikon visual; menerjemahkan angka biner dan mode mentah MediaTek Mali GED (`0`, `1`, `2`) serta governor Qualcomm menjadi deskripsi teknis yang mudah dipahami; memperluas pipeline compositing HWUI ke 5 backend termasuk Skia Graphite modern dan translasi ANGLE; serta menyediakan kartu khusus manajemen game driver per aplikasi dengan dialog pencarian aplikasi terpasang, pemilihan driver (Default / Game Driver / Prerelease), switch translasi ANGLE Vulkan, dan penguncian refresh rate layar per judul game.

## 🚀 Fitur Baru & Peningkatan (3.0.39)

### 1. 📈 Master GPU Hero Card (Real-Time Bezier Waveform & Top Render Processes)
- **30-Second Bezier Waveform Canvas**: Menampilkan grafik fluktuasi beban komputasi GPU secara real-time dengan kurva Bezier mulus, grid halus (25%, 50%, 75%), gradien vertikal amber bercahaya, titik puncak (*peak marker*), dan indikator *glowing pulse dot* pada sampel data terbaru.
- **Top 5 Proses Render Grafis Aktif**: Mendeteksi dan menampilkan daftar 5 aplikasi/proses yang sedang aktif membebani SurfaceFlinger dan GPU (seperti game, SystemUI, Chromium renderers) lengkap dengan ikon tipe proses, nama paket, dan badge persentase beban komputasi.

### 2. 🧠 Governor GPU Semantik & Kartu Edukatif Karakteristik Teknis
- **Label Manusiawi Cerdas**: Menggantikan angka mentah MediaTek Mali GED (`0`, `1`, `2`) dengan chip deskriptif (`0 • Dinamis (Bawaan GED)`, `1 • Performa (Low-Latency)`, `2 • Agresif (Kustom)`) serta label informatif untuk Qualcomm Adreno (`msm-adreno-tz (TrustZone AI)`, `performance (Maksimal)`, dsb.).
- **Kartu Edukatif Real-Time**: Menyematkan kartu penjelasan teknis di bawah pilihan governor untuk mengedukasi pengguna mengenai karakteristik algoritma scaling daya dan respon clock dari profil yang dipilih.

### 3. ⚡ 5-Engine UI Rendering Pipeline (HWUI & Compositing Backend)
- **Ekspansi 5 Pipeline Render**: Menyediakan selektor backend compositing antarmuka dan canvas dengan 5 opsi lengkap: *Default Sistem [Stabil]*, *SkiaGL [OpenGL ES]*, *SkiaVK [Vulkan]*, *Skia Graphite [Android 14+]*, dan *ANGLE [Khronos Vulkan]*.
- **Badge Kompatibilitas & Edukasi**: Indikator status cerdas yang memberitahukan ketersediaan library dan batas minimum versi Android (misal Android 14+ untuk Skia Graphite) tanpa memicu crash sistem.

### 4. 🎮 Manajemen Rendering Per-Aplikasi (Game Driver Hub)
- **Konfigurasi Khusus per Judul Game**: Mengoptimalkan rendering setiap game secara individual memanfaatkan framework Android AOSP `GAME_DRIVER_OPT_IN_APPS`, `GAME_DRIVER_PRERELEASE_OPT_IN_APPS`, dan `ANGLE_ENABLED_FOR_PACKAGES`.
- **App Picker Modal Cepat**: Dialog pemilihan aplikasi terpasang dengan filter pencarian real-time untuk memilih game target dengan mudah.
- **Dialog Pengaturan Lengkap**: Kontrol menyeluruh per game mencakup pemilihan Tipe Driver (Default, Game Driver, Prerelease), sakelar Translasi ANGLE (OpenGL → Vulkan), dan penguncian Refresh Rate Layar (Bawaan, 60Hz, 90Hz, 120Hz).
- **Manajemen Mandiri**: Tombol edit dan hapus aturan per aplikasi untuk fleksibilitas total pengguna.

---

# Lynx [Codename: Deity] 3.0.38
Released on: 2026-10-05
> **Versi ini** menghadirkan **Pembersih Shader & Pipeline Cache Grafis Universal (Shader Cache Manager), Live Telemetri Suhu Silikon GPU & Indikator Thermal Throttling, Tunable Driver Kernel Lanjutan SoC (Adreno Idle Timer & MediaTek Mali GED DVFS Margin), serta Integrasi Floating Game HUD Overlay (In-Game OSD)** — menyempurnakan subhalaman *GPU & Display* menjadi ekosistem tuning grafis profesional setara Scene dan Franco Kernel Manager (FKM); membasmi tuntas masalah *shader compilation micro-stutter* pada game 3D melalui pemindaian dan pembersihan aman berkas `.shaders_cache` OpenGL & Vulkan tanpa menyentuh data login atau save game pemain; menampilkan live telemetri temperatur silikon GPU (°C) secara langsung di header tuner dengan peringatan visual saat thermal throttling terjadi; memberikan kontrol presisi terhadap parameter kernel low-latency seperti *Adreno Idle Timer* (20ms–100ms) dan *Mali GED DVFS Margin* (+0% s/d +30%); serta menyematkan kartu kendali *Floating Game HUD Overlay* di tab Lab agar gamer dapat memantau FPS, Frame Time, beban GPU, dan suhu secara real-time di atas game fullscreen dengan beragam gaya tampilan (RTSS Slim Pillar, Top Ribbon, Dual-Block, dsb.).

## 🚀 Fitur Baru & Peningkatan (3.0.38)

### 1. 🧹 Pembersih Shader & Pipeline Cache Grafis (Shader Cache Manager)
- **Pemindaian Kapasitas Cache Real-Time**: Menghitung secara otomatis ukuran total dan jumlah berkas shader cache (`com.android.opengl.shaders_cache` dan `com.android.skia.shaders_cache`) yang terakumulasi di seluruh sistem dan game 3D.
- **Pembersihan Sekali Ketuk (One-Tap Purge)**: Tombol pembersih dengan dialog konfirmasi aman yang menghapus cache shader usang atau korup tanpa merusak save game atau kredensial akun pengguna, memastikan GPU mengompilasi shader baru yang bersih dan bebas stuttering.

### 2. 🌡️ Live Telemetri Suhu GPU & Indikator Thermal Throttling
- **Direct Silicon Temp Probe**: Membaca sensor termal silikon GPU secara presisi lintas arsitektur SoC (Qualcomm Adreno `/sys/class/kgsl/kgsl-3d0/temp`, MediaTek Mali thermal zones `gpu`/`mali`/`mtktsAP`, Samsung Exynos `/sys/kernel/gpu/gpu_temp`).
- **Indikator Throttling Cerdas**: Menampilkan badge temperatur berkode warna (Hijau <50°C, Oranye 50–64°C, Merah >=65°C) serta banner peringatan visual jika frekuensi GPU dipangkas akibat regulasi termal kernel.

### 3. ⏱️ Parameter Lanjutan Driver Kernel SoC (Kernel Tunables)
- **Adreno Idle Timer (Qualcomm Snapdragon)**: Opsi setelan batas waktu idle GPU (20ms, 40ms, 64ms Bawaan, 80ms, 100ms) via `/sys/class/kgsl/kgsl-3d0/idle_timer` untuk mencegah penurunan clock yang memicu micro-stutter pada jeda frame gameplay.
- **Mali GED DVFS Margin (MediaTek Dimensity / Helio)**: Opsi sensitivitas scaling frekuensi (+0%, +10%, +20%, +30%) via `/sys/kernel/ged/hal/dvfs_margin_value` agar GPU lebih responsif melompat ke OPP clock tertinggi saat beban komputasi grafis melonjak.

### 4. 🎛️ Integrasi Floating Game HUD Overlay (In-Game OSD)
- **Kartu Kendali HUD di Tab Lab**: Sakelar master terintegrasi untuk mengaktifkan overlay performa mengambang langsung saat bermain game.
- **Pilihan Gaya Tampilan (OSD Layouts)**: Mendukung seleksi instan gaya tampilan (RTSS Slim Pillar, Top Nano-Ribbon, Dual-Block Esport, Quad-Tiles, Steam Deck Banner).
- **Deteksi Izin Overlay Otomatis**: Memeriksa izin `System Alert Window` (`Settings.canDrawOverlays`) dan memandu pengguna ke setelan sistem jika izin belum aktif.

---

# Lynx [Codename: Deity] 3.0.37
Released on: 2026-10-05
> **Versi ini** menghadirkan **Master Toggle & Sistem Proteksi Sentuh Kalibrasi Warna Layar (Color Engine Touch Protection), Eliminasi Risiko Blank Screen dengan Sanitasi Ketat Format Angka Internasional (Locale.US Enforced), Reset Mandiri Aman ke Standar Bawaan OEM (D65 White Point / Matrix Identity 1015 / Saturation 1.0x), serta Penyempurnaan Desain Antarmuka Material 3 Obsidian yang Bersih, Terstruktur, dan Bebas Distorsi Sentuhan** — melengkapi kartu *Manajemen Warna Layar (Color Engine)* dengan master switch terintegrasi di header dan banner status visual; saat kalibrasi dinonaktifkan, seluruh slider (temperatur Kelvin, saturasi, kontras, gain RGB) dan preset terkunci rapat dan tersembunyi dengan transisi halus (`AnimatedVisibility`), menjamin tidak ada sentuhan atau geseran tidak sengaja saat pengguna menggulir layar; saat dimatikan, sistem secara otomatis merestorasi matriks layar SurfaceFlinger dan kanal warna Android ke standar pabrik OEM.

## 🚀 Fitur Baru & Peningkatan (3.0.37)

### 1. 🛡️ Master Toggle & Proteksi Anti-Sentuh Kalibrasi Warna Layar
- **Master Switch Terintegrasi**: Sakelar kendali utama ditempatkan di header kartu dan status banner interaktif untuk mengaktifkan atau menonaktifkan seluruh engine kalibrasi warna secara instan.
- **Kunci Total Saat Nonaktif (Touch-Proof)**: Saat sakelar dalam posisi nonaktif (`OFF`), seluruh slider (Temperatur Kelvin 4000K–9000K, Saturasi 0.5x–1.8x, Kontras 0.7x–1.3x, dan Gain RGB Individual) serta chip preset dikunci dan disembunyikan secara rapi dengan animasi `AnimatedVisibility`. Pengguna bebas melakukan *scroll* tanpa risiko menyentuh slider secara tidak sengaja.
- **Banner Status & Indikator OEM**: Menampilkan kartu status informatif dengan ikon gembok dan tag `STANDAR OEM` saat nonaktif, atau ikon tuning dan tag profil aktif (misal `AKURAT`, `GAMING`) saat aktif.

### 2. ⚡ Restorasi Otomatis & Aman ke Standar Pabrik OEM (Safe Fallback)
- **Zero-Latency Reset on Disable**: Mematikan sakelar kalibrasi secara otomatis mengeksekusi reset aman pada seluruh lapisan grafis: SurfaceFlinger Color Matrix 1015 dikembalikan ke identitas (`1015 i32 0`), saturasi dikembalikan ke `1.0`, dan `display_color_adjustment` dikembalikan ke `'1.0 1.0 1.0'`.
- **Pencegahan Risiko Layar Gelap (Black Screen Prevention)**: Menjamin tidak ada lagi nilai nol atau format angka dengan koma yang dapat menyebabkan layar blank pada ROM ber-locale non-Inggris (Indonesia, Eropa, dsb.).

### 3. 🎨 Perbaikan Desain & Struktur Antarmuka yang Bersih (Ultra-Clean UI)
- **Hierarki Informasi yang Rapi**: Mengelompokkan preset, slider utama, dan penyesuaian gain lanjutan ke dalam container bertingkat yang terstruktur dan mudah dipahami tanpa kebingungan.
- **Touch-First Compliance (>= 48dp)**: Seluruh tombol preset, switch, dan area interaktif dirancang dengan target sentuh minimal 48dp sesuai pedoman kenyamanan jemari dan mobile-first.
- **Persistensi State Cerdas**: Status aktif/nonaktif kalibrasi warna dan profil pilihan tersimpan secara aman di preferensi aplikasi sehingga tetap konsisten setelah aplikasi ditutup atau perangkat direboot.

---

# Lynx [Codename: Deity] 3.0.36
Released on: 2026-10-04
> **Versi ini** menghadirkan **Arsitektur 3-Tab Terpadu "GPU & Display" (Tuning, Performance Lab, Info Hardware), Performance Lab Engine dengan Perekaman Frame-Pacing & Korelasi Drop Timestamp Real-Time (Avg FPS, 1% Low, 0.1% Low, Stabilitas %, Frame Time Variance), Deteksi Kapabilitas Hardware Universal (GPU Vendor, Model, Driver, GLES, Vulkan API, Panel Modes, HDR, Wide Color, Sysfs Explorer), Diagnostik Display Pipeline (HWC vs GPU Client Composition, Missed Frames, Active SkiaVK/GL), Mesin Kalibrasi Warna Modern SurfaceFlinger Matrix 1015 (Kelvin White Point 4000K-9000K, Saturasi, Kontras, RGB Individual, Presets D65/Gaming/Cinema/Membaca, Deteksi Konflik Night Light / Extra Dim), serta Perluasan Aturan Per-App Profil (GPU Clock Min/Max, Boost Level, Adaptive Authority, Color Profile)** — meningkatkan subhalaman *GPU & Display* menjadi pusat kendali grafis terlengkap tanpa perlu aplikasi pihak ketiga; dilengkapi validasi ketat *No-Gimmick* (verifikasi read-back hak akses node nyata), ekspor histori sesi ke CSV (`/sdcard/Download/Lynx/`), dan desain antarmuka Material 3 Obsidian yang bersih, terstruktur, dan mobile-first.

## 🚀 Fitur Baru & Peningkatan (3.0.36)

### 1. 🎛️ Arsitektur 3-Tab Terpadu: [ 🎮 Tuning ], [ 📊 Lab ], dan [ ℹ️ Info ]
- **Segmented Top Navigation**: Navigasi segmented touch-first di bagian atas subhalaman GPU & Display yang membagi fitur ke dalam 3 pilar: *Tuning* (pengaturan clock, driver, refresh rate, kalibrasi warna), *Lab* (perekam performa & analisis frame pacing), dan *Info* (pemindai kapabilitas hardware dan penjelajah node kernel).
- **Desain Ultra-Clean & Anti-Clutter**: Memastikan antarmuka tetap rapi, responsif, dan tidak membebani pengguna dengan pengelompokan yang jelas dan terstruktur.

### 2. 📊 Performance Lab — Real Frame Stability & Drop Correlator
- **Perekaman Frame-Pacing SurfaceFlinger**: Mengukur latensi penyerahan buffer frame per layer langsung via SurfaceFlinger BLAST tanpa membebani sistem render.
- **Metrik Frame Komprehensif**: Menghitung secara presisi *Rata-rata FPS*, *1% Low FPS*, *0.1% Low FPS*, *Variansi Frame Time (Deviasi Standar)*, *Skor Kestabilan %*, *Persentil p50/p95/p99*, dan *Total Frame Jank*.
- **Korelasi Drop Akar Masalah**: Mengorelasikan timestamp setiap kejadian frame drop terhadap fluktuasi clock GPU (downclock oleh governor), thermal throttling, GPU core queue stall, atau CPU thread stall.
- **Rekomendasi Cerdas**: Memberikan saran optimasi kontekstual berdasarkan akar masalah yang terdeteksi.
- **Histori Sesi & Ekspor CSV**: Menyimpan hingga 20 sesi pengujian dan memungkinkan ekspor data frame lengkap ke format `.csv` di folder `/sdcard/Download/Lynx/`.

### 3. ℹ️ Hardware Capability Scanner & Sysfs Node Explorer
- **Deteksi Driver & API Fisik**: Memindai vendor GPU nyata (Adreno, Mali, Xclipse), versi driver kernel, versi OpenGL ES, serta mendekode versi Vulkan API via `cmd gpu vkjson`.
- **Kapabilitas Panel Display**: Mendeteksi resolusi dan seluruh refresh rate yang didukung panel (`dumpsys display`), tipe HDR (HDR10, HDR10+, Dolby Vision), Wide Color Gamut (Display P3), serta dukungan hardware DC Dimming, HBM Sunlight Booster, dan KCAL.
- **Display Pipeline & Komposisi**: Memantau rasio komposisi *Hardware Composer (HWC Direct)* vs *Client GPU Fallback*, jumlah missed frames, serta backend aktif Skia (SkiaVK Vulkan vs SkiaGL).
- **Universal Sysfs Node Explorer**: Menampilkan daftar node kernel nyata yang terdeteksi pada perangkat beserta badge status akses (`WRITABLE`, `READ-ONLY`, `UNAVAILABLE`) dan fitur salin path dalam satu ketukan.

### 4. 🎨 Universal Color Management Engine (SurfaceFlinger Matrix 1015)
- **Koreksi White Point D65 & Temperatur Kelvin**: Penyesuaian temperatur warna (4000K hingga 9000K) berbasis aproksimasi Tanner Helland dengan normalisasi D65.
- **Kontrol Saturasi & Kontras**: Menyetel matriks saturasi Rec.709 (0.5x hingga 1.8x) dan kontras dinamis tanpa efek banding visual.
- **Preset Instan & Gain RGB Individual**: Opsi preset cepat (*Akurat D65*, *Gaming Vivid*, *Cinema Warm*, *Membaca/Eye Care*) dan slider gain individu untuk Red, Green, Blue.
- **Deteksi Konflik Night Light / Extra Dim**: Notifikasi otomatis jika fitur Night Light atau Extra Dim Android sedang aktif di sistem agar kalibrasi warna tidak terdistorsi.
- **KCAL & HBM Seamless Fallback**: Tetap mempertahankan dukungan saklar KCAL kernel dan HBM Sunlight Booster jika perangkat memilikinya.

### 5. 📦 Perluasan Aturan Profil Aplikasi (App Profile Rules)
- **Parameter GPU & Display pada Per-App Rule**: Menambahkan konfigurasi frekuensi minimum/maksimum GPU, boost level, preferensi adaptive authority, dan profil warna pada basis data per-aplikasi (`AppProfileRule`).

---

# Lynx [Codename: Deity] 3.0.35
Released on: 2026-10-04
> **Versi ini** menghadirkan **Reka Ulang Arsitektur Universal Subhalaman "GPU & Display": Dual-Pill Dropdown Frequency Picker & Kunci Clock Mandiri, Mode Auto Refresh Rate Dinamis (0Hz Ultra-Low Idle & Instant Boost Touch), Eliminasi Duplikasi Boost, Driver Grafis Produksi Game (AOSP `updatable_driver_all_apps`), HWUI Modern SkiaVK (Vulkan Backend) & SkiaGL, SurfaceFlinger Low-Latency Latch Unsignaled, Shield Anti-Throttling Vendor OEM (Xiaomi Joyose / Samsung GOS / BBK GPA / Transsion Darwin), serta Kalibrasi Warna Layar Universal Android (`display_color_adjustment`) Bebas Pesan Error Raksasa** — merestrukturisasi total subhalaman *GPU & Display* pada aplikasi Lynx Companion (`LynxKernelManager`) menjadi 4 Kartu Master berorientasi touch-first dan clean minimalist: (1) *Master GPU Tuner & Telemetri*, (2) *Driver Grafis & HWUI Engine*, (3) *Display Refresh Rate & Touch*, dan (4) *Kalibrasi Warna Layar (Universal RGB)*; membasmi tuntas slider frekuensi horizontal yang kaku menjadi selektor Dual-Pill (Min MHz & Max MHz) dengan Bottom Sheet 49-step OPP table dan tombol kunci mandiri, mengintegrasikan mode Auto Refresh Rate cerdas dengan `min_refresh_rate = 0.0` untuk efisiensi baterai maksimal, serta mendukung penuh cross-SoC kernel (Qualcomm Snapdragon Adreno, MediaTek Mali/Immortalis GED, Samsung Exynos/AMD RDNA Xclipse, Google Tensor, Generic Linux GKI).

## 🚀 Fitur Baru & Peningkatan (3.0.35)

### 1. 🎛️ Dual-Pill Dropdown Frequency Picker & Clock Lock Mandiri
- **Paritas Sempurna dengan CPU Clock**: Menggantikan slider horizontal GPU dengan selektor Dual-Pill interaktif (*Frekuensi Min* dan *Frekuensi Max*) dengan tinggi sentuh 48dp bebas miss-click.
- **Modal Bottom Sheet OPP Steps**: Mengetuk pill frekuensi membuka bottom sheet interaktif yang menampilkan seluruh tangga frekuensi yang didukung hardware kernel (300 MHz hingga 950 MHz+).
- **Tombol Kunci Clock Mandiri (`Lock`)**: Tombol aksi sentuh 48dp untuk mengunci frekuensi GPU minimum dan maksimum secara seragam demi performa gaming stabil tanpa fluktuasi clock.

### 2. 📱 Mode Auto Refresh Rate Cerdas (0.0Hz Idle & Instant Touch Spike)
- **Selektor Chip 4-Arah**: Menambahkan mode `[ 🤖 Auto Dinamis ]` di samping opsi refresh rate tetap `60Hz`, `90Hz`, dan `120Hz/144Hz`.
- **Zero-Waste Power Efficiency**: Mengatur `min_refresh_rate = 0.0` pada mode Auto sehingga panel layar turun ke refresh rate terendah saat tampilan statis (menghemat konsumsi daya baterai hingga 40%), dan seketika melompat ke 120Hz saat disentuh.

### 3. 🧹 Eliminasi Duplikasi Boost & Penataan Ulang Arsitektur
- **Zero Redundancy**: Menghapus duplikasi selektor GPU Boost yang sebelumnya bertumpuk dua kali (Mati, Level 1, Level 2 vs Off, Medium, High).
- **Pembersihan Kartu Misplaced**: Memindahkan selektor arsitektur SoC global keluar dari subhalaman GPU agar fokus kartu murni pada akselerasi grafis hardware.
- **Segmented Boost 3-Arah**: Menghadirkan kontrol segmented boost ringkas: `🍃 Hemat (0)`, `⚡ Level 1 (Normal)`, dan `🔥 Level 2 (Hardcore)`.

### 4. 🎮 Driver Grafis Game & HWUI Engine Modern (Lintas SoC & Brand)
- **AOSP Production Game Driver**: Opsi `updatable_driver_all_apps` untuk memaksa sistem memuat driver grafis produksi independen untuk semua aplikasi.
- **HWUI Rendering Engine (Vulkan / SkiaVK)**: Saklar backend antarmuka sistem Android (`skiavk` Vulkan, `skiagl` OpenGL ES, `auto`) untuk memangkas beban CPU overhead rendering hingga 30%.
- **SurfaceFlinger Low-Latency Latch**: Mengaktifkan `debug.sf.latch_unsignaled = 1` untuk memangkas antrean render buffer dan memotong input lag sentuhan hingga 1 frame (~8.3ms pada 120Hz).
- **Shield Anti-Throttling OEM**: Mendeteksi dan melumpuhkan daemon pembatas FPS bawaan OEM (Xiaomi Joyose, Samsung GOS, Transsion Darwin, BBK GPA).

### 5. 🎨 Kalibrasi Warna Layar Universal Android (`display_color_adjustment`)
- **Dukungan Universal AOSP**: Memanfaatkan node resmi Android `display_color_adjustment` untuk kalibrasi channel Red, Green, Blue di seluruh custom ROM modern (AOSP, LineageOS, EvolutionX, PixelOS, HyperOS, OneUI).
- **Desain Smart-Compact**: Menghilangkan badge pesan error oranye raksasa saat driver KCAL/HBM lawas tidak ada di kernel modern, digantikan oleh antarmuka slider RGB yang bersih dan responsif beserta tombol reset 1.0.

---

# Lynx [Codename: Deity] 3.0.34
Released on: 2026-10-04
> **Versi ini** menghadirkan **Penyempurnaan Arsitektur & Reorganisasi Hierarki UI CPU: Promosi Posisi Kartu Core Parking & CPU Idle ke Posisi 2, Transformasi Segmented Selector 3-Arah Touch-First, Penyelarasan Zero-Redundancy antara Kernel Hotplug (`online=0/1`) dan C-States (`cpuidle`), serta Perampingan Accordion Lanjutan** — merestrukturisasi subhalaman *CPU & Governor* pada aplikasi Lynx Companion (`LynxKernelManager`) agar alur navigasi parameter CPU lebih logis, berorientasi mobile-first, dan bebas dari ambiguitas; kini kartu *Core Parking & CPU Idle (C-States)* ditempatkan tepat di bawah *Cluster Frequency & Governor Tuning* (sebelum *CPU Sets & Task Shield*), fitur kebijakan Core Parking ditarik keluar dari accordion tersembunyi dan menu dropdown menjadi selektor segmented 3-arah (`Dinamis (OEM)`, `Unpark Semua`, `Parkir Big Cores`) dengan kartu penjelasan kontekstual langsung, serta accordion kustomisasi lanjutan dikhususkan murni untuk parameter C-States tingkat mendalam (Level 0 WFI hingga Level 3 Deep Sleep) dan ARMPLL Power Down.

## 🚀 Fitur Baru & Peningkatan (3.0.34)

### 1. 📐 Reorganisasi Hierarki Kartu CPU (`CpuSubScreen`)
- **Promosi ke Posisi 2**: Memindahkan kartu `CpuIdleCoreParkingCard` ke posisi kedua tepat di bawah `CpuClusterTunerCard` dan mendahului `CpuSetsTaskShieldCard`.
- **Alur Logika Berurutan**: Menyusun hierarki konfigurasi prosesor yang runtut: *Kecepatan/Frekuensi Inti* $\to$ *Ketersediaan Inti & Latensi Tidur (Core Parking & Idle)* $\to$ *Penugasan Tugas (CPU Sets / Affinity)* $\to$ *Algoritma Penjadwalan (CFS/EAS/HMP/BORE)*.

### 2. 🎛️ Transformasi Selektor Segmented 3-Arah Core Parking
- **Eliminasi Dropdown Tersembunyi**: Menghapus menu dropdown dan accordion bersarang untuk pengaturan Core Parking yang sebelumnya memerlukan klik ekstra dan sulit dijangkau.
- **Selektor Segmented Touch-First**: Menyajikan kontrol langsung 3-opsi (`Dinamis`, `Unpark Semua`, `Parkir Big`) dengan tinggi sentuh minimum 44–48dp dan indikator visual status aktif berbasis warna aksen (Biru, Cyan, Oranye).
- **Penjelasan Kontekstual Real-Time**: Menyertakan kartu ringkasan dinamis yang menerangkan secara gamblang implikasi kernel dari masing-masing mode yang dipilih (misal: penulisan sysfs `/sys/devices/system/cpu/cpu*/online`).

### 3. 🔬 Perampingan Accordion Kustomisasi Lanjutan C-States
- **Pemisahan Konseptual yang Tegas**: Memisahkan secara tegas antara *Core Parking / Hotplug* (isolasi fisik core dari scheduler) dan *C-States* (siklus tidur idle CPU saat core tetap online).
- **Fokus Murni C-States**: Mengubah nama accordion menjadi *Kustomisasi Lanjutan: C-States (/sys/cpuidle)* yang khusus menampung saklar granular Level 0 (WFI Wajib Aktif), Level 1 (cpuoff), Level 2 (clusteroff), Level 3 (deep), serta saklar hardware *ARMPLL Power Down Mode*.

---

# Lynx [Codename: Deity] 3.0.33
Released on: 2026-10-04
> **Versi ini** menghadirkan **Deep Hardware Diagnostic & Transsion Motherboard Thermal Override: Pembongkaran Kernel DV2/PE5.0 Throttling, Bypass Kuncian Suhu PCB 45°C (`pcb_thermal_debug` [65,3500,70,3000,2500]), Penjinakan Adaptive Battery Current Throttling (`abcct`), dan Analisis Fisika Saturasi Sel Baterai (CV Phase)** — membongkar tuntas investigasi hardware tingkat kernel pada perangkat MediaTek Dimensity / Transsion (Infinix X698) mengapa pengisian daya sempat drop di bawah 25W (menjadi ~10W–14W); telemetri kernel membuktikan bahwa algoritma DV2 memotong arus input adaptor dari 3000mA ke 1500mA akibat suhu sensor motherboard (`tpcb`) menyentuh 45°C (Level 7) dan layar menyala (`game_limit_ita` 1500mA), serta kondisi tegangan baterai yang telah menyentuh fase jenuh Constant Voltage (>4.47V / >70%); versi ini menyuntikkan override langsung ke register driver pabrik ODM Transsion untuk menaikkan plafon suhu PCB ke 65°C, menonaktifkan derating cooling device `abcct`, serta mengoptimalkan aliran daya pada kondisi layar aktif dan mati.

## 🚀 Fitur Baru & Peningkatan (3.0.33)

### 1. 🌡️ Transsion ODM PCB Thermal Clamp Override (`pcb_thermal_debug`)
- **Pembongkaran Bottleneck 45°C Kernel**: Melalui inspeksi dmesg real-time, ditemukan bahwa kernel MediaTek PE5.0 mengeksekusi `__dv2_check_tpcb_level tpcb(46,7)` yang secara otomatis memotong arus adaptor `ita` dari 3000mA menjadi 1500mA setiap kali motherboard ponsel menyentuh 45°C.
- **Penyuntikan Ambang Batas Pabrik (65°C / 3500mA)**: Mengintegrasikan bypass register ODM Transsion via `echo "[65,3500,70,3000,2500]" > /sys/devices/platform/odm/odm:tran_battery/pcb_thermal_debug` (`Tpcb_store_ok = 1`), menaikkan toleransi panas PCB ke 65°C dan menaikkan arus dealing dari 1500mA ke 3500mA sehingga watt pengisian tidak drop drastis saat komponen menghangat.

### 2. ⚡ Penjinakan Cooling Device `abcct` & Perbaikan Izin Sysfs
- **Reset Adaptive Battery Charging Current Throttling**: Memastikan pendingin kernel `cooling_device56 [abcct]` dinonaktifkan (`cur_state = 0`) tanpa mengunci file dengan `chmod 444` yang sebelumnya memicu *Permission Denied* pada siklus daemon berulang.
- **Konsistensi Manajemen Termal Asinkron**: Seluruh loop otomasi pengisian daya kini dapat menyegarkan dan menjaga state pendingin charging pada level 0 secara terus menerus.

### 3. 🔬 Analisis & Optimalisasi Perilaku Pengisian Daya (Screen-On vs Screen-Off & CV Phase)
- **Bypass Layar Menyala & Mode Game**: Mengidentifikasi limitasi baku firmware Transsion `game_limit_ita: 1500mA` saat layar aktif (`lcd_on > 0`), serta mengoptimalkan mode screen-off agar adaptor dapat memompa arus maksimal 3000mA (6000mA pada sel baterai).
- **Pemahaman Fisika Elektrokimia Baterai**: Memberikan panduan transparan berbasis data kernel bahwa saat kapasitas baterai di atas 70% (tegangan sel >4.47V), PMIC hardware wajib menurunkan arus pengisian daya (fase Constant Voltage / CV) demi keselamatan fisik sel baterai.

---

# Lynx [Codename: Deity] 3.0.32
Released on: 2026-10-04
> **Versi ini** menghadirkan **Persistent Background SuperCharge Protection: Pemisahan Sensor Termal Baterai Fisik Nyata (Anti-False Cutoff CPU 46°C), Independensi Subsistem Pengisian Lintas Profil (`apply_profile.sh` Balance Shield), dan Proteksi Kuncian Anti-Drop Saat Keluar Aplikasi Lynx (`/dev/lynx_extreme_charging`)** — menuntaskan investigasi mendalam di mana daya pengisian 30W sempat drop setelah beberapa saat akibat skrip daemon yang secara keliru membaca `thermal_zone0` (CPU/SoC yang wajar menyentuh 46°C saat pengisian cepat) dan langsung memicu Emergency Thermal Guard 1500mA, serta membasmi fenomena drop drastis saat aplikasi Lynx ditutup atau kehilangan fokus yang disebabkan oleh pemicuan `cmd thermalservice reset` dan `unfreeze_oem_throttlers` saat sistem beralih ke profil *Balance*; kini subsistem pengisian daya beroperasi secara mandiri dan persisten di semua profil sistem, sensor termal dipetakan secara akurat ke sel baterai fisik (`mtktsbattery`), dan penanganan termal dikunci rapat di latar belakang.

## 🚀 Fitur Baru & Peningkatan (3.0.32)

### 1. 🛡️ Pemisahan Sensor Termal Baterai Fisik Nyata (Anti-False Cutoff CPU)
- **Deteksi Sensor Baterai Akurat**: Mengganti pembacaan hardcoded `thermal_zone0` (SoC CPU) dengan pemindaian dinamis tipe sensor `*battery*`, `mtktsbattery`, dan `bms` pada `/sys/class/thermal/thermal_zone*` serta fallback ke thermistor internal baterai.
- **Plafon Keamanan Baterai Riil (49°C)**: Emergency Thermal Guard pada mode Extreme Charging kini hanya akan aktif jika suhu sel baterai fisik yang sesungguhnya menyentuh $\ge 49.0^\circ\text{C}$ (bukan suhu CPU yang wajar panas), menjamin aliran daya 30W–33W stabil terus menerus tanpa terpotong prematur.

### 2. ⚡ Independensi Pengisian Lintas Profil (Anti-Drop Saat Tutup Aplikasi)
- **Persistensi Pengisian di Semua Profil**: Memindahkan dan mendekopel seluruh blok pengisian daya pada `apply_profile.sh` sehingga setelan Extreme Charging (6000mA, Direct Pump, `BN_TestMode`, spoofing 28°C) tetap aktif sepenuhnya di latar belakang bahkan saat pengguna berada di Home Screen, berpindah aplikasi, atau sistem berjalan di profil *Balance*.
- **Marker Atomik `/dev/lynx_extreme_charging`**: Melindungi sistem dari eksekusi `cmd thermalservice reset` dan `unfreeze_oem_throttlers` ketika mode Extreme Charging aktif, menjaga pendingin termal tetap terkunci pada `cur_state = 0` (`chmod 444`) dan daya pengisian tidak drop saat Lynx ditutup.

---

# Lynx [Codename: Deity] 3.0.31
Released on: 2026-10-04
> **Versi ini** menghadirkan **Direct 33W Charge Pump Engagement Engine: Eliminasi Kuncian Protokol PE 2.0 (18W Downgrade Fix) & Proteksi Read-Only Locking pada Arus Pengisian Sel Baterai (`constant_charge_current_max` 6000mA)** — membasmi pembatasan tidak disengaja di mana penulisan nilai `Pump_Express = 2` pada sysfs kernel MediaTek memaksa hardware melakukan downgrade ke protokol Pump Express 2.0 (plafon 18W: 9V / 2A), membuka prioritas penuh bagi negosiasi Pump Express 4.0 & Transsion Super Charge 33W (`enable_sc = 1`, `pe40 = 1`, `sc_ibat_limit = 8000`), serta menerapkan proteksi `chmod 444` pada `constant_charge_current_max` dan `charge_control_limit` agar Android BatteryService/Healthd tidak dapat mereset batas arus baterai kembali ke default 2000 mA.

## 🚀 Fitur Baru & Peningkatan (3.0.31)

### 1. ⚡ Eliminasi Kuncian Protokol PE 2.0 (Unlocking 33W Direct Pump)
- **Hapus Pembatasan `Pump_Express = 2`**: Menghapus penulisan statis `Pump_Express = 2` yang sebelumnya memerintahkan driver charger MTK untuk beroperasi pada Pump Express 2.0 (18W maks: 8.4V–9V @ 2.1A).
- **Prioritas Penuh PE 4.0 & Super Charge**: Membuka jalur negosiasi 33W murni via `pe40 = 1`, `enable_sc = 1`, dan `pdc_max_watt = 68` sehingga adaptor dapat menaikkan tegangan ke 10V/11V dan mengaktifkan IC RT9759 Direct Charge Pump 2:1.

### 2. 🔒 Proteksi Read-Only (`chmod 444`) pada Arus Pengisian Baterai
- **Anti-Reset 2000mA oleh Android BatteryService**: Menerapkan `chmod 444` pada `/sys/class/power_supply/battery/constant_charge_current_max` setelah disetel ke 6000000 uA (6000 mA). Ini mencegah Android OS mereset batas arus kembali ke 2000 mA.
- **Reset Charge Control Limit**: Mengunci `charge_control_limit_max` dan `charge_control_limit` ke 0 agar tidak terjadi pelambatan arus oleh subsistem manajemen daya OS.

---

# Lynx [Codename: Deity] 3.0.30
Released on: 2026-10-04
> **Versi ini** menghadirkan **Continuous Unthrottled Screen-On SuperCharge Engine: Bypass Penuh Limitasi Layar Menyala Transsion/MediaTek (BN_TestMode & tpcb Derating Override), Proteksi Read-Only Locking pada Cooling Devices (`chmod 444`), dan Eliminasi Throttling Prematur Suhu CPU saat Ponsel Aktif Digunakan** — meruntuhkan batasan agresif kernel OEM Transsion yang sebelumnya memangkas arus adaptor menjadi 1500 mA setiap kali layar aktif atau ponsel sedang digunakan, mengintegrasikan mode uji pabrik `BN_TestMode = 1` untuk menonaktifkan derating layar/game secara permanen, mengunci seluruh pendingin termal `cur_state = 0` dengan izin read-only agar daemon sistem tidak dapat menaikkan level throttling, serta membebaskan mode Extreme Charging dari batasan soft cutoff termal sehingga pengisian daya 33W (5–6A pada sel baterai) tetap mengalir kencang dan konsisten tanpa interupsi.

## 🚀 Fitur Baru & Peningkatan (3.0.30)

### 1. ⚡ Continuous Screen-On SuperCharge Engine (Bypass Limit Layar Menyala)
- **Aktivasi Transsion `BN_TestMode`**: Mengaktifkan node pengujian pabrik `/sys/devices/platform/charger/BN_TestMode = 1` dan mereset `BatteryNotify` serta `tran_charger_full` untuk menonaktifkan pembatasan `tpcb / lcd_on` (1500mA clamp) saat framebuffer layar aktif.
- **Pengisian Cepat Tanpa Drop Saat Gaming/Dipakai**: Pengguna kini dapat menggunakan ponsel secara intensif, bermain game, atau menyalakan layar tanpa khawatir kecepatan pengisian drop ke 1.2A–1.5A. Daya 33W penuh dan arus 5–6A tetap dipompa stabil ke sel baterai.

### 2. 🔒 Proteksi Kunci Izin Read-Only (`chmod 444`) pada Cooling Devices & Suhu Baterai
- **Anti-Overriding Daemon Sistem**: Setelah mereset seluruh cooling device charging (`bcct`, `chg`, `battery`, `current`) ke `cur_state = 0`, permission dikunci menjadi `chmod 444` sehingga thermal daemon latar belakang tidak dapat menaikkan state throttling saat layar menyala.
- **Proteksi Suhu Spoofing 28°C**: Node `Battery_Temperature` kini dikunci dengan `chmod 444` setelah disetel ke 28°C untuk mencegah kernel mengembalikan nilai suhu tinggi yang memicu DV2_TBAT lockout.

### 3. 🎯 Eliminasi Throttling Prematur dari Sensor CPU
- **Pemisahan Sensor Baterai vs SoC**: Memperbaiki logika daemon loop di mana sebelumnya temperatur thermal zone 0 (SoC/CPU yang normal mencapai 50°C saat layar menyala) secara keliru memicu soft thermal throttling 1200mA pada pengisian daya baterai.
- **Hak Istimewa Extreme Mode**: Mode Extreme Charging kini dikecualikan dari soft cutoff dan hanya dibatasi oleh Emergency Thermal Guard nyata pada sel baterai (>48.5°C) demi menjamin kecepatan pengisian yang tidak terputus.

---

# Lynx [Codename: Deity] 3.0.29
Released on: 2026-10-04
> **Versi ini** menghadirkan **Perbaikan Kritis Subsistem Pengisian Daya & Optimalisasi 33W Transsion Super Charge: Eliminasi Bug Integer Overflow (Zeroing Input Current Bug Fix), Penguraian Konseptual & Edukasi UI Bypass vs Extreme Charging, dan Dynamic Thermal Cooling Device Unlocking** — membasmi cacat fatal pada skrip pengontrol di mana penulisan nilai `4294967295` memicu overflow pada sysfs kernel MediaTek dan me-reset arus input `input_current` menjadi 0 mA, menggantikannya dengan nilai valid 6000 mA (register step 24576) untuk memompa daya penuh 33W (hingga 5–6A pada sel baterai via RT9759 2:1 Switched Capacitor Charge Pump); memperjelas pemisahan tegas antara fungsi *Bypass Charging* (daya langsung ke motherboard, net 0mA baterai untuk gaming dingin) dan *Extreme Fast Charging* (pompa arus maksimum ke sel baterai) pada antarmuka pengguna; serta menggantikan penanganan termal statis hardcoded dengan loop dinamis pada seluruh `cooling_device*` terkait charging.

## 🚀 Fitur Baru & Peningkatan (3.0.29)

### 1. ⚡ Perbaikan Kritis Subsistem Pengisian Daya (Zeroing Input Current Bug Fix)
- **Eliminasi Integer Overflow Sysfs**: Memperbaiki bug di mana penulisan `4294967295` ke `/sys/devices/platform/charger/input_current`, `chg1_current`, dan `chg2_current` ditolak oleh parser kernel driver dan me-reset arus pengisian menjadi `0`, secara artifisial mencekik kecepatan pengisian ke mode darurat minimal.
- **Koreksi Parameter Arus MediaTek**: Mengalokasikan nilai valid `6000` (diterjemahkan kernel ke step internal `24576` = 6000 mA / 6A) pada `input_current`, `chg1_current`, dan `chg2_current`, serta menetapkan `sc_ibat_limit = 8000` mA.
- **Sinkronisasi Seluruh Engine**: Memperbarui implementasi pada `LynxRepository.kt`, `Charging-Controller.sh`, dan `core/apply_profile.sh` secara serentak.

### 2. 🛡️ Penguraian Konseptual & Edukasi UI: Bypass vs Extreme Charging
- **Pemisahan Tegas Mental Model**:
  - **Bypass Charging (Direct Motherboard)**: Diperjelas fungsinya sebagai penyuplai motherboard secara langsung dan **menghentikan pengisian baterai (Net 0mA)** agar baterai dingin saat gaming. Diberi peringatan tegas untuk tidak diaktifkan jika berniat mengisi daya.
  - **Extreme Fast Charging (33W Super Charge / 6A)**: Diperjelas sebagai mode yang memompa daya baterai hingga 6000mA (6A) melalui chip RT9759 2:1 charge pump.
- **Transparansi Transsion Screen-On Throttling**: Menambahkan catatan edukatif bahwa algoritma OEM Transsion membatasi adaptor ke ~1.5A saat layar menyala demi suhu panel AMOLED, dan pengisian 33W penuh beroperasi optimal saat layar mati (Screen-Off).

### 3. ❄️ Dynamic Thermal Cooling Device Unlocking
- **Eliminasi Hardcode Cooling Device**: Menggantikan referensi kaku `cooling_device56` dengan pemindaian dinamis di seluruh `/sys/class/thermal/cooling_device*` yang mendeteksi tipe `bcct`, `chg`, `battery`, dan `current`, menjamin pelepasan limitasi termal bekerja stabil di setiap siklus reboot dan varian perangkat.

---

# Lynx [Codename: Deity] 3.0.28
Released on: 2026-10-04
> **Versi ini** menghadirkan **Perbaikan Tata Letak Header Kartu & Eliminasi Badge Collision: Restorasi Judul Bersih Satu Baris pada Platform Hardware Engine, Integrasi Subtitle Komprehensif pada LynxCard, dan Perbaikan Bug Alokasi Bobot Baris (Spacer Weight Bug Fix)** — menyelesaikan masalah tampilan di mana badge `MediaTek PPM Driver` pada sisi kanan kartu memicu tabrakan ruang horizontal dan memecah teks judul "Platform Hardware Engine" menjadi 3 baris canggung, memindahkan identitas driver chipset menjadi subtitle semantik elegan di bawah judul, serta merombak sistem perataan baris pada `LynxCard` sehingga teks judul dapat memanfaatkan lebar penuh layar tanpa terpotong secara artifisial oleh alokasi bobot spacer.

## 🚀 Fitur Baru & Peningkatan (3.0.28)

### 1. 🎨 Restorasi Tata Letak Bersih Platform Hardware Engine
- **Eliminasi Badge Collision**: Menghapus badge pill bulky di sisi kanan header `PlatformHardwareEngineCard` yang sebelumnya memicu perebutan lebar horizontal dengan judul section.
- **Hierarki Subtitle Semantik**: Mengintegrasikan informasi driver chipset (`MediaTek PPM Driver` pada platform MTK atau `Snapdragon QTI HAL` pada platform Qualcomm) sebagai subtitle di bawah judul utama dengan ukuran dan warna teks yang harmonis.
- **Judul Stabil 1-Baris**: Teks "Platform Hardware Engine" kini tampil kokoh, rapi, dan konsisten dalam 1 baris di seluruh rasio layar tanpa wrapping.

### 2. 📐 Perbaikan Arsitektur Tata Letak Header `LynxCard`
- **Dukungan Parameter Subtitle**: Menambahkan parameter `subtitle: String? = null` pada komponen dasar `LynxCard` untuk standarisasi kartu antarmuka dengan hierarki informasi dua baris.
- **Eliminasi Bug Spacer Weight**: Menghapus `Spacer(Modifier.weight(1f))` yang sebelumnya membatasi ruang judul hingga 50% lebar kartu saat terdapat elemen `action`, kini digantikan dengan perataan `Modifier.weight(1f)` pada kolom judul dan `Spacer(Modifier.width(8.dp))` untuk spasi aksi yang presisi.
- **Proteksi Overflow & Ellipsis**: Menambahkan batasan `maxLines = 1` dengan `TextOverflow.Ellipsis` pada judul kartu untuk menjamin integritas visual pada berbagai ukuran layar dan skala font aksesibilitas.

---

# Lynx [Codename: Deity] 3.0.27
Released on: 2026-10-04
> **Versi ini** menghadirkan **Pembaruan UX Menyeluruh: Dual-Action Glanceable Switch & Rak Edukasi Interaktif Bottom Sheet (LynxSwitchInfoSheet), Eliminasi Inverted State Trap (Purge Schedstats Overhead), dan Refinement Keterbacaan Subtitle Anti-Truncation** — merevolusi antarmuka toggle kernel dengan pola interaksi ganda di mana switch dapat di-toggle instan tanpa friksi sementara baris teks membuka laci edukasi mendalam (`LynxSwitchInfoSheet`) yang memaparkan cara kerja kernel, perbandingan status ON vs OFF, serta rekomendasi skenario (Gaming, Balanced, Baterai); membalik logika membingungkan sakelar "Nonaktifkan Schedstats" menjadi model mental positif "Purge Schedstats Overhead" (ON = Optimasi Aktif); serta memperluas subtitle tweak tile hingga 2 baris penuh bebas elipsis terpotong.

## 🚀 Fitur Baru & Peningkatan (3.0.27)

### 1. 📖 Rak Edukasi Interaktif Bottom Sheet (`LynxSwitchInfoSheet`)
- **Dual-Action Glanceable Pattern**: Pengguna dapat langsung menyalakan/mematikan toggle dari daftar utama secara instan, atau mengetuk baris teks/ikon info untuk membuka lembar panduan teknis mendalam.
- **Sinkronisasi Status Live Real-Time**: Rak edukasi dilengkapi toggle switch interaktif di bagian atas lembar sehingga pengguna dapat langsung mengubah status sakelar sembari membaca penjelasan teknis tanpa perlu menutup lembar terlebih dahulu.
- **Komparasi Status Visual & Terstruktur**:
  - *Status Aktif (ON)*: Penjelasan efek positif, mekanisme kerja pada siklus CPU/cache, serta peningkatan latensi atau efisiensi.
  - *Status Non-Aktif (OFF)*: Penjelasan perilaku standar kernel Linux dan dampaknya terhadap beban sistem.
- **Matriks Rekomendasi 3-Skenario**:
  - 🎮 **Gaming / Kompetitif**: Panduan pengaturan untuk frame pacing stabil dan zero-stutter.
  - ⚖️ **Penggunaan Seimbang (Harian)**: Keseimbangan responsivitas dan konsumsi baterai.
  - 🔋 **Hemat Daya (Baterai)**: Opsi optimal untuk memperpanjang daya tahan perangkat.

### 2. 🧠 Eliminasi "Inverted State Trap": Purge Schedstats Overhead
- **Model Mental Positif**: Mengganti sakelar membingungkan *"Schedstats Profiling: Nonaktifkan pengumpulan statistik..."* menjadi **"Purge Schedstats Overhead"**.
- **Logika Bersih**: Toggle dalam posisi **ON (Aktif)** berarti optimasi sedang berjalan (beban overhead kernel dipangkas, `sched_schedstats = 0`), mengeliminasi kebingungan pengguna terhadap status negatif/terbalik.
- **Copywriting Glanceable 1-Baris**: Subjudul diringkas menjadi ringkas dan padat: *"Pangkas beban siklus CPU dengan mematikan statistik scheduler internal"*.

### 3. 🛡️ Integrasi Edukasi Komprehensif pada Seluruh Sakelar Kritis
- **EAS Schedtune**: Panduan lengkap untuk `Top-App Prefer Idle` (penempatan thread game ke core kosong).
- **Scheduler Hardware Hints**: Panduan mendalam untuk `Big Task Rotation` (efek rotasi vs cache L1/L2 hits) dan `Sync Wakeup Acceleration` (akselerasi komunikasi antar-thread).
- **CFS Core Scheduling**: Edukasi interaktif untuk `Child Process Runs First` (prioritas fork thread baru untuk startup game instan).
- **Platform Hardware Engine (MediaTek PPM & Qualcomm QTI)**: Edukasi mendalam untuk `Bypass Power Throttling OEM` (PPM Policy 3), `Hardware System Boost` (PPM Policy 9), `Sinkronisasi Thermal Policy PPM` (PPM Policy 4), dan `Qualcomm Touchboost Driver`.

### 4. 📐 Keterbacaan Maksimal & Subtitle Anti-Truncation
- **Ekspansi Subtitle `LynxTweakTile` & `LynxDualTweakTile`**: Menetapkan `maxLines = 2` dan `lineHeight = 13.sp` pada subteks ubin tweak sehingga kalimat penjelasan tidak terpotong elipsis (`...`) di layar ponsel dengan resolusi atau skala teks padat.
- **Copywriting Refinements**:
  - `Sched Tunable Scaling`: *"Kunci periode latensi tetap saat core tidur/bangun demi stabilitas frame rate"*.
  - `Real-Time (RT) Runtime Bandwidth`: *"Batas alokasi waktu CPU per detik untuk thread prioritas (audio & touch)"*.

---

# Lynx [Codename: Deity] 3.0.26
Released on: 2026-10-04
> **Versi ini** menghadirkan **Sub-Halaman CPU Master Level Komprehensif & Driver Hardware Engine: Live Runqueue & Pressure Telemetry, Platform Hardware Engine (MediaTek PPM & Snapdragon QTI Boost), serta Deep Kernel Latency & Overhead Purge** — mentransformasikan monitoring CPU dengan chip telemetri langsung beban antrean kernel (`RQ Avg`), deteksi tugas komputasi berat (`H-Task`), dan status saturasi kapasitas energi EAS (`EAS Limit / Opt`), menyematkan kartu khusus `PlatformHardwareEngineCard` untuk kendali langsung driver MediaTek PPM (bypass power throttling baterai lemah, system boost, sinkronisasi thermal) dan Qualcomm Snapdragon QTI Input Boost/Touchboost, serta membuka akses penuh ke tuning latensi kernel ekstrem (`schedstats profiling overhead purge`, `sched_tunable_scaling` pengunci konsistensi frame FPS, dan bandwidth `sched_rt_runtime_us`).

## 🚀 Fitur Baru & Peningkatan (3.0.26)

### 1. 📊 Live Runqueue & Pressure Telemetry (Master CPU Telemetry)
- **Monitoring Kedalaman Antrean CPU (`RQ Avg`)**: Membaca `/sys/devices/system/cpu/rq-stats/run_queue_avg` secara realtime untuk memantau rata-rata antrean thread runnable di seluruh cluster CPU.
- **Deteksi Heavy Tasks (`H-Task`)**: Membaca penghitung tugas berat (`/sys/devices/system/cpu/rq-stats/htasks` atau `big_task`) untuk membedakan thread game berat dari background noise.
- **Status Saturasi Energi EAS (`EAS Limit / Opt`)**: Membaca flag over-utilization EAS (`/sys/devices/system/cpu/rq-stats/over_util`) untuk mendeteksi secara instan saat sistem beralih dari kalkulasi efisiensi daya ke performa throughput maksimum.
- **Visual Micro-Chips**: Menampilkan indikator status di Master Telemetry Card dengan warna semantik adaptif (Hijau/Cyan untuk optimal, Oranye saat jenuh beban).

### 2. ⚡ Platform Hardware Engine (MediaTek PPM & Qualcomm QTI Boost)
- **MediaTek PPM Driver Controls**:
  - `Bypass Power Throttling OEM (PPM Policy 3)`: Mencegah kernel memangkas frekuensi CPU secara drastis saat persentase baterai berada di bawah 20%.
  - `Hardware System Boost (PPM Policy 9)`: Mengaktifkan akselerasi komputasi berat langsung pada driver manajemen daya MediaTek.
  - `Sinkronisasi Thermal Policy PPM (PPM Policy 4)`: Mengaitkan pembatasan termal langsung dengan driver PPM.
- **Qualcomm Snapdragon QTI Driver Controls**:
  - `Qualcomm Touchboost Driver`: Kontrol sakelar lonjakan frekuensi seketika saat event touch terdeteksi (`/sys/module/msm_performance/parameters/touchboost`).
  - `Input Boost Dynamics Status`: Pemantauan frekuensi boost MHz dan durasi ms saat input event aktif.
- **Kartu Khusus Berbasis Deteksi Driver**: Menampilkan `PlatformHardwareEngineCard` secara otomatis hanya jika hardware driver vendor terdeteksi di kernel perangkat.

### 3. 🎯 Deep Kernel Latency & Overhead Purge
- **Schedstats Profiling Overhead Purge (`sched_schedstats`)**: Sakelar untuk menonaktifkan pengumpulan statistik profil scheduler di kernel, memangkas siklus CPU yang terbuang sia-sia dan mengurangi micro-stuttering.
- **Sched Tunable Scaling (`sched_tunable_scaling`)**: Kontrol metode penskalaan periode scheduler (Mode 0: None / Tetap, Mode 1: Logarithmic, Mode 2: Linear). Mode 0 mengunci latensi konstan saat core CPU bangun/tidur demi kestabilan frame pacing gaming kompetitif.
- **Real-Time (RT) Runtime Bandwidth (`sched_rt_runtime_us`)**: Penyesuaian alokasi batas bandwidth waktu CPU per detik untuk thread prioritas tinggi (seperti audio low-latency dan input touch driver) dengan panduan keamanan terintegrasi.

---

# Lynx [Codename: Deity] 3.0.25
Released on: 2026-10-04
> **Versi ini** menghadirkan **Perbaikan Kritis Penjadwal Inti (Core Scheduler Architecture Bug Fix): Persistensi Tombol Mode Hybrid pada Transisi EAS dan HMP** — memperbaiki galat logika di mana kemampuan hardware (*kernel capability*) tertukar dengan status aktif runtime (*active state*), memastikan tombol `[ Hybrid ]` tetap persisten dan dapat dipilih kapan saja meskipun pengguna beralih ke mode `EAS` (`1`) atau `HMP` (`0`), serta mengamankan deteksi driver multi-mode MediaTek (`/sys/devices/system/cpu/eas/enable`) sehingga transisi arsitektur berjalan mulus tanpa menghilangkan opsi penjadwalan dari antarmuka pengguna.

## 🚀 Fitur Baru & Peningkatan (3.0.25)

### 1. 🛠️ Perbaikan Kritis: Tombol Mode Hybrid Persisten & Anti-Hilang
- **Pemisahan Kapabilitas Hardware vs Status Runtime**: Memperbaiki logika deteksi pada repository di mana flag `eas_hybrid` dan `isHybridSupported` sebelumnya hanya bernilai true jika mode yang sedang aktif adalah Hybrid.
- **Ketersediaan Opsi 3-Arah Sepenuhnya**: Menghubungkan kapabilitas arsitektur dengan keberadaan driver multi-mode (`hasMtkEas` dan node `/sys/devices/system/cpu/eas/enable`), sehingga opsi `[ EAS ]`, `[ HMP ]`, dan `[ Hybrid ]` selalu tampil lengkap dan dapat dialihkan kapan saja tanpa batas.
- **Transisi Kernel Tanpa Hambatan**: Memvalidasi penulisan nilai `0` (HMP), `1` (EAS), dan `2` (Hybrid) secara aman pada sysfs kernel MediaTek dengan feedback status yang akurat.

---

# Lynx [Codename: Deity] 3.0.24
Released on: 2026-10-04
> **Versi ini** menghadirkan **Penerapan Disiplin Ketat Palet Warna Antarmuka (Strict Color Discipline): Hak Istimewa Ungu Eksklusif untuk Kustom DIY, Soft Tinted Glass pada Matriks Core CPU Sets, Accordion Monokromatik Netral saat Idle, dan Restorasi Tombol Reset OEM ke Abu-abu Tenang** — menyelaraskan arsitektur engine `Hybrid` ke aksen biru terpadu `AccentBlue` agar warna ungu `AccentPurple` (`#A855F7`) murni eksklusif untuk setelan kustom racikan manual pengguna, merombak 24 kotak selektor core manual CPU Sets menjadi kaca transparan lembut (*Soft Tinted Glass*) berlatar 15% dengan border halus, menenangkan seluruh subheader kategori lanjutan (*SCHEDTUNE, CFS, HMP*) dan header accordion menu lipat ke abu-abu perak tenang `TextSecondary`, serta menetralkan tombol `[ 🔄 Reset OEM ]` dari oranye alarm menjadi abu-abu siaga elegan.

## 🚀 Fitur Baru & Peningkatan (3.0.24)

### 1. 🟣 Hak Istimewa Ungu Eksklusif untuk Status Kustom DIY (`AccentPurple`)
- **Pemisahan Semantik Tombol Arsitektur Engine**: Mengubah warna tombol pemilih arsitektur engine `[ Hybrid ]` dari `AccentPurple` menjadi `AccentBlue` (`#00A3FF`).
- **Eliminasi Bias Kustom Palsu**: Mencegah kesan seolah sistem sedang dalam mode kustom saat perangkat berjalan di arsitektur default pabrik.
- **Identitas Visual DIY yang Kuat**: Warna ungu (`#A855F7`) kini 100% eksklusif hanya menyala saat pengguna melakukan modifikasi manual pada parameter tweak, memberikan kepastian visual mutlak.

### 2. 🎛️ Matriks Kotak Core CPU Sets Manual: *Soft Tinted Glass* (15% Transparan)
- **Eliminasi Neon Silau**: Merombak tampilan 24 tombol core (`[0]` s/d `[7]`) pada *Kustomisasi Manual per-Grup* (Top-App, Foreground, Background).
- **Latar Kaca Lembut**: Menggunakan latar transparan `copy(alpha = 0.15f)` dengan border `copy(alpha = 0.5f)` dan teks nomor core berwarna senada dengan grup proses.
- **Status Non-Aktif Netral**: Kotak core yang tidak aktif menggunakan latar belakang `BgSurfaceLowest` dan border halus `BorderSubtle`, menghasilkan keterbacaan tinggi yang sangat ramah di mata.

### 3. 📂 Accordion Menu Lipat Monokromatik Netral saat Idle (`TextSecondary`)
- **Struktur Pendukung Tenang**: Mengubah judul menu lipat *Kustomisasi Manual per-Grup* dan *Kustomisasi Manual (Hotplug & C-States)* saat posisi tertutup (*collapsed*) menjadi `TextSecondary` (`#94A3B8`).
- **Feedback Visual Ekspansi**: Judul dan ikon baru menyala lembut dengan `AccentCyan` hanya saat menu dibuka (*expanded*), menjaga layar tetap rapi dan tidak mencuri fokus utama.

### 4. 🔄 Restorasi Tombol Reset OEM Header ke Abu-abu Tenang
- **Eliminasi False Alarm Oranye**: Mengubah warna ikon tombol `ResetHeaderButton` dari oranye peringatan `#FFA726` menjadi abu-abu perak tenang `TextSecondary`.
- **Hierarki Aksi Sekunder**: Tombol reset kini terbaca sebagai aksi siaga/pemulihan yang elegan, bukan lampu peringatan error atau kerusakan hardware.

### 5. 🏷️ Subheader Kategori Advanced Penjadwal Monokromatik
- **Fokus pada Nilai Tweak Aktif**: Mengubah warna teks subheader `SCHEDTUNE & TASK CAPACITY BOOST`, `SCHEDULER HARDWARE HINTS`, `CFS GRANULARITAS & LATENSI`, dan `HMP TASK BALANCING & QUEUE SPILL` dari neon tebal (`AccentCyan`, `AccentBlue`, `AccentOrange`) ke `TextSecondary` dengan letter spacing rapi.
- Menjadikan slider, pill nilai, dan sakelar interaktif sebagai satu-satunya titik fokus utama di layar.

---

# Lynx [Codename: Deity] 3.0.23
Released on: 2026-10-04
> **Versi ini** menghadirkan **Harmonisasi Palet Warna Semantik Subhalaman CPU: Standardisasi Preset Hijau Ramah Daya, Dual-Tone Spectrum 8-Bar, Harmonisasi Tile Antrean HMP, & Pembersihan Token Desain M3** — menstandarkan seluruh preset hemat daya (*Hemat Daya* pada CPU Sets dan *Deep Sleep* pada CPU Idle) ke aksen hijau resmi `AccentGreen` (`#10B981`) untuk konsistensi semantik intuitif universal, menghadirkan spektrum 8-bar dual-tone dinamis pada kartu telemetri master CPU yang membedakan core efisiensi (Little Core: `AccentBlue`) dan performa (Big Core: `AccentOrange`), menyelaraskan aksen warna tile penjadwalan antrean HMP, serta membersihkan sisa kode heksadesimal mentah pada pill kartu kluster ke token desain resmi Obsidian M3 (`BgSurfaceLowest`).

## 🚀 Fitur Baru & Peningkatan (3.0.23)

### 1. 🟢 Standardisasi Palet Semantik Preset Hemat Daya (`AccentGreen`)
- **Konsistensi Semantik Universal**: Mengeliminasi kontradiksi warna oranye pada profil efisiensi daya. Kini seluruh kartu CPU menerapkan aturan semantik baku:
  - 🟢 `AccentGreen` (`#10B981`): Profil Baterai, Hemat Daya, dan Deep Sleep (Siklus C-States).
  - 🔵 `AccentBlue` (`#00A3FF`): Profil Standar AOSP, Seimbang, dan Little Cores.
  - 🟠 `AccentOrange` (`#FF9F2E`): Profil Responsif, Big Cores, dan Antrean HMP.
  - 🔴 `AccentRed` (`#FF3B5C`): Profil Extreme, Throttling, dan Peringatan Kritis.
  - 🟣 `AccentPurple` (`#A855F7`): Profil Kustom / Manual tuning.
- **Pembaruan CPU Sets Task Shield**: Mengubah warna lencana dan tombol segmen 1-klik *Hemat Daya* dari `AccentOrange` menjadi `AccentGreen`.
- **Pembaruan CPU Idle & Core Parking**: Mengubah warna lencana dan tombol segmen 1-klik *Deep Sleep* dari `AccentOrange` menjadi `AccentGreen`.

### 2. 📊 Spektrum Dual-Tone 8-Bar Dinamis pada Hero Card CPU
- **Diferensiasi Arsitektur Silicon**: Batang spektrum live beban CPU 8-bar pada hero card atas kini secara dinamis membaca tipe kluster core:
  - Little Cores (Core 0..5): Menampilkan aksen biru elegan `AccentBlue`.
  - Big Cores (Core 6..7): Menampilkan aksen oranye mencolok `AccentOrange`.
- **Harmoni Visual Matriks**: Menghasilkan kesinambungan visual yang sempurna antara hero card telemetri atas dengan *Matriks Status Per-Core Silicon* di bawahnya.

### 3. 🟠 Harmonisasi Aksen Tile Penjadwal HMP Task Placement
- **Aksen Oranye pada Antrean Big Core**: Menambahkan properti `accentColor = AccentOrange` pada ketiga tile parameter penjadwal HMP:
  - `Init Task Load (Fork Initial)`
  - `Sched Spill Nr Run`
  - `Sched Spill Load Threshold`
- Menghadirkan visual cue tegas yang membedakan parameter distribusi beban core besar (HMP) dengan penjadwal adil CFS.

### 4. 🎨 Pembersihan Sisa Token Desain Mentah pada Kartu Kluster CPU
- **Eliminasi Hex Statis Pill Kluster**: Mengganti `Color(0xFF10121A)` pada latar belakang pill *Frekuensi Min*, *Frekuensi Max*, dan *Governor Selector* dengan token resmi `BgSurfaceLowest`.
- **Harmonisasi Tombol Kunci Frekuensi**: Memperbarui warna tombol kunci frekuensi kluster aktif dari kode lime mentah `#00E676` ke token terpadu `AccentGreen` dan `AccentGreen.copy(alpha = 0.16f)`.

---

# Lynx [Codename: Deity] 3.0.22
Released on: 2026-10-04
> **Versi ini** menghadirkan **Audit Komprehensif Subhalaman CPU: Integrasi Lembar Preset Penjadwal, Kepatuhan Target Sentuh 44px, Standardisasi LynxSwitch, & Harmonisasi Token Desain M3** — mengintegrasikan lembar bawah panduan terpadu `LynxSchedulerPresetSheet` melalui header profil responsif yang interaktif, menstandarkan tombol sakelar `Child Process Runs First` dengan komponen terpadu `LynxSwitch`, mengoptimalkan seluruh tombol pemilih arsitektur engine dan preset kartu CPU agar memenuhi standar target sentuh minimal 44×44 px (bebas *miss-click*), serta merombak seluruh kode warna statis pada kartu telemetri utama, matriks status per-core silicon, dan dialog konfirmasi ke sistem token desain resmi Obsidian Material 3.

## 🚀 Fitur Baru & Peningkatan (3.0.22)

### 1. 📖 Integrasi Lembar Panduan Preset Penjadwal Kernel (`LynxSchedulerPresetSheet`)
- **Header Profil Responsif Interaktif**: Menghubungkan header badge profil penjadwal (*Preset Cepat* / *Kustom*) agar dapat diketuk untuk membuka lembar bawah interaktif `LynxSchedulerPresetSheet`.
- **Edukasi & Pemilihan 1-Klik**: Lembar ini menyajikan perbandingan mendalam antara 4 profil teruji (*Extreme*, *Responsif / Gaming*, *Seimbang*, dan *Efisiensi Daya*) beserta rincian spesifikasi teknisnya (latensi CFS, ramp-up limit, uclamp, dan RT throttling), serta menutup lembar secara mulus saat salah satu profil dipilih.

### 2. 🎯 Kepatuhan Standar Aksesibilitas & Touch Target 44×44 px (Rule 1)
- **Selektor Arsitektur Engine (EAS / HMP / Hybrid)**: Menambahkan batas ukuran minimal `.defaultMinSize(minWidth = 48.dp, minHeight = 44.dp)` dengan penyelarasan konten terpusat pada tombol segmen arsitektur engine penjadwal, mengeliminasi tombol tipis sub-26dp yang rentan salah sentuh.
- **Tombol Makro Preset Penjadwal, CPU Sets, & CPU Idle**: Menstandarkan seluruh tombol segmen 1-klik pada ketiga kartu inti CPU (`CpuSetsTaskShieldCard`, `CpuIdleCoreParkingCard`, dan `KernelSchedulerCard`) dengan tinggi minimal 44dp sesuai pedoman antarmuka *touch-first*.

### 3. 🔄 Standardisasi Komponen Sakelar Terpadu (`LynxSwitch`)
- **Harmonisasi `Child Process Runs First`**: Menggantikan implementasi baris dan sakelar manual yang menggunakan skala khusus (`Modifier.scale(0.8f)`) pada bagian CFS dengan komponen modular `LynxSwitch`. Kini seluruh sakelar di dalam kartu penjadwal memiliki konsistensi ukuran, tipografi, dan gaya interaksi yang seragam.

### 4. 🎨 Harmonisasi Token Desain Obsidian Material 3 (Rule 4)
- **Matriks Status Per-Core Silicon**: Mengganti seluruh kode warna heksadesimal mentah dengan token desain resmi: `BgSurfaceLowest`, `BgElevated`, `BorderSubtle`, `TextPrimary`, `TextSecondary`, `TextTertiary`, `AccentOrange`, `AccentBlue`, dan `AccentRed`.
- **Hero Card Telemetri & Grafik Sparkline**: Menyelaraskan kartu master hero atas dan kurva gelombang beban real-time ke token Obsidian M3.
- **Dialog Interaktif Aman**: Memperbarui skema warna pada dialog hotplug core, dialog proteksi master core (C0), dan dialog konfirmasi reset OEM per-bagian agar menyatu sempurna dengan tema gelap mendalam (True OLED).

---

# Lynx [Codename: Deity] 3.0.21
Released on: 2026-10-04
> **Versi ini** menghadirkan **Eliminasi Menyeluruh Redundansi Teks, Parameter Usang, dan Harmonisasi Komponen Antar-Kartu Subhalaman CPU** — menstandarkan label frekuensi kluster (`Frekuensi Min` & `Frekuensi Max`), membersihkan duplikasi jumlah core pada subjudul *CPU Idle*, menyelaraskan header bagian preset isolasi *CPU Sets*, memperjelas teks ambang batas beban *Kernel Scheduler Spill*, menstandarkan seluruh sakelar persistensi boot dengan komponen terpadu `LynxSwitch`, serta membersihkan *dead callbacks* dan memperbarui pemisah usang ke `HorizontalDivider`.

## 🚀 Fitur Baru & Peningkatan (3.0.21)

### 1. 🏷️ Harmonisasi Label & Terminologi Kluster CPU
- **Standardisasi Pill Frekuensi**: Memperbarui label pill kartu kluster dari *Batas Bawah* dan *Batas Puncak* menjadi **Frekuensi Min** dan **Frekuensi Max**, menyelaraskan dengan judul lembar pemilih frekuensi (*Pilih Frekuensi Minimum / Maksimum*) serta terminologi tuning kernel standar.
- **Konsistensi Subjudul CPU Idle (C-States)**: Menghapus teks duplikat `${onlineCores}/$totalCores Cores Aktif` dari subjudul kartu karena rasio tersebut sudah ditampilkan secara detail pada telemetri kartu; menggantinya dengan informasi arsitektur bersih: `Driver: ${cpuIdle.driver} • Kernel C-States`.

### 2. 🎨 Penyelarasan Layout & Estetika Visual Antar-Kartu
- **Header Bagian Preset CPU Sets (Task Shield)**: Menambahkan label header bagian `PROFIL ISOLASI CORE` • `Preset Cepat 1-Klik` di atas tombol segmen preset isolasi core, menyelaraskan hierarki desain dengan kartu *Core Parking & CPU Idle*.
- **Standardisasi Sakelar Boot (`LynxSwitch`)**: Mengganti implementasi baris dan switch manual pada kartu *Penjadwal Kernel* dengan komponen terpadu `LynxSwitch`.
- **Harmonisasi Frasa Persistensi Boot**: Menyeragamkan seluruh subjudul sakelar persistensi boot di seluruh kartu CPU menjadi format standar:
  - CPU Sets: `"Terapkan otomatis isolasi CPU Sets saat boot"`
  - CPU Idle & Core Parking: `"Terapkan otomatis setelan CPU Idle & Core Parking saat boot"`
  - Penjadwal Kernel: `"Terapkan otomatis konfigurasi penjadwal saat boot"`

### 3. 🧹 Pembersihan Teks Tweak Penjadwal Kernel & Eliminasi Redundansi
- **Penyempurnaan Deskripsi `sched_spill_load`**: Mengubah subjudul dari *"Ambang batas beban core untuk spillover"* menjadi *"Beban CPU pemicu pengalihan tugas ke core senggang"*, serta memperjelas deskripsinya agar bebas dari pengulangan kata spillover.
- **Eliminasi Komentar Duplikat**: Menghapus baris komentar duplikat pada blok preset makro penjadwal kernel.

### 4. ⚡ Pembersihan Parameter & Callbacks Usang (Dead Code Elimination)
- **Eliminasi `onSchedCstateAwareChange`**: Menghapus parameter dan callback yang tidak digunakan dari `CpuIdleCoreParkingCard` dan call site-nya karena fitur C-State aware telah dipusatkan pada kartu *Penjadwal Kernel*.
- **Pembersihan Flag `isClusterModified`**: Menghapus variabel bendera modifikasi kluster yang tidak lagi digunakan pasca-relokasi tombol reset ke lembar tunables.
- **Modernisasi Komponen Jetpack Compose**: Memperbarui pemisah garis `Divider` yang *deprecated* menjadi `HorizontalDivider` pada seluruh komponen pendukung.

---

# Lynx [Codename: Deity] 3.0.20
Released on: 2026-10-04
> **Versi ini** menghadirkan **Relokasi Tombol Reset Dynamic CPU Khusus ke Lembar Governor Tunables** — menghapus tombol reset pada header kartu utama *Dynamic CPU Clusters & Governors* demi menjaga kebersihan antarmuka utama, serta menyediakan tombol *Reset ke Default OEM* secara terfokus langsung di dalam lembar bawah *Governor Tunables* lengkap dengan dialog konfirmasi aman sebelum mengembalikan parameter kernel ke standar pabrikan.

## 🚀 Fitur Baru & Peningkatan (3.0.20)

### 1. 🧹 Pembersihan Header Kartu Dynamic CPU Clusters
- **Eliminasi Tombol Reset di Header Kartu**: Menghilangkan tombol *ResetHeaderButton* dari sudut kanan atas kartu *Dynamic CPU Clusters & Governors*, menjaga tata letak layar CPU tetap bersih, minimalis, dan tidak memicu ketidaksengajaan reset frekuensi/governor kluster.

### 2. 🎛️ Tombol Reset Khusus pada Lembar Governor Tunables
- **Penempatan Terfokus di Header Tunables**: Menyediakan tombol Reset OEM (`ResetHeaderButton`) secara elegan berdampingan dengan badge jumlah parameter pada header lembar bawah *Governor Tunables*.
- **Dialog Konfirmasi Aman (Reset to OEM Guard)**: Menampilkan konfirmasi interaktif sebelum mereset (*"Reset Tunables Policy X?"*), memastikan pengguna mengonfirmasi intensi pengembalian seluruh parameter tunable kernel governor ke profil pabrikan bawaan OEM.

---

# Lynx [Codename: Deity] 3.0.19
Released on: 2026-10-04
> **Versi ini** menghadirkan **Eliminasi Redundansi Teks & Sinkronisasi Rekomendasi CPU Governor Tunables** — menata ulang seluruh metadata lembar bawah Governor Tunables dengan menghapus pengulangan kata pada judul parameter, membersihkan duplikasi kalimat pada deskripsi dan petunjuk (seperti pada *HiSpeed Target Frequency*, *Interval Sampling*, dan *Min Sample Time*), menghilangkan instruksi redundan pada sakelar boolean (*I/O Wait Boost*), serta menyinkronkan 100% angka rekomendasi dan saran cepat dialog edit dengan tabel profil terkalibrasi kluster (*Little Cores* vs *Big Cores*).

## 🚀 Fitur Baru & Peningkatan (3.0.19)

### 1. 🎯 Sinkronisasi Penuh Rekomendasi Kluster (Asymmetric Tunable Alignment)
- **Kalibrasi Petunjuk Berbasis Identitas Kluster**: Memperbaiki kontradiksi angka rekomendasi pada `up_rate_limit_us` dan `down_rate_limit_us`. Kini lembar tunables menampilkan petunjuk spesifik sesuai tipe kluster yang sedang dibuka:
  - *Little Cores (Policy 0)*: Rekomendasi Ramp-Up `0 µs` (Responsif), `1 ms` (Seimbang), `10 ms` (Hemat Daya) dan Ramp-Down `10 ms` (Responsif), `20 ms` (Seimbang), `1 ms` (Hemat Daya), `30 ms` (OEM).
  - *Big Cores (Policy > 0)*: Rekomendasi Ramp-Up `0 µs` (Instan / Seimbang), `20 ms` (Hemat Daya) dan Ramp-Down `5 ms` (Responsif), `10 ms` (Seimbang), `0.5 ms` (Hemat Daya), `30 ms` (OEM).
- **Saran Cepat Dialog Edit Adaptif**: Menyajikan chip pilihan cepat (*Quick Suggestion Chips*) pada dialog edit nilai yang disesuaikan dengan kluster aktif (misalnya `0 µs (Instan / Seimbang)` dan `20 ms (Hemat Daya)` pada Big Cores), mengeliminasi angka arbitrary statis yang tidak sinkron.

### 2. 🧹 Pembersihan Redundansi Judul & Deskripsi Parameter
- **Pembersihan Judul Bersih & Profesional**: Menghilangkan tanda kurung pengulangan pada judul parameter seperti `(Respon Naik Clock)`, `(Durasi Tahan Clock)`, `(Prioritas Storage)`, serta menyederhanakan `Load Threshold Eskalasi` menjadi `Ambang Beban Naik (Up Threshold)` dan `Ambang Beban Turun (Down Threshold)`.
- **Eliminasi Kalimat Berulang pada Petunjuk**:
  - *HiSpeed Target Frequency*: Menggantikan kalimat duplikat dengan panduan praktis penyesuaian berbasis kurva frekuensi kluster (`Satuan kHz. Otomatis dikalibrasi mengikuti titik tengah kurva frekuensi kluster`).
  - *Interval Sampling (Sampling Rate)*: Menghapus pengulangan deskripsi dan memberikan contoh mikrodetik nyata (`10000 µs = 10 ms (responsif) • 20000 µs = 20 ms (standar)`).
  - *Waktu Minimum Sampel (Min Sample Time)*: Memberikan panduan format mikrodetik (`50000 µs = 50 ms`).
- **Penyederhanaan Petunjuk Sakelar Boolean**: Menghapus teks redundan `1 = Aktif / 0 = Nonaktif` pada *I/O Wait Boost*, menyelaraskan informasi dengan sakelar visual on/off yang telah tersedia.

### 3. 🏷️ Kejelasan Format Preset Subtitle Lembar Bawah
- **Penjelasan Notasi Ramp-Up / Ramp-Down**: Memperjelas subjudul kartu preset dengan menyertakan keterangan tipe kluster dan arti pemisah garis miring (`Profil latensi terkalibrasi kluster (Little Cores / Big Cores • Ramp-Up / Ramp-Down)`), sehingga pengguna memahami makna instan dari kartu seperti `0 µs / 10 ms`.

---

# Lynx [Codename: Deity] 3.0.18
Released on: 2026-10-04
> **Versi ini** menghadirkan **Penyempurnaan Total Normalisasi Penggunaan CPU, Eliminasi Redundansi Schedutil, & Laci Penjadwal Adaptif Hardware** — menuntaskan kalkulasi matematis persentase beban CPU per-proses (normalisasi skala 100% SoC dari Irix mode toybox `top`) dan per-core (eliminasi beban sintetis sehingga rata-rata C0..C7 selaras dengan total load), menghapus seluruh kontrol duplikat schedutil dan C-state pada kartu penjadwal, serta merombak laci *Pengaturan Lanjutan & Hardware Hints* menjadi sepenuhnya cerdas dan dinamis hanya merender node sysfs yang benar-benar didukung oleh kernel/OEM perangkat aktif.

## 🚀 Fitur Baru & Peningkatan (3.0.18)

### 1. 📊 Normalisasi Presisi Persentase CPU Proses & Inti (100% Mathematical Parity)
- **Normalisasi Irix Mode Toybox `top`**: Membagi beban CPU setiap proses secara dinamis berdasarkan jumlah total core perangkat (`rawCpu / totalCores.toFloat()`). Menghilangkan ketidaksesuaian di mana proses latar belakang melebihi total beban SoC, menghasilkan konsistensi visual dan matematis antara daftar proses dan *Total CPU Load*.
- **Pembersihan Beban Inti Sintetis (True `/proc/stat` Delta)**: Menghapus kalkulasi beban buatan pada pembacaan frekuensi idle core. Beban per-core (C0..C7) kini 100% murni merefleksikan delta jiffies kernel Linux, sehingga rata-rata beban seluruh core tepat mencerminkan angka telemetri utama.

### 2. 🧹 Eliminasi Redundansi Kontrol Schedutil & C-State Aware
- **Penghapusan Ubin Duplikat Schedutil**: Menghapus ubin *Rate Limit Respons Clock (Schedutil)* dari kartu Penjadwal Kernel, menghindari kebingungan konfigurasi karena pengaturan *up/down rate limit* telah dikontrol secara asimetris per-kluster pada lembar *CPU Governor Tunables*.
- **Sentralisasi C-State Aware Scheduler**: Menghapus sakelar duplikat dari kartu *Core Parking*, memusatkan pengaturan preferensi tidur inti secara elegan di dalam kelompok *Hardware Hints* kartu penjadwal.

### 3. 🧠 Laci Penjadwal Lanjutan Adaptif Hardware (Strict Dynamic Node Probing)
- **Penghitungan Dinamis Fitur Tersedia**: Menghitung secara nyata jumlah fitur lanjutan yang terekspos oleh kernel (`$availableAdvancedCount Fitur Tersedia`). Menampilkan indikator informatif ketika kernel OEM mengunci antarmuka sysfs penjadwal.
- **Validasi Izin Tulis Nyata (Anti-False Support)**: Memverifikasi eksekusi penulisan aktual pada `/proc/sys/kernel/sched_energy_aware` dan `/sys/devices/system/cpu/eas/enable` guna memastikan pengalihan arsitektur EAS/HMP didukung tanpa crash izin kernel (`EACCES`).
- **Penyaringan Selektif Berbasis Hardware**:
  - *CFS Granularitas & Latensi*: Menampilkan ubin latensi, granularitas preemption, wakeup, dan migration cost hanya jika nodenya ada di `/proc/sys/kernel/`.
  - *Schedtune & Task Capacity*: Menampilkan kontrol boost dan prefer idle hanya jika `/dev/stune` tersedia.
  - *Hardware Hints*: Menyaring *Big Task Rotation*, *Sync Wakeup*, *C-State Aware*, dan *Stune Task Threshold* secara mandiri.
  - *HMP Balancing & Spill*: Menyembunyikan seluruh ubin migrasi HMP jika kernel tidak mengekspos antarmuka `sched_upmigrate` dan `sched_downmigrate`.

### 4. 🔄 Reset to OEM Terpadu & Pembersihan Cache Preferensi
- **Pembersihan Bersih Shared Preferences**: Menghapus tuntas rekaman cache `lynx_scheduler_prefs` saat pengguna mengeksekusi Reset ke Default, mengembalikan nilai trip, boost, dan preset ke standar bawaan kernel pabrikan.

---

# Lynx [Codename: Deity] 3.0.17
Released on: 2026-10-04
> **Versi ini** menuntaskan **Audit & Polish Komprehensif CPU Tuning & Sheet Interaction** — mengoptimalkan lembar bawah pemilih frekuensi (*Frequency Picker*) dan governor (*Governor Picker*) agar langsung terbuka penuh tanpa terpotong (*skipPartiallyExpanded*), memperbaiki logika seleksi frekuensi presisi (eliminasi centang ganda), memperbesar seluruh target sentuh minimal 48dp (mematuhi Rule 1), membersihkan emoji/AI slop pada subkategori CPU & Scheduler, menyematkan aksi Reset to OEM pada kluster CPU, serta meningkatkan ketahanan telemetri CPU Core Spectrum dan dynamic Big-core detection.

## 🚀 Fitur Baru & Peningkatan (3.0.17)

### 1. 📱 Lembar Bawah Pemilih Frekuensi & Governor Lebih Mulus (Fluid Modal Bottom Sheets)
- **Ekspansi Penuh Seketika (`skipPartiallyExpanded = true`)**: Mengatasi masalah bawaan Material 3 di mana lembar pemilih frekuensi dan governor kerap terpotong di ketinggian 50% layar saat pertama kali dibuka.
- **Eliminasi Nested Scroll Terjepit**: Menghapus batas `heightIn(max = 380.dp)` dan menyatukan seluruh daftar item ke dalam single-level fluid vertical scroll.
- **Seleksi Presisi 1-Item (Anti-Duplicate Checkmarks)**: Menggantikan heuristik selisih frekuensi mentah (`Math.abs < 5000`) dengan pencocokan MHz exact (`f == curFreq || (curFreq > 0 && f / 1000 == curFreq / 1000)`), sehingga tidak ada lagi centang ganda pada langkah frekuensi yang berdekatan.
- **Standar Touch Target 48dp (Mobile-First Rule 1)**: Memastikan setiap baris frekuensi dan governor memiliki `minHeight = 48.dp`, bebas dari kesalahan sentuh (*miss-click*).

### 2. 🎛️ Peningkatan Interaksi Kluster CPU (Cluster Tuner Card)
- **Target Sentuh Optimal**: Tombol frekuensi Min/Max, tombol gembok frekuensi (`size(48.dp)`), pill governor, dan tombol aksi Tunables kini memenuhi standar aksesibilitas sentuh 48dp.
- **Aksi Reset to OEM Terpadu**: Mengintegrasikan tombol `ResetHeaderButton` langsung pada header kartu kluster yang telah dimodifikasi, lengkap dengan dialog konfirmasi sebelum mengembalikan frekuensi dan governor ke setelan awal pabrik.

### 3. 🧹 Pembersihan Slop & Penguatan Telemetri CPU (Clean Telemetry & Robustness)
- **Eliminasi Emoji Slop**: Menghilangkan seluruh emoji kaku pada mode penjadwal kernel (EAS, HMP, Hybrid), live status rate limits, Uclamp, HMP, dan Sched init task load demi estetika profesional dan bersih.
- **Ketahanan Spectrum 8-Bar**: Mencegah potensi crash/null-pointer pada visualisasi 8-core CPU Spectrum dengan penanganan null yang aman (`core?.isOnline ?: false`).
- **Kalkulasi Dinamis Big Cores**: Menghitung jumlah Big Cores secara dinamis dari kluster CPU pada kartu *CPU Idle & Core Parking*, menggantikan asumsi hardcoded.

---

# Lynx [Codename: Deity] 3.0.16
Released on: 2026-10-04
> **Versi ini** menghadirkan **Pemisahan Asimetris Per-Kluster Tunables CPU (Asymmetric Multi-Cluster Schedutil Calibration)** — mendesinkronisasi tuning frekuensi kernel di seluruh skrip platform dan Companion backend, sehingga kluster efisiensi (Little Cores) dan kluster komputasi tinggi (Big/Prime Cores) menerima profil latensi yang disesuaikan secara presisi dengan karakteristik fisiknya tanpa saling menyamakan (*flat-broadcast*), serta menyempurnakan deteksi real-time dan tampilan lembar tunables per-kluster.

## 🚀 Fitur Baru & Peningkatan (3.0.16)

### 1. ⚡ Desinkronisasi Menyeluruh Parameter Schedutil Antar-Kluster (Asymmetric Per-Cluster Tuning)
- **Eliminasi Flat-Broadcast Loop**: Menggantikan perulangan statis datar pada seluruh skrip shell (`platforms/mtk/`, `platforms/qcom/`, `platforms/generic/`, dan `core/apply_profile.sh`) dengan percabangan berbasis identitas kluster (`pol_id == 0` vs `pol_id > 0`).
- **Kalibrasi Kluster Efisiensi (Little Cores - `policy0`)**:
  - *Seimbang*: `up: 1 ms (1000 µs)`, `down: 20 ms (20000 µs)` — Mencegah lonjakan frekuensi singkat (*micro-thrashing*) dan mempertahankan clock stabil untuk konsumsi daya minimal.
  - *Responsif / Gaming*: `up: 0 µs`, `down: 10 ms (10000 µs)` — Respons seketika dengan durasi tahan yang optimal.
  - *Hemat Daya*: `up: 10 ms (10000 µs)`, `down: 1 ms (1000 µs)` — Memperlambat peningkatan frekuensi dan segera menurunkan clock saat beban mereda.
- **Kalibrasi Kluster Performa (Big / Prime Cores - `policy > 0`)**:
  - *Seimbang*: `up: 0 µs`, `down: 10 ms (10000 µs)` — Lompatan instan saat beban aplikasi berat membutuhkan daya komputasi tinggi.
  - *Responsif / Gaming*: `up: 0 µs`, `down: 5 ms (5000 µs)` (Extreme: `down: 2 ms`) — Latensi nol untuk komputasi grafis dan *framerate* puncak.
  - *Hemat Daya*: `up: 20 ms (20000 µs)`, `down: 0.5 ms (500 µs)` — Membatasi keterlibatan kluster besar pada skenario siaga.

### 2. 🛠️ Penyelarasan Backend Companion App (`LynxRepository.kt`)
- **Adaptasi Dinamis `applyGovernorPreset`**: Mendukung penyetelan mandiri per-kebijakan (`policyId`) dengan nilai yang disesuaikan otomatis terhadap tipe kluster (`isLittle` vs `isBig`). Penyetelan global secara otomatis membagi parameter asimetris ke masing-masing direktori sysfs.
- **Asymmetric Schedutil Preset Engine**: Mengintegrasikan batas latensi asimetris pada preset makro penjadwal (*Extreme*, *Gaming*, *Battery*, dan *Balanced*).
- **Skala Proporsional Slider Penjadwal**: Penyetelan slider global *up/down rate limit* kini menerapkan penskalaan proporsional antara kluster Little dan kluster Big alih-alih menyamakan nilai mentah secara seragam.

### 3. 🎨 Penyempurnaan Lembar Tunables & Deteksi Real-Time (`LynxComponents.kt`)
- **Catatan Waktu Spesifik Kluster**: Kartu preset pada ModalBottomSheet kini secara transparan menampilkan nilai latensi yang sesuai dengan kluster yang sedang dibuka (contoh: Seimbang pada Policy 0 menampilkan `1 ms / 20 ms`, sedangkan pada Policy 6 menampilkan `0 µs / 10 ms`).
- **Deteksi Status Cerdas (Cluster-Aware Real-Time Detection)**: Algoritma deteksi sysfs otomatis mengenali status preset aktif (*Seimbang Aktif*, *Responsif Aktif*, *Hemat Aktif*, *OEM Aktif*) berdasarkan batas toleransi terkalibrasi untuk masing-masing kluster silikon.

---

# Lynx [Codename: Deity] 3.0.15
Released on: 2026-10-04
> **Versi ini** menuntaskan **Modernisasi & Redesain Menyeluruh Governor Tunables (Anti-Slop)** — merombak antarmuka lembar setelan *Dynamic CPU Clusters & Governors* menjadi sangat bersih, informatif, dan profesional. Menghapus seluruh emoji dekoratif kaku dan menggantinya dengan *Material Vector Icons*, mengintegrasikan 4 Preset Responsivitas Clock berbasis deteksi *hardware sysfs* *real-time* per-kluster, memperbaiki masalah *layout clipping* pada ModalBottomSheet, serta menyempurnakan dialog pengeditan parameter dengan *Live Conversion Preview* mikrodetik ke milidetik dan tombol pill rekomendasi yang rapi.

## 🚀 Fitur Baru & Peningkatan (3.0.15)

### 1. 🧹 Redesain Menyeluruh ModalBottomSheet Governor Tunables
- **Material Vector Icons Penuh**: Menghapus seluruh emoji kaku (`🚀`, `⚖️`, `🍃`, `🔧`) dan menggantinya dengan ikon vektor modern (`Bolt`, `Balance`, `Eco`, `Restore`, `Tune`) yang adaptif terhadap tema aktif dan warna aksen kluster CPU.
- **Penyatuan Scroll Surface Tunggal**: Menghilangkan pembatasan ketinggian kaku (`heightIn(max = 420.dp)`) dan mengaktifkan `skipPartiallyExpanded = true` sehingga lembar bawah terbuka secara alami, mulus, dan bebas dari pemotongan elemen (*clipping*).
- **Eliminasi Kotak Bertumpuk (Anti-Slop)**: Menghapus container abu-abu ganda (`Surface(color = BgElevated)`) yang memadati ruang visual; rekomendasi teknis kini terintegrasi secara mulus dan bersih di bawah deskripsi parameter.
- **Isolasi Tuning Per-Kebijakan (Per-Policy Tuning)**: Penyetelan parameter dan preset kini secara presisi menyasar `policyId` target (contoh: Little Cluster `policy0` vs Big Cluster `policy6`) tanpa saling menimpa (*cluster-isolated*).

### 2. ⚡ 4 Preset Responsivitas Clock & Deteksi Real-Time
- **Preset Terkalibrasi Perangkat Keras**:
  - **Responsif**: `up_rate_limit_us: 0 µs`, `down_rate_limit_us: 5 ms (5000 µs)` — Akselerasi instan tanpa jeda saat beban melonjak.
  - **Seimbang**: `up_rate_limit_us: 1 ms (1000 µs)`, `down_rate_limit_us: 10 ms (10000 µs)` — Transisi mulus antara performa dan penghematan daya.
  - **Hemat**: `up_rate_limit_us: 4 ms (4000 µs)`, `down_rate_limit_us: 20 ms (20000 µs)` — Memperlambat akselerasi frekuensi untuk efisiensi termal.
  - **OEM (Bawaan Pabrik)**: `up_rate_limit_us: 0 µs`, `down_rate_limit_us: 30 ms (30000 µs)` — Kalibrasi bawaan vendor (MediaTek Dimensity/Helio) untuk stabilitas total.
- **Deteksi Status Preset Otomatis**: Badge di sudut kanan atas kartu preset secara cerdas mendeteksi kesesuaian nilai sysfs nyata dan menampilkan status: *Responsif Aktif*, *Seimbang Aktif*, *Hemat Daya Aktif*, *Bawaan OEM Aktif*, atau *Setelan Kustom*.

### 3. ⏱️ Live Conversion Preview & Dialog Pengeditan Parameter Presisi
- **Konversi Unit Real-Time**: Dialog pengeditan parameter kini menampilkan pratinjau konversi dinamis dari mikrodetik (µs) ke milidetik (ms) secara instan (contoh: `30000` otomatis menampilkan `"Setara dengan 30 ms (30000 µs)"`), menghilangkan kebingungan konversi angka besar.
- **Pill Rekomendasi Terpadu**: Tombol cepat rekomendasi diformat ringkas dan terhindar dari pemotongan teks (`5 ms (Cepat)`, `10 ms (Seimbang)`, `20 ms (Stabil)`, `30 ms (OEM)`).
- **Format Display Ringkas**: Nilai parameter pada kartu ditampilkan dalam format waktu yang mudah dibaca (`30 ms`, `0 µs (Instan)`).

---

# Lynx [Codename: Deity] 3.0.14
Released on: 2026-10-04
> **Versi ini** menuntaskan **Eliminasi Redundansi Preset Core Parking & CPU Idle** — menghapus baris tombol preset duplikat di dalam mode lanjutan (Advance), memisahkan dengan tegas peran *Preset Respon Terpadu (Makro 1-Klik)* di bagian awal dengan *Kustomisasi Manual (Hotplug & C-States)* di laci akordion, serta merancang ulang pemilih kebijakan hotplug menjadi Tile Pengaturan Teknis ber-dropdown yang elegan, informatif, dan bebas dari ambiguitas antarmuka.

## 🚀 Fitur Baru & Peningkatan (3.0.14)

### 1. 🧹 Eliminasi Redundansi Preset Ganda pada Core Parking
- **Penghapusan Baris Tombol Duplikat**: Menghapus deretan 3 tombol pill horizontal di mode lanjutan yang sebelumnya meniru tombol preset makro di awal (`Unpark Semua`, `Dinamis`, `Park Big Core`).
- **Hierarki Kontrol yang Tegas**:
  - **Bagian Awal (Atas)**: Berfungsi eksklusif sebagai *Preset Respon Terpadu (Makro 1-Klik)* (`Zero Latency`, `Seimbang`, `Deep Sleep`) untuk konfigurasi instan menyeluruh.
  - **Bagian Lanjutan (Akordion)**: Berfungsi untuk penyesuaian granular manual independen tanpa adanya tombol preset yang saling tumpang tindih.

### 2. ⚙️ Redesain Tile Pengaturan Kebijakan Hotplug Inti
- **Tile Teknis Ber-Dropdown**: Mengganti tombol preset redundan di dalam akordion dengan sebuah Tile Pengaturan Hotplug modern yang menampilkan status kebijakan aktif secara mendalam (ikon, judul, dan deskripsi teknis peran inti).
- **Pemilih Dropdown Intuitif**: Menu dropdown untuk mengubah mode alokasi inti (*Dinamis OEM*, *Unpark Semua Inti*, *Parkir Big Cores*) dengan panduan teknis yang jelas di setiap opsinya.
- **Penyelarasan Judul Akordion**: Memperbarui judul laci menjadi `Kustomisasi Manual (Hotplug & C-States)` agar secara akurat merefleksikan seluruh parameter di dalamnya.

---

# Lynx [Codename: Deity] 3.0.13
Released on: 2026-10-04
> **Versi ini** menghadirkan **Penyempurnaan Visual & Pembersihan Indikator Presisi** — menghapus ikon centang dekoratif pada preset terpilih yang terkesan repetitif (anti-slop), memperhalus indikator seleksi aktif murni berbasis saturasi warna dan kontras border, serta merestrukturisasi pemilih mode *Core Parking Policy* dengan ikon vektor Material.

## 🚀 Fitur Baru & Peningkatan (3.0.13)

### 1. 🧹 Eliminasi Ikon Centang Repetitif (Clean Selection Indicator)
- **Desain Seleksi Minimalis**: Menghapus ikon centang (`✓` / `Check`) pada seluruh tombol preset di kartu *CPU Sets & Task Shield* dan *Core Parking & CPU Idle*.
- **Pembeda Visual Murni**: Status aktif kini ditandai secara elegan melalui aksen warna border proporsional, latar elevasi berpendar halus, serta warna ikon dan teks yang selaras tanpa elemen grafis tambahan yang memadati tombol.

### 2. ⚡ Modernisasi Pemilih Kebijakan Hotplug Inti (Core Parking Policy)
- **Vektor Material Penuh**: Mengganti emoji pada opsi *Core Parking Policy* (`🚀 Unpark Semua`, `⚖️ Dinamis (OEM)`, `🔋 Park Big Core`) dengan ikon vektor `Bolt`, `Tune`, dan `Bedtime`.
- **Tipografi Bersih**: Menghapus seluruh emoji dekoratif dari catatan status dinamis CPU Idle.

---

# Lynx [Codename: Deity] 3.0.12
Released on: 2026-10-04
> **Versi ini** menyempurnakan **Estetika & Konsistensi Visual Subhalaman CPU** — menggantikan ikon emoji bawaan OS yang kaku pada kartu *CPU Sets & Task Shield*, *Core Parking & CPU Idle*, dan *Penjadwal Kernel & Multicore* dengan **Material Vector Icons** modern yang adaptif terhadap aksen tema cyber dark, memberikan tampilan antarmuka yang jauh lebih elegan, tajam, dan profesional.

## 🚀 Fitur Baru & Peningkatan (3.0.12)

### 1. 🎨 Transisi Penuh dari Emoji Kaku ke Material Vector Icons
- **CPU Sets & Task Shield**:
  - Mengganti teks emoji kaku `⚔️ Game Shield`, `⚖️ Standar`, `🔋 Hemat Daya` dengan ikon vektor Material berpresisi tinggi: `SportsEsports` (Gamepad), `Tune` (Equalizer/Sliders), dan `BatteryChargingFull`.
  - Badge mode sudut kanan atas kini menggunakan ikon vektor `Tune` yang selaras dengan aksen status aktif.
  - Menghapus emoji dekoratif dari catatan status alokasi agar tipografi lebih bersih dan fokus pada informasi teknis.
- **Core Parking & CPU Idle (C-States)**:
  - Mengganti emoji kaku `⚡ Zero Latency`, `⚖️ Seimbang`, `🔋 Deep Sleep` dengan ikon vektor `Bolt`, `Tune`, dan `Bedtime` (Bulan Sabit modern).
  - Badge status kini dilengkapi indikator vektor `Tune` yang terpadu.
- **Penjadwal Kernel & Multicore**:
  - Mengganti ikon preset respon jadwal dari emoji ke vektor: `Bolt` (Responsif), `Tune` (Seimbang), `BatteryChargingFull` (Efisiensi), dan `LocalFireDepartment` (Ekstrem).
  - Penyelarasan segmen *Arsitektur Engine* dengan ikon vektor `Bolt` (EAS), `AccountBalance` (HMP), dan `Build` (Hybrid).

### 2. 💎 Dynamic Theme Tinting & Visual State Feedback
- **Adaptasi Warna Dinamis**: Ikon vektor kini secara dinamis mewarisi warna aksen status saat aktif (Cyan, Kuning, Merah, Hijau) dan beralih ke warna sekunder redup saat nonaktif, mencegah tabrakan warna pelangi kartun khas Noto Color Emoji Android.
- **Indikator Seleksi Presisi**: Menyertakan tanda centang (`Check`) vektor yang rapi pada tombol preset yang sedang aktif untuk kepastian visual instan bagi pengguna.

---

# Lynx [Codename: Deity] 3.0.11
Released on: 2026-10-04
> **Versi ini** menghadirkan **CPU & Governor Subscreen Modernization & Anti-Slop Overhaul** — membersihkan total tampilan subhalaman CPU dari jargon fiktif, mengintegrasikan grafik waveform beban real-time ke dalam Hero Master Card, merampingkan matriks 8-core silikon hardware, serta menyederhanakan Penjadwal Kernel & Multicore dari 25+ baris menjadi sistem preset makro cepat dengan laci akordion parameter lanjutan yang rapi dan elegan.

## 🚀 Fitur Baru & Peningkatan (3.0.11)

### 1. 🧹 Eliminasi AI Slop & Penyelarasan Terminologi Kernel Nyata
- **Penghapusan Jargon Fiktif**: Mengganti seluruh penyebutan fiktif "Arctic Engine" / "Arctic" dengan terminologi arsitektur kernel Linux resmi: `EAS + CFS Hybrid Scheduling` dan `EAS Hybrid (Multi-Domain)`.
- **Keterbacaan & Akurasi Teknis**: Memastikan seluruh label mencerminkan mekanisme penjadwalan kernel yang sebenarnya (Energy-Aware Scheduling, Completely Fair Scheduler, dan Heterogeneous Multi-Processing).

### 2. 💎 Desain Bersih & Elegan Matriks Silikon CPU (Scene Hero Card)
- **Integrasi Grafik Beban Waveform Real-Time**: Menggabungkan grafik kurva Bezier beban CPU langsung ke dalam Master Hero Card di bagian atas, mengeliminasi kartu terpisah "Grafik Beban CPU" dan menghemat ~140dp ruang vertikal tanpa mengurangi data telemetri.
- **Matriks 8-Inti Minimalis & Modern**:
  - Menghapus teks repetitif rentang frekuensi `500~2000MHz` dan equalizer 5-batang vertikal yang memadati antarmuka.
  - Menggantinya dengan sel silikon minimalis (`C0`..`C7`) berlatar kontras halus, menampilkan frekuensi MHz aktif secara tegas, *slim progress bar* proporsional, serta persentase beban inti.

### 3. ⚡ Perampingan Total Penjadwal Kernel & Multicore Arsitektur
- **Struktur Hierarki 3-Level yang Intuitif**:
  - **Identitas & Status**: Menampilkan nama penjadwal kernel aktif secara ringkas dengan indikator dot LED `Aktif`.
  - **Pemilih Arsitektur Engine**: Tab segmen bersih untuk beralih mode arsitektur (`EAS`, `HMP`, `Hybrid`).
  - **4 Preset Respon Makro Cepat**: Tombol *quick pill* interaktif (`⚡ Responsif`, `⚖️ Seimbang`, `🔋 Efisiensi`, `🔥 Ekstrem`) dengan highlight warna status instan dan persistensi SharedPreferences.
  - **2 Tile Tweak Esensial**: Akses langsung ke pengaturan kritis `Rate Limit Respons Clock (Schedutil)` dan `Rentang Utilisasi Uclamp (EAS)` tanpa harus menggulir jauh.
  - **Laci Akordion Kolapsibel (`Pengaturan Lanjutan & Hardware Hints`)**: Menyembunyikan 12 parameter mikro lanjutan (CFS Latency, Granularity, Migration Cost, Task Capacity Boost Top-App/FG/BG, Task Rotation, Sync Hint, C-State Aware, Stune Threshold, dan Spillover HMP) ke dalam satu laci ekspansi yang rapi.
- **Penyusutan Drastis Beban Gulir (Anti-Scroll Fatigue)**: Mengurangi panjang halaman subkategori CPU dari sebelumnya 7 kali usapan layar penuh menjadi hanya 3 usapan layar yang nyaman, bersih, dan bebas distraksi.

### 4. 🛡️ Kartu Voltage Control (Undervolting) Ringkas
- **Kondisional Surface Minimalis**: Mengubah kartu peringatan undervolting yang sebelumnya memakan ruang besar menjadi baris Surface 1-baris yang bersih dan proporsional saat kernel perangkat tidak mendukung antarmuka sysfs undervolting tradisional (khas SoC modern).

---

# Lynx [Codename: Deity] 3.0.10
Released on: 2026-10-03
> **Versi ini** menghadirkan **Live Charging Telemetry & Direct Pump Unlock Suite** — menyelesaikan kendala telemetri pengisian daya yang tertahan melalui ticker real-time 1 detik, mengatasi bottleneck antrean root shell, serta membuka penguncian arus pengisian cepat MediaTek Pump Express / Direct Charge Pump (`enable_sc = 1`), disertai penyederhanaan antarmuka CPU Sets dan Core Parking.

## 🚀 Fitur Baru & Peningkatan (3.0.10)

### 1. ⚡ Live Charging Telemetry & Root Shell Optimization
- **Dedicated 1-Second Subscreen Polling Loop**: Menambahkan *lifecycle-aware continuous ticker* pada layar Baterai & Charging (`TuningChargingCategory`), memastikan wattmeter input adaptor, tegangan, arus baterai, dan estimasi waktu selesai diperbarui secara *live* setiap detik tanpa jeda.
- **Root Shell Throughput Unblocking**: Membatasi eksekusi pembacaan proses CPU latar belakang (`top -b -n 1 -m 8`) menjadi setiap 3 detik (dari sebelumnya 1 detik), mengeliminasi *mutex lock congestion* pada shell root sehingga query telemetri sensor baterai sysfs dieksekusi secara instan (<20ms).
- **Robust Line-Filtering & Adapter Current Fallback**: Memperbarui parser pembacaan telemetri di `LynxRepository.kt` agar kebal terhadap baris kosong sistem dan menyertakan kalkulasi matematis arus adaptor dinamis `(W * 1,000,000) / V` saat node `Pump_Express_ICharger` dibaca dalam format desimal.

### 2. 🔌 MediaTek / Transsion Direct Charge Pump & Current Throttle Fix
- **Perbaikan Kritis `enable_sc` (Direct Charge Pump Unlock)**: Mengoreksi logika penulisan `/sys/devices/platform/charger/enable_sc` menjadi `1` pada seluruh profil dan skrip apply profile. Menuliskan nilai `0` sebelumnya secara keliru mematikan chip pengisian cepat (RT9759 Direct Pump) dan protokol PE4.0 Super Charge sehingga arus tertahan pada 0–500 mA.
- **Thermal Cooling Device Reset (`cooling_device56`)**: Menambahkan pengamanan izin `chmod 666` dan peresetan status trip `abcct` ke 0 saat mode spoofing suhu baterai (28°C) aktif, mencegah sistem OEM menurunkan batas arus pengisian daya (*thermal clamping*).
- **Hasil Verifikasi Fisik (Empiris)**: Teruji langsung pada perangkat fisik Infinix X698 (Dimensity 920). Daya input adaptor stabil pada **20.3 W** (8.4 V • 2410 mA) dan arus baterai bersih **+2407 mA** dengan protokol Transsion Super Charge aktif.

### 3. 🎯 UI Affordance & Clean Interface Refinement (CPU Sets & Core Parking)
- **Pembeda Tegas Tombol vs Visual Read-Only**:
  - **Tombol Preset Interaktif**: Dilengkapi indikator centang seleksi `✓` dan kontras outline dinamis pada preset aktif (`Game Shield`, `Standar`, `Hemat Daya`, `Zero Latency`, `Seimbang`, `Deep Sleep`), memberikan afrodansi sentuh yang jelas.
  - **Integrated SoC Silicon Strip (Peta Alokasi Inti)**: Mengubah visual core C0–C7 dari 8 kotak tombol terpisah menjadi **1 pita balok prosesor terpadu (Hardware SoC Silicon Strip)** dengan sekat divider 1px, lampu indikator LED bulat (`●`), dan badge overline `[ MONITOR ]` `READ-ONLY`. Otak pengguna seketika mengenali ini sebagai diagram perangkat keras, bukan tombol klik.
  - **Unified Telemetry Readout Panel (Core Parking)**: Mengonversi kartu status terpisah menjadi satu panel telemetri terpadu 2-kolom dengan badge `[ TELEMETRI ]` dan dot status LED, mengeliminasi kebingungan pengguna yang sebelumnya mengira kartu tersebut adalah tombol toggle tile.
- **Penyederhanaan Dynamic Clusters & CPU Sets**: Menghapus tombol reset redundan dan menyelaraskan seluruh tampilan CPU dalam hierarki yang konsisten.

---

# Lynx [Codename: Deity] 3.0.9
Released on: 2026-09-28
> **Versi ini** menghadirkan **Zero-Delay App Transition & Universal Extreme Mode Performance Suite** — menghilangkan jeda saat berpindah atau menutup aplikasi, meluncurkan Floating Game HUD seketika (0ms), serta memperluas optimasi Extreme Mode secara universal untuk SoC Qualcomm Snapdragon dan MediaTek (EAS Bypass, Multi-SoC IRQ Affinity, Adreno Force-No-Nap, dan Linux CFS Low-Latency Scheduling).

## 🚀 Fitur Baru & Peningkatan (3.0.9)

### 1. ⚡ Zero-Delay App Transition Engine
- **Inversi Peluncuran Floating Game HUD (0ms Immediate Feedback)**: Floating HUD kini diinisiasi seketika pada frame pertama saat game terdeteksi, tanpa terhalang antrean eksekusi skrip kernel yang kini diproses secara asinkron di latar belakang (`Dispatchers.IO`).
- **Zero-Fork Fast Path `write_node()`**: Merekayasa ulang fungsi modifikasi kernel sysfs dengan mekanisme pengecekan langsung tanpa membuat subprocess `chmod` berulang (menurunkan waktu eksekusi skrip profil dari ~4.8 detik menjadi <600 milidetik).
- **Fast Foreground Query (sub-15ms)**: Pemantauan aplikasi aktif memprioritaskan ekstraksi jendela fokus cepat (`mCurrentFocus`) sebelum beralih ke inspeksi hierarki aktivitas penuh.
- **Smart Launcher Dismissal**: Mendeteksi penutupan game kembali ke Home Launcher dan memangkas waktu cooldown penutupan HUD dari 3.5 detik menjadi 1.5 detik secara responsif.
- **Merged Telemetry Query**: Pengambilan status profil aktif kini digabungkan ke dalam satu query telemetri multi-sensor sub-20ms di HUD, memangkas separuh frekuensi root IPC.

### 2. 🛡️ Universal Multi-SoC Extreme Mode Enhancements (Snapdragon & MediaTek)
- **Universal Energy-Aware Scheduling (EAS) Bypass**: Memaksa `sched_energy_aware = 0` dan `sched_sync_hint_enable = 1` di mode Extreme agar task scheduler kernel tidak membatasi performa CPU demi efisiensi daya.
- **Universal Sched Clamping (`uclamp_util_min = 1024`)**: Mengunci utilitas minimum cpuset `top-app` ke 100% kapasitas pada seluruh arsitektur kernel yang mendukung uclamp.
- **Multi-SoC GPU & Display IRQ SMP Affinity**: Otomatis mengidentifikasi interrupt handler grafis baik Qualcomm (`kgsl`, `adreno`, `msm_drm`, `mdss`) maupun MediaTek (`mali`, `ged`, `disp`, `drm`) dan mengisolasinya ke CPU core sekunder (`0x3F`), membebaskan Big Cores 100% untuk komputasi render thread game engine.
- **Qualcomm Snapdragon Adreno Boost**: Mengaktifkan `force_no_nap = 1`, `pwrscale/policy = performance`, `devfreq/adreno_boost = 1`, dan `devfreq/governor = performance`.
- **CPU Online Core Retention**: Memastikan seluruh 8 core CPU tetap aktif (`online = 1`) dan mencegah sleep core yang tidak diinginkan dengan `core_ctl/min_cpus = 4`.
- **CFS Low-Latency Tunables**: Mengonfigurasi `sched_upmigrate = 60`, `sched_downmigrate = 40`, `sched_latency_ns = 3000000`, `vfs_cache_pressure = 40`, dan `swappiness = 50`.

### 3. 🔍 Granular Hardware Profile Verification & Zero-Fallback Interlock Suite
- **Granular Verification Suite (`verify_profile.sh`)**: Mesin audit unit-level independen yang memvalidasi setiap parameter kernel/hardware secara individual (CPU Governor, Min/Max Freq, Schedutil tunables, CCI Interconnect, PPM, Mali GED, FPSGO, CFS Latency, Refresh Rate, Thermal zones, Throttler processes, dan Network/Audio stack).
- **Zero-Fallback Dynamic Hardware Interlocks**:
  - Re-assertion interlock otomatis untuk MediaTek CCI interconnect mode (`cpufreq_cci_mode = 1`) pasca Android Thermal HAL callback.
  - POSIX space-delimited OPP snapping loop untuk adaptasi frekuensi hardware presisi tanpa dependensi pipeline sort eksternal.
  - Schedutil dynamic floor matcher (`eas_floor`) yang cerdas membedakan idle C-states Energy-Aware Scheduling dari kegagalan konfigurasi governor.
  - Penanganan dinamis driver Mali GED runtime idle ratio (`gpu_idle_off`/`gpu_idle_on`).
  - Pemulihan refresh rate adaptif (`60.0Hz` base / `120.0Hz` peak) yang bersih saat keluar dari mode gaming ke mode Balance/Auto.
- **100% Health Score across All Profiles**: Terverifikasi secara empiris di perangkat fisik (Infinix X698 - Dimensity 920) dengan 0 Fallbacks dan 0 Errors untuk seluruh mode (`extreme`, `performance`, `balance`, `powersave`, `auto`).

### 4. 🎮 Intelligent Game Render Pacing & Frame Time Stabilization Suite
- **Resolusi Clamping Frekuensi GPU (300 MHz -> 950 MHz)**: Memperbaiki kendala pada driver GPU-DVFS MediaTek di mana penulisan voltase debug `gpufreq_fixed_freq_volt` membekukan PLL hardware ke indeks terendah (300 MHz). Dengan mengaktifkan `dvfs_enable = 1` dan mereset node debug ke `0 0`, GPU Mali kini bebas melakukan boost hingga puncak maksimal **950 MHz** (peningkatan clock 3.16x lipat).
- **Arsitektur Penguncian Hardware EAS MediaTek**: Mengidentifikasi bahwa penggunaan governor generik `performance` menyebabkan DVFSRC MediaTek melepaskan kait hardware dan menurunkan clock Big Core ke 774 MHz. Lynx kini menerapkan `schedutil` dengan konfigurasi frekuensi simetris (`min = max = 2.05 GHz`), `up_rate_limit_us = 0`, `down_rate_limit_us = 0`, dan `pl = 1`, mengunci Big Core secara permanen di frekuensi puncak 2.05 GHz.
- **Universal Game Thread Pacing Engine (`core/lib/game_pacing.sh`)**:
  - Penemuan topologi CPU dinamis (Zero Hardcoding) mendeteksi Prime, Big, dan Little core secara otomatis.
  - **Thread Render Utama (`UnityMain` / `RenderThread`)**: Dikunci ke Prime Big Core dengan prioritas tertinggi (`nice -20`).
  - **Graphics Worker (`UnityGfxDeviceWorker` / GL / Vulkan Worker)**: Dikunci ke Big Core sekunder dengan `nice -20`, mencegah preemption dan kelaparan draw call GPU.
  - **GPU Driver Backend (`mali-*`, `kgsl-*`)**: Diberikan akses eksklusif ke seluruh Big Core (`nice -20`).
  - **Compute & Physics Jobs (`Job.Worker*`)**: Disebar ke seluruh 8 core (`nice 0`) sehingga core LITTLE bekerja efisien tanpa merebut time slice Big Core.
  - **Audio & Background Decoder (`AudioTrack`, `CRI`, `RxCached`)**: Diisolasi ke core LITTLE (`0x3F`), mengeliminasi jitter audio dan gangguan I/O terhadap pipeline grafis.
- **Optimasi Latensi MediaTek GED & FPSGO**:
  - `switch_idleprefer = 0`: Mencegah FPSGO memindahkan task render aktif ke LITTLE core demi penghematan daya.
  - `enable_switch_down_throttle = 0`: Mematikan penurunan frekuensi mendadak saat transisi adegan atau dialog.
  - `ultra_rescue = 1`: Mengaktifkan boost seketika saat terdeteksi beban frame render melampaui deadline.
  - `target_t_cpu_remained = 8333333`: Mengunci sisa target komputasi CPU ke standar 120 FPS (8.33ms budget).
  - Prioritas Real-Time Buffer Gralloc: Meningkatkan prioritas `android.hardware.graphics.allocator@4.0-service-mediatek` ke `nice -20` untuk mengeliminasi penundaan alokasi buffer Surface.
- **Hasil Kinerja Empiris**:
  - Frame presentation time pada skenario pertempuran 3D intensif turun dari **31.30 ms** menjadi **24.93 ms** dengan variasi latensi mendekati nol (<0.01 ms).
  - Health Audit Score mencapai **100%** (48 PASS, 2 CLAMPED, 0 FALLBACK, 0 ERROR) pada mode Extreme dan Balance.

### 5. 🎮 Non-Intrusive Edge Drawer (Infinix Game Space / ROG Game Bar Style HUD)
- **Arsitektur Dual-State Ergonomis**:
  - **State 1 (Collapsed Handle)**: Strip vertikal tipis bercahaya cyan docked di tepi layar/bezel saat bermain game sehingga layar tetap bersih 100% tanpa menghalangi pandangan maupun kontrol sentuh game. Handle mendukung penyesuaian posisi vertikal (drag) dan gesture geser ke dalam (swipe inward) atau ketukan (single tap) untuk membuka.
  - **State 2 (Expanded Game Bar)**: Drawer frosted-glass cyberpunk modern menampilkan matriks telemetri lengkap (Live FPS, AVG, 1% Low, Frametime Sparkline, CPU & GPU load/clock/temp, RAM/ZRAM, dan konsumsi daya Watt baterai).
- **Auto-Collapse Inactivity Timer**: Drawer otomatis menutup kembali ke tepi layar secara halus setelah 5 detik tanpa sentuhan, mencegah gangguan fokus saat gameplay kembali intensif.
- **Quick Gaming Tools & Profile Switcher**:
  - **1-Tap Profile Switcher**: Beralih langsung antara profil `[BAL]`, `[PERF]`, `[EXT]`, dan `[PWR]` tanpa perlu keluar dari game.
  - **⚡ Boost RAM**: Eksekusi pembersihan cache sistem dan pembebasan memori (drop caches) instan.
  - **🔒 Lock Refresh Rate**: Penguncian cepat display refresh rate (60 Hz / 90 Hz / 120 Hz).
  - **📌 Pin Mini FPS**: Opsi menampilkan floating mini FPS pill terpisah yang tetap terlihat saat drawer tertutup.
  - **⏱️ 60s Live Benchmark**: Memicu perekaman pacing hardware 60 detik langsung dari drawer.
- **Interchangeable Interaction Modes**: Pengguna dapat dengan mudah beralih antara mode **Edge Drawer (Game Bar)** dan **6 Gaya Classic Floating Window** langsung dari HUD maupun via kartu konfigurasi di aplikasi Lynx Companion.

### 6. ⚡ True Bypass Charging & Extreme Fast Charging Suite (Universal Multi-SoC)
- **Resolusi Akar Masalah Penurunan Baterai Saat Mengisi Daya di Mode Extreme**:
  - Mengidentifikasi bahwa daemon pengontrol suhu pengisian bawaan kernel MediaTek (`sw_jeita` di `/sys/devices/platform/charger/sw_jeita`) aktif secara default (`1`). Saat temperatur baterai menyentuh 43–45°C dalam gaming beban tinggi di mode Extreme, JEITA memotong arus pengisian (`chg1_current`) menjadi 0 mA. Akibatnya, sistem terpaksa menarik daya dari baterai (`current_now = -768mA` s/d `-1500mA`) meskipun terhubung ke pengisi daya.
  - Memperbaiki bug pada skrip thermal di mana penulisan `min_state = max_state` pada thermal cooling devices secara tidak sengaja memicu throttling maksimum pada `abcct`/`bcct` (battery charging current throttle).
  - Merevisi logika bypass terdahulu yang mematikan arus dengan `input_suspend = 1` (yang memutus daya USB dan memaksa konsumsi baterai penuh).
- **Arsitektur True Bypass Charging (Direct Motherboard Vsys Power Path)**:
  - Mempertahankan jalur daya USB tetap aktif (`input_suspend = 0`) dan membuka kapasitas arus input adapter ke tingkat maksimum (`input_current = 4294967295`), memungkinkan motherboard dan SoC ditenagai langsung dari adaptor charger.
  - Mengaktifkan node OEM bypass lintas arsitektur: `bypass_charger`, `direct_charging`, `smart_charging`, `store_mode`, `batt_slate_mode`.
  - Pada OEM Transsion (Infinix, Tecno): mengaktifkan `enable_sc = 1`, mengunci target persentase SOC (`sc_tuisoc = $cur_cap`), dan membatasi arus pengisian baterai ke nol (`sc_ibat_limit = 0`) tanpa memutus Vsys motherboard.
  - Baterai terlatch pada persentase konstan, temperatur baterai tetap dingin, dan terbebas dari siklus panas kimiawi saat gaming intensif.
- **Extreme High-Current Fast Charging Suite**:
  - **Bypass JEITA Throttler**: Menonaktifkan pembatasan suhu arus pengisian (`sw_jeita = 0`), menjaga suplai arus tetap tinggi dan stabil di mode Extreme.
  - **Protokol Fast Charging Hardware**: Mengaktifkan Pump Express 2.0 & 4.0 (`Pump_Express = 2`, `pe20 = 1`, `pe40 = 1`, `pdc_max_watt = 68`).
  - **Arus Maksimal Multi-SoC**: Membuka limit arus pengisian baterai (`chg1_current`, `chg2_current`, `input_current`), Transsion SC (`sc_ibat_limit = 6000`), serta Qualcomm/Universal (`constant_charge_current_max`, `current_max = 6000000`, `fastcharge_mode = 1`, `restricted_charging = 0`).
  - **Terverifikasi pada Pengujian Nyata**: Arus pengisian pada perangkat fisik Infinix X698 berhasil dibalikkan dari kondisi terkuras (`-768mA`) menjadi pengisian daya cepat aktif (`+636mA` hingga `+846mA`), dan persentase baterai berhasil bertambah stabil saat gaming berat.
- **Antarmuka & Kontrol Lynx Companion**:
  - Penambahan toggle **Bypass Charging (Direct Motherboard)** dan **Extreme Fast Charging (High Current)** pada Tab Baterai & Daya.
  - **Live Charging Telemetry Strip**: 4 metrik telemetri hardware real-time (Arus Baterai live mA, Daya Masuk live Watts, Tegangan Adapter live Volts, dan Suhu Baterai °C) serta deteksi chip protokol hardware otomatis (seperti `Pump Express (8.8V)`).
  - **Resolusi Clamping Batas Arus (1500mA -> 4500mA Default)**: Menaikkan batas bawaan dari 1500mA ke 4500mA dengan rentang slider fleksibel 1000–6000mA, mengaktifkan fast charging penuh secara otomatis saat limit >= 3000mA.
  - **Zero-Collision Touch & Optimistic State UI**: Mengeliminasi tabrakan klik ganda pada `LynxSwitch` di Jetpack Compose Material 3 (`onCheckedChange = null` pada inner Switch) dan mengaplikasikan *optimistic UI state update* untuk respon instan (0ms).
  - Dynamic Status Banner visual: Cyan untuk Bypass Mode, Oranye-Merah untuk Extreme Fast Charge, Cyan untuk Fast Charging Otomatis, dan Oranye untuk Pengisian Teratur.
  - Eksekusi langsung ke sysfs kernel secara real-time via `LynxRepository.applyChargingMode` baik dalam Standalone Root Mode maupun Module Root Mode.

---

# Lynx [Codename: Deity] 3.0.8
Released on: 2026-09-28
> **Versi ini** memperbarui durasi **Live Benchmark OSD di Floating Game HUD** menjadi **1 Menit (60 detik)** penuh, memungkinkan analisis kestabilan frametime jangka panjang, deteksi thermal throttling progresif, serta perataan pacing yang lebih representatif saat gameplay intensif.

## 🚀 Fitur Baru & Peningkatan (3.0.8)

### 1. ⏱️ 1-Minute Live Benchmark pada Floating Game HUD
- **Standar Durasi 1 Menit (60 Detik)**: Tombol benchmark instan di Expanded Game HUD kini disetel ke durasi 60 detik (sebelumnya 10 detik).
- **Pemantauan Pacing Jangka Panjang**: Pengujian 60 detik menangkap siklus gameplay realistis (rotasi peta, pertempuran, burst efek partikel) serta efek kenaikan suhu terhadap kestabilan frame delivery.
- **Hitung Mundur Real-Time**: Tampilan tombol HUD menampilkan indikator live `Merekam Pacing... (60s)` hingga `(0s)`.
- **Benchmark Studio Dialog Synchronization**: Di dalam aplikasi utama Lynx Companion, opsi default juga disesuaikan ke 1 Menit (60s) dengan pilihan rentang `10s`, `30s`, `1 Min`, dan `2 Min`.

---

# Lynx [Codename: Deity] 3.0.7
Released on: 2026-09-28
> **Versi ini** menghadirkan **Live Hardware Benchmark Studio & Frame Pacing Profiler**, pembaruan ergonomi Floating Game HUD (Frame Time langsung di Mini Pill), penguncian hardware fixed OPP GPU, bypass limit table Mali, dan isolasi SMP Affinity IRQ CPU.

## 🚀 Fitur Baru & Peningkatan (3.0.7)

### 1. ⚡ Live Hardware Benchmark & Frame Pacing Studio
- **Presisi Hardware Presentation Latency**: Menggunakan ekstraksi timestamp hardware SurfaceFlinger (`dumpsys SurfaceFlinger --latency`) untuk mengukur waktu sesungguhnya saat frame ditampilkan ke panel layar.
- **Metrik Diagnostik Komprehensif**:
  - Average FPS & Median Frametime (ms)
  - 1% Low FPS & 0.1% Low FPS
  - Frametime Jitter / Standard Deviation (ms)
  - Peak / Min Latency & Max Spike (ms)
  - Janky Frames Count & Percentage (>33.3ms)
  - Hardware Telemetry (CPU Avg, GPU Avg & Load, Suhu Baterai, Konsumsi Daya Watt)
- **Interactive Canvas Frametime Chart**: Visualisasi kurva latensi per frame secara real-time dengan garis panduan 16.6ms (60 FPS) dan 33.3ms (30 FPS).
- **Akses Fleksibel**: Dapat dijalankan dari Dashboard (Tab 0), Tools (Tab 3), serta tombol Quick Benchmark (10s) langsung di Floating Game HUD tanpa meninggalkan game.

### 2. 🎮 Ergonomi HUD OSD — Frame Time pada Mini Pill
- Menggantikan label 120Hz pada Mini Pill HUD dengan nilai **Live Frame Time (ms)** (misal `23.8ms`) yang berdampingan langsung dengan FPS, memberikan informasi instan tentang konsistensi rendering.
- Nilai Refresh Rate panel (Hz) tetap ditampilkan dengan rapi pada grid telemetri di mode Expanded HUD.

### 3. 🔥 Peak GPU & IRQ Performance Clamping
- **Hardware Fixed OPP Lock**: Menulis frekuensi puncak KHz ke `/proc/gpufreq/gpufreq_opp_freq` untuk mengunci register OPP GPU Mali di frekuensi tertinggi.
- **Bypass Limit Table GPU**: Menonaktifkan seluruh pembatas thermal, battery OC, battery low, dan governor policy pada `/proc/gpufreq/gpufreq_limit_table`.
- **Mali DVFS Disable**: Mematikan DVFS kbase driver di mode Extreme (`/proc/mali/dvfs_enable = 0`) agar GPU tidak pernah mengalami micro-downclock.
- **Mali GPU IRQ Affinity Isolation**: Mengalihkan interrupt handler Mali ke CPU 0–5 (`0x3F`), mengisolasi Big Cores (Cortex-A78) 100% untuk komputasi render thread game engine.
- **VFS Cache Pressure Tuning (`vm.vfs_cache_pressure = 40`)**: Mencegah pembuangan cache direktori dan file tekstur di RAM selama transisi scene dan rotasi 3D.

---

# Lynx [Codename: Deity] 3.0.6
Released on: 2026-09-28
> **Versi ini** menghadirkan **Frametime & Sustained FPS Optimization Suite** untuk Extreme dan Performance mode — meminimalisir frame delivery jitter, menghilangkan micro-stuttering pada 3D open-world gaming, serta mengoptimalkan SurfaceFlinger buffer latching, MediaTek FPSGO Ultra Rescue, dan Linux CFS low-latency scheduling.

## 🚀 Fitur Baru & Peningkatan (3.0.6)

### 1. ⏱️ SurfaceFlinger & Frame Pacing Pipeline Optimization
- **`debug.sf.latch_unsignaled = 1`**: Mengizinkan SurfaceFlinger melakukan latch render buffer seketika setelah GPU selesai me-rasterize tanpa harus menunggu sinyal fence siklus VSYNC berikutnya, memangkas display input lag 1–2 frame dan menghilangkan frame drop artificial.
- **`debug.sf.enable_gl_backpressure = 0` & `disable_backpressure = 1`**: Menghilangkan backpressure pipeline GPU yang sering kali memblokir RenderThread game saat rendering frame kompleks.
- **SkiaGL Threaded Backend & Phase Offsets**: Mengaktifkan `debug.renderengine.backend skiaglthreaded` bersama offset fase mikrodetik (`early_phase_offset_ns 500000`, `early_gl_phase_offset_ns 3000000`) untuk penyerahan frame sub-millisecond.

### 2. ⚡ MediaTek FPSGO Ultra Rescue & GED Anti-Stutter Tuning
- **GPU Idle Elimination (`gpu_idle = 0`)**: Mematikan state idle mikro pada Mali GPU di mode Extreme agar shader core tidak mengalami siklus tidur-bangun antar draw call yang memicu spike frametime.
- **FPSGO Ultra Rescue (`ultra_rescue = 1`)**: Mengaktifkan MediaTek Ultra Rescue untuk mendeteksi frame time overrun secara sub-millisecond dan menginjeksi CPU boost seketika sebelum frame drop terjadi.
- **Light Loading Policy Bypass (`light_loading_policy = 0`)**: Mencegah penurunan clock otomatis saat transisi adegan/menu di dalam game.
- **Hardware MDP Composition Offloading (`ged_force_mdp_enable = 1`)**: Mengalihkan komposisi overlay ke MediaTek Display Processor, menghemat ALU execution unit GPU Mali untuk 3D rendering murni.
- **GED Top-App PID Prioritization (`gx_top_app_pid`)**: Menginjeksi PID game aktif secara dinamis ke driver GED untuk prioritas antrean command stream GPU tertinggi.

### 3. 🧠 Linux CFS Scheduler Low-Latency Preemption
- **Scheduling Latency Epoch 4ms (`sched_latency_ns = 4000000`, `sched_min_granularity_ns = 500000`)**: Memperketat jendela penjadwalan CPU dari default 10ms menjadi 4ms, memastikan thread game diprioritaskan tanpa tertunda oleh background worker.
- **Instant Core Migration (`sched_migration_cost_ns = 50000`)**: Menurunkan ambang migrasi dari 200µs ke 50µs agar thread rendering game segera berpindah ke cluster Big (A76) seketika ada beban rendering.
- **Thread Spawning Acceleration (`sched_child_runs_first = 1`)**: Thread worker yang di-spawn oleh game engine (seperti Unity Job System `Job.Worker` atau Unreal Engine worker) langsung dieksekusi seketika.
- **C-State Aware Packing Disable (`sched_cstate_aware = 0`)**: Mematikan pemadatan tugas ke core hemat daya pada Extreme mode.

### 4. 🎯 Dynamic Game Process & Thread Renicing
- Pada saat game aktif terdeteksi oleh watcher/daemon, seluruh thread proses game (`UnityMain`, `UnityGfxDeviceW`, `Job.Worker`, `RenderThread`) secara otomatis di-renice ke tingkat prioritas tertinggi Linux (`nice -20`), diberikan I/O Real-Time (`ionice -c 1 -n 0`), dan dialokasikan ke `top-app` cpuset.

### 5. 🗄️ Storage I/O Read-Ahead 2048 KB (Zero Stutter World Streaming)
- Meningkatkan buffer UFS/MMC `read_ahead_kb` ke 2048 KB dan `nr_requests` ke 512 untuk mengeliminasi hitching saat streaming tekstur dan model 3D di game open-world.

---

# Lynx [Codename: Deity] 3.0.5

## 🐛 Critical Bug Fixes (3.0.5)

### 1. ⚡ Fix GPU Extreme Mode — OPP Index vs KHz Mismatch
- **Root Cause**: Node `custom_upbound_gpu_freq` dan `gpufreq_opp_freq` di MTK GED HAL menggunakan **OPP Index** (0 = frekuensi tertinggi, 48 = terendah), bukan nilai KHz. Script lama menulis nilai `950000` (KHz) ke node index ini, sehingga GED menginterpretasinya sebagai "index 950000" yang tidak valid dan mem-fallback ke index 48 (= 300 MHz minimum).
- **Fix**: Tulis `0` (index 0 = OPP tertinggi) ke `custom_upbound_gpu_freq` dan `gpufreq_opp_freq`. Nilai KHz tetap digunakan di node `gpu_cust_upbound_freq` dan `gpu_cust_boost_freq` dari `/sys/module/ged/`.
- **Tambahan**: Aktifkan `gpufreq_fixed_freq_volt` dengan nilai puncak OPP untuk memastikan GPU terkunci di 950 MHz pada mode Extreme.

### 2. 🔒 Fix CPU Extreme Mode — MTK PPM Index vs KHz Mismatch
- **Root Cause**: Node `hard_userlimit_min_cpu_freq` dan `hard_userlimit_max_cpu_freq` di PPM (MediaTek Power Policy Manager) juga menggunakan **OPP Index** bukan KHz. Script lama mengirim nilai KHz mentah yang salah diinterpretasikan oleh PPM.
- **Fix**: Tulis `<cluster_id> 0` (index 0 = frekuensi puncak) untuk extreme, dan index proporsional untuk performance.

### 3. 🚀 Fix CPU Extreme — Governor Switch ke `performance`
- **Root Cause**: `mtkpower@1.0-service` (MTK Power HAL daemon) terus me-reset `scaling_min_freq` ke nilai defaultnya, menimpa nilai yang ditulis oleh `apply_profile.sh`.
- **Fix**: Mode Extreme kini menggunakan CPU governor **`performance`** (bukan `schedutil`), yang secara otomatis memaksa CPU berjalan di `scaling_max_freq` tanpa bergantung pada `scaling_min_freq`. Ini secara efektif mem-bypass interferensi mtkpower HAL.

### ✅ Hasil Terverifikasi (Infinix X698, Dimensity 920)
- CPU policy0 (A55): governor `performance`, freq **2000 MHz** ✅
- CPU policy6 (A76): governor `performance`, freq **2050 MHz** (saat load) ✅
- GPU: fixed_freq **950 MHz** enabled via `gpufreq_fixed_freq_volt` ✅

---

# Lynx [Codename: Deity] 3.0.4
Released on: 2026-09-28
> **Versi ini** menghadirkan **Audit & Hardening Total Seluruh Profil Hardware (18 Vektor Subsistem)** untuk Extreme, Performance, Balance, dan Powersave, menjamin **Zero Missing Tweaks & 100% Parity** antara Standalone Root Mode dan Magisk/KernelSU Module Mode, resolusi Unity FPS Uncap read permission collision, serta sinkronisasi per-app profile targeting secara komprehensif.

## ✨ Fitur Baru & Peningkatan (3.0.4)

### 1. ⚡ Master Hardware Profile Applicator (`apply_profile.sh` — 18 Subsystem Vectors)
- **Audit Menyeluruh 18 Vektor Subsistem**: Melakukan audit dan harmonisasi komprehensif pada seluruh profil hardware (`extreme`, `performance`, `balance`, `powersave`, `auto`):
  - **CPU Core & Governors**: Kunci frekuensi min/max presisi, governor selection (`performance`, `schedutil`), dan pemulihan dynamic range.
  - **Schedutil Rate Limits**: `up_rate_limit_us` 0µs untuk lompatan frekuensi seketika pada mode gaming/extreme, dan ramp-down terukur pada mode seimbang/hemat daya.
  - **MediaTek Deep Tuning**: Aktivasi `Performance(Sports) mode` pada `/proc/cpufreq/cpufreq_power_mode`, penguncian PPM userlimit table (`hard_userlimit_min_cpu_freq`), dan CCI boost.
  - **GPU Acceleration**: Boost DVFS margin 99% pada Mali GED (`/proc/ged/hal/custom_margin`) dan devfreq boost max pada Qualcomm Adreno (`/sys/class/kgsl/kgsl-3d0`).
  - **UCLAMP & CPUSET**: Task clamping top-app min 100% untuk prioritas frame rendering maksimal pada CPU cluster Big/Prime.
  - **Virtual Memory & Storage I/O**: Swappiness teroptimasi (60 extreme, 70 perf, 80 balance, 100 powersave), MGLRU boost, dan peningkatan I/O read-ahead (2048KB).
  - **OEM Throttler Neutralizer**: Membekukan daemon termal OEM (`thermal-engine`, `mi_thermald`, `thermalloadalg`) via sinyal `SIGSTOP` pada mode extreme/gaming dan memulihkan via `SIGCONT` pada mode balance.
  - **Display, Wi-Fi & Audio**: TouchBoost touch response, low-latency Wi-Fi gaming packet stack, dan AAudio MMAP FastMixer low-latency.
  - **Process Priority & Lib Injection**: Renice `-20` pada `surfaceflinger` dan HWComposer, serta injeksi `sched_lib_name` untuk library game populer (Unity, Unreal Engine).

### 2. 🛡️ Unity FPS Uncap Read Collision Resolution
- **Pre-Flight Permission Recovery**: Memperbaiki isu di mana teknik bypass limit FPS Unity (`chmod 000` pada `cpuinfo_max_freq` dan `cpu_capacity`) menyebabkan pembacaan frekuensi kosong pada pergantian profil berikutnya.
- **Dynamic Fallback Parsing**: Menambahkan pemulihan izin otomatis (`chmod 444`) sebelum pembacaan sysfs dan mekanisme fallback cerdas ke `scaling_available_frequencies`.

### 3. 🎯 Full Parity: Standalone Root Mode & Module Mode
- **Zero Gap Between Modes**: Sinkronisasi penuh antara implementasi Kotlin di `LynxRepository.kt` dan skrip shell root `/data/adb/lynx/apply_profile.sh`.
- Pengguna Standalone Root Mode kini menikmati seluruh 18 tweak subsistem yang setara 100% dengan pengguna modul terpasang di Magisk/KernelSU.

### 4. 📱 Dynamic Per-App Profile Targeting pada Watcher Daemon
- Watcher daemon mandiri (`lynx_watcher.sh` & `Smart-AI.sh`) kini mengekstrak target profil dinamis langsung dari `app_rules.tsv` dan memanggil `apply_profile.sh` dengan parameter profil spesifik per aplikasi yang sedang aktif di latar depan.

---

# Lynx [Codename: Deity] 3.0.3
Released on: 2026-09-27
> **Versi ini** menghadirkan arsitektur **Dual-Engine Per-App Automation** dengan daemon latar belakang root mandiri (*Unkillable Standalone Root Watcher*) yang beroperasi penuh di latar belakang tanpa bergantung pada antarmuka aplikasi, kebal pembunuhan proses Android, serta pemulihan otomatis pasca-reboot.

## ✨ Fitur Baru & Peningkatan (3.0.3)

### 1. 🛡️ Unkillable Standalone Root Watcher Daemon (`lynx_watcher.sh`)
- **Proses Root Mandiri (UID 0)**: Watcher berjalan terpisah dari proses Android zygote/JVM di bawah `init` (PPID 1), menjadikannya kebal terhadap pembersihan Recent Apps, pembatasan baterai OEM (XOS/MIUI/ColorOS), maupun `am force-stop`.
- **Eksekusi 0ms Instan**: Memantau aplikasi aktif dengan latensi sub-30ms via `dumpsys activity activities` (`topResumedActivity`) dan menerapkan profil hardware (CPU Schedutil 0µs ramp-up, GPU GED/Adreno boost, Display 120Hz, dan Floating HUD) secara seketika saat aplikasi dibuka.
- **Hysteresis Cooldown Buffer (4 Detik)**: Mempertahankan mode performa selama 4 detik saat berpindah aplikasi singkat (membuka notifikasi, floating chat, atau menu recent) sebelum secara halus mengembalikan frekuensi dan governor ke mode seimbang.
- **Deep Sleep Shield**: Otomatis menghentikan loop polling saat layar mati (`mHoldingDisplaySuspendBlocker=false`), mengembalikan profil hemat daya, dan mengizinkan CPU masuk ke C-States penuh tanpa menguras baterai standby.

### 2. ⚡ Dual-Engine Architecture & Task-Swipe Immunity
- **Perlindungan Task Removal**: Penambahan `android:stopWithTask="false"` pada manifest dan override `onTaskRemoved()` pada `LynxAppAutomationService` untuk memastikan kelangsungan hidup daemon saat pengguna menyapu aplikasi dari daftar tugas terkini.
- **Deteksi Status Persisten**: Logika pengecekan switch UI kini memverifikasi langsung keberadaan proses daemon root aktif melalui `isAppAutomationRunning()`, sehingga switch selalu akurat dalam posisi aktif meskipun aplikasi baru saja dibuka kembali.

### 3. 🔄 Cold-Boot Auto-Recovery (`LynxBootReceiver`)
- **Penanganan Boot Android**: Menambahkan `LynxBootReceiver` yang mendengarkan sinyal `BOOT_COMPLETED`, `LOCKED_BOOT_COMPLETED`, dan `QUICKBOOT_POWERON`.
- Jika otomasi aktif sebelum restart, sistem secara otomatis membangkitkan Root Watcher Daemon dan layanan notifikasi saat perangkat dinyalakan kembali tanpa perlu membuka aplikasi Lynx secara manual.

### 4. 🚀 Format Pemetaan Kecepatan Tinggi (`app_rules.tsv`)
- Mengompilasi aturan per-aplikasi ke format pemetaan TSV terindeks pipa (`packageName|targetProfile|targetRefreshRate|autoFloatingHud|appName`) secara otomatis di `/data/adb/lynx/app_rules.tsv` untuk evaluasi shell berkecepatan sub-milidetik tanpa overhead parsing JSON.

---

# Lynx [Codename: Deity] 3.0.2
Released on: 2026-09-27
> **Versi ini** menghadirkan pembaruan besar pada manajemen Penjadwal Kernel & Gubernur (CFS/EAS), Otomasi Profil Per-Aplikasi & Game Picker UI cerdas, sinkronisasi penuh WebUI KernelSU/APatch, serta panduan arsitektur penyediaan driver hardware kustom.

## ✨ Fitur Baru & Peningkatan (3.0.2)

### 1. 🎮 Otomasi Profil Per-Aplikasi & Visual Game Picker UI
- **Visual App/Game Picker Dialog**: Pemilih aplikasi dan game visual terpadu dengan pencarian instan, filter kategori cerdas (Semua, 🎮 Game, ⚡ Belum Dikonfigurasi), serta deteksi otomatis tag kategori game.
- **Konfigurasi Profil Per-Aplikasi**: Pengguna dapat mengunci profil performa khusus (Extreme, Performa, Balance, Hemat), memaksakan refresh rate panel (60Hz, 90Hz, 120Hz), serta mengaktifkan overlay Floating Game HUD secara otomatis saat aplikasi dibuka.
- **Sinkronisasi Multi-Level**: Sinkronisasi instan dua arah ke `/data/adb/lynx/applist_perf.txt` dan `app_rules.json` (serta `$MODULE_DIR/core/` saat modul terpasang), memicu respon 0ms boost pada daemon AI Core.

### 2. ⚡ Penjadwal Kernel & Gubernur Deep Tunables (CFS / EAS / BORE)
- **Deteksi Jujur BORE Engine**: Memeriksa keberadaan node `/proc/sys/kernel/sched_bore` secara dinamis dan menampilkan badge status jujur (`CFS / EAS` dengan `BORE: UNSUPPORTED` pada kernel stock).
- **3 Preset Penjadwal Cepat**:
  - `⚡ Gaming`: Menyetel `sched_latency_ns` ke 4ms, `up_rate_limit_us` ke 0µs (lompatan instan tanpa jeda), dan `down_rate_limit_us` ke 5ms.
  - `⚖️ Balanced`: Pemulihan nilai seimbang AOSP (`sched_latency_ns` 10ms, `up_rate_limit_us` 500µs, `down_rate_limit_us` 20ms).
  - `🔋 Battery Saver`: Penjadwalan hemat daya (`sched_latency_ns` 20ms, `up_rate_limit_us` 4000µs).
- **Slider Parameter Presisi**: Kontrol langsung untuk CFS Latency, Min Granularity, Wakeup Granularity, Task Migration Cost, Migration Queue Limit (`nr_migrate`), dan tombol Child Process Runs First.

### 3. 🌐 Sinkronisasi Penuh WebUI KernelSU / APatch (`webroot/`)
- **Tuner Virtual Memory (VM) Terpadu**: Diperluas dengan 3 tombol preset cepat (`⚡ Gaming`, `⚖️ Balanced`, `🔋 Battery`) dan 7 slider sysfs lengkap (`dirty_ratio`, `dirty_background_ratio`, `vfs_cache_pressure`, `swappiness`, `dirty_expire_centisecs`, `dirty_writeback_centisecs`, `stat_interval`).
- **Dynamic TCP Congestion Picker**: Membaca algoritma TCP aktif dan tersedia langsung dari kernel (`/proc/sys/net/ipv4/tcp_available_congestion_control`) dan me-render tombol dinamis.
- **Wake Guard & Aggressive Doze**: Menampilkan status nyata driver Boeffla Wakelock Blocker serta switch Aggressive Doze (`dumpsys deviceidle force-idle`) untuk memangkas konsumsi baterai standby.

### 4. 📖 Panduan Penyediaan Driver Hardware Kustom
- Penambahan dokumen teknis resmi [`docs/14_CUSTOM_KERNEL_DRIVER_DEVELOPMENT_GUIDE.md`](./docs/14_CUSTOM_KERNEL_DRIVER_DEVELOPMENT_GUIDE.md) yang menjelaskan arsitektur kernel Ring 0 vs Ring 3, penyediaan patch driver Sound Control ALSA codec, driver VDD voltage table untuk undervolt/overvolt, penambahan frekuensi overclocking pada DTS OPP table MediaTek/Qualcomm, serta alur kompilasi dan pengemasan AnyKernel3 1-klik.

---

# Lynx [Codename: Deity] 3.0.1
Released on: 2026-09-26
> **Versi ini** membawa ekspansi masif Deep Hardware Scanner dengan lebih dari 450 node tuneable hardware terdeteksi secara dinamis.

## ✨ Fitur Baru & Peningkatan (3.0.1)

### 1. Deep Hardware Scanner Diperluas (450+ Hardware Nodes)
- **Tambahan subsistem yang sebelumnya tidak terpindai:**
  - **MediaTek FPSGO/FBT/FSTB**: Engine frame-pacing utama MediaTek (`/sys/kernel/fpsgo/common/*`, `/fbt/*`, `/fstb/*`) kini tampil sebagai kontrol toggle tertunable.
  - **GED HAL Layer**: Kontrol langsung GPU driver level (`/sys/kernel/ged/hal/*`) untuk custom boost freq, DVFS margin, loading step.
  - **Core Control (Qualcomm)**: Manajemen hotplug core CPU performa Qualcomm (`cpu*/core_ctl/*`).
  - **EAS & HPS**: Energy Aware Scheduling enable node dan MediaTek CPU Hotplug System.
  - **PPM Master Switch & Mode**: Kontrol on/off seluruh engine PPM MediaTek (`/proc/ppm/enabled`, `/proc/ppm/mode`).
  - **Charging Lanjutan**: Tambahan node `fast_charge`, `fastcharge_mode`, `thermal_limit`, `system_temp_level`, `wireless_boost` untuk Samsung/Xiaomi/POCO.
  - **LMK & Process Reclaim**: `/sys/module/lowmemorykiller/parameters/*` dan `/sys/module/process_reclaim/parameters/*` untuk manajemen memori lebih halus.
  - **Sound Control**: `/sys/kernel/sound_control/*` dan `/sys/class/misc/soundcontrol/*` untuk kernel audio tuning.
  - **Vibrator Amplitude**: `/sys/devices/virtual/timed_output/vibrator/amp` untuk kontrol kekuatan getaran.
  - **LRU Gen**: Seluruh node Multi-Gen LRU (`/sys/kernel/mm/lru_gen/*`) bukan hanya enabled.
  - **Adreno Extended**: `force_no_nap`, `gpuclk`, `min/max_clock_mhz`, `pwrscale`, dan `max_gpuclk`.
  - **Kernel Misc**: `pid_max`, `timer_migration`, `randomize_va_space`, `perf_cpu_time_max_percent`.
- **Smart Value Normalization**: Status string `ppm is enabled/disabled`, `fbt_idleprefer_enable:1` kini otomatis dinormalisasi ke nilai boolean 0/1.
- **Smart Skipping**: Node non-tuneable (info dumps, statistik, BQ ID, tabel) kini difilter otomatis sehingga tidak muncul sebagai toggle palsu.
- **Performa Scan**: 453 node terdeteksi dalam 80ms (dari sebelumnya 440 node dalam 130ms).
- **Metadata Baru**: 20+ entri metadata friendly ditambahkan untuk GED HAL, FPSGO, Core Control, PPM, HPS, EAS, ASLR.

### 2. Sinkronisasi Shell Script & Kotlin
- `core/lib/deep_inspector.sh` dan `buildStandaloneDeepScanScript()` di `LynxRepository.kt` kini **100% sinkron** — jalur hardware, filter, normalisasi nilai, dan kategorisasi identik persis antara shell module dan aplikasi native.

---

# Lynx [Codename: Deity] 3.0.0
Released on: 2026-09-25
> **Nama Aplikasi**: Lynx | **Codename**: Deity | **Versi**: 3.0.0  
> Rilis ini menghadirkan perombakan total (*major architectural overhaul*), penyatuan arsitektur hibrida Qualcomm & MediaTek, pembersihan redundansi kode warisan, standarisasi murni POSIX, integrasi biner BusyBox selektif (Feravolt & Brutal), antarmuka WebUI modern, serta Aplikasi Native Android Companion (Kotlin + Jetpack Compose) dengan sinkronisasi 2 arah real-time.

---

## ✨ Fitur Baru & Peningkatan (3.0.0)

### 1. Spektrum 5 Mode & AI Adaptif (Smart-AI Core v5.5)
- **5 Profil Performa Utama**:
  - `auto`: Deteksi game adaptif secara otomatis (*Zero Latency 0ms entry, 3s cooldown buffer, deep sleep suspend blocker*).
  - `balance`: Profil harian hemat daya berbasis EAS, frekuensi seimbang, dan *power-efficient workqueues*.
  - `performance`: Kunci frekuensi menengah-atas, elevasi prioritas *SurfaceFlinger/HW Composer*, dan pembatasan throttling moderat.
  - `extreme`: Frekuensi CPU & GPU maksimum, *unrestricted full thermal bypass* (trip points 150°C), dan pengisian daya bebas batas (khusus dengan *phone cooler* eksternal).
  - `powersave`: Penghemat baterai ekstrem dengan batas frekuensi efisien dan penonaktifan boost agresif.
- **Safe First-Boot (Dormant Mode)**: Modul menginisialisasi dalam status standby aman tanpa modifikasi jam ekstrem sebelum dikonfigurasi melalui WebUI atau Aplikasi Companion.

### 2. Segmentasi HAL Perangkat Keras (Qualcomm vs MediaTek)
- **Pemisahan Sysfs Eksklusif**:
  - `platforms/qcom/sysfs.sh`: Penekanan overhead diagnostik Adreno KGSL, peredam jitter CPU-Boost input frequency, aktivasi Qualcomm WALT (*Window Assisted Load Tracking*), dan DRM perf mode.
  - `platforms/mtk/sysfs.sh`: Penonaktifan logging modem CCCI, penekanan tracing GED KPI, pembatalan pembatasan FPS MediaTek Syslimiter (60/90/120/144), dan pengoptimalan Perf PMU.
  - `platforms/generic/sysfs.sh`: Penanganan fallback aman untuk chipset arsitektur generik.
- **Anti-Spoofing Detection Engine & Hardware Fingerprinting (`hw_probe.sh`)**:
  - Verifikasi bertingkat melalui driver kernel fisik dan Device Tree Blob (`/sys/firmware/devicetree/base/model`, `/proc/device-tree/compatible`, `/dev/kgsl-3d0`, `/dev/mali0`, `/proc/ppm`) yang kebal 100% terhadap manipulasi spoofing *Device Faker*, *GLTools*, maupun *Game Unlocker*.
  - Mengabaikan manipulasi `getprop` di user-space dan secara otomatis mengunci eksekusi ke arsitektur hardware kernel yang sesungguhnya.
  - **Dynamic Targeted Sub-Profiles**:
    - **MediaTek**: ARM Mali-G57 (`gpu_mali_g57.sh`), Mali Valhall Gen-2 G68/G77/G78 (`gpu_mali_valhall2.sh`), ARM Immortalis flagship (`gpu_immortalis.sh`), dan tuning khusus perangkat Infinix X698 / MT6781 (`infinix_x698.sh`).
    - **Qualcomm**: Adreno 600 series (`gpu_adreno_600.sh`), Adreno 700 GMU tuning (`gpu_adreno_700.sh`), dan adaptasi Xiaomi/Poco/Redmi (`xiaomi_qcom.sh`).

### 3. Modularisasi Subsistem Universal (POSIX Standard)
- **`core/lib/sched_features.sh`**:
  - Penyesuaian flags scheduler kernel berlatensi rendah (`NO_GENTLE_FAIR_SLEEPERS`, `START_DEBIT`, `LB_BIAS`, dll.).
  - Injeksi otomatis 23 pustaka mesin game utama (*Unity, Unreal Engine, Genshin Impact, Asphalt, Flutter*) ke `/proc/sys/kernel/sched_lib_name`.
- **`core/lib/network.sh`**:
  - Penemuan otomatis algoritma TCP Congestion Control terbaik (`bbrv3` ➔ `bbr` ➔ `westwood` ➔ `cubic`).
  - Implementasi *Fair Queueing Controlled Delay* (`fq_codel`) untuk eliminasi *bufferbloat*.
  - Pemblokiran *Wi-Fi Power Save* saat bermain game untuk mencegah lonjakan latensi (ping spikes).
- **`core/lib/state.sh` & `config.json`**:
  - Manajemen state terpadu berbasis JSON dengan dukungan notasi titik (*dot-notation*, e.g. `uclamp.game_min_ratio`).
  - Pembaruan atomik bebas race condition yang menjaga konsistensi state di seluruh antarmuka.

### 4. Tombol Aksi KernelSU & APatch Aman (`action.sh`)
- Menghapus total perintah penghapusan `dalvik-cache` usang yang berisiko memicu *soft reboot*.
- Menggantikan dengan pemeliharaan aman via `CCleaner.sh`: pemadatan memori RAM fisik kontigu (*memory compaction*), pembersihan crash dump/tombstones/ANR, dan pemangkasan blok penyimpanan (*fstrim*).

### 5. Aplikasi Native Android Companion (`LynxCompanion`)
- Dibangun menggunakan **Kotlin + Jetpack Compose + Material 3** dengan estetika *Cyberpunk Deep Dark OLED*.
- Eksekusi root berlatensi rendah via `libsu`.
- Sinkronisasi dua arah (*Two-Way Sync*) secara instan dengan `config.json` modul via `FileObserver` dan `inotify`.

---

# Arsip Rilis Sebelumnya (v3.0 Beta)
Released on: 2025-05-11
> Rilis awal pengenalan mesin logika Lxcore dan dukungan Android 14/15 Beta.
