#!/system/bin/sh
# Small POSIX-shell locale helper for installer and interactive module scripts.

lynx_locale() {
    local tag
    tag="$(getprop persist.sys.locale 2>/dev/null)"
    [ -z "$tag" ] && tag="$(getprop ro.product.locale 2>/dev/null)"
    [ -z "$tag" ] && tag="${LANG:-id}"
    case "$(printf '%s' "$tag" | tr '[:upper:]' '[:lower:]')" in
        en|en_*|en-*) printf 'en' ;;
        *) printf 'id' ;;
    esac
}

lynx_t() {
    local key locale
    key="$1"
    locale="$(lynx_locale)"
    if [ "$locale" = "en" ]; then
        case "$key" in
            install_title) printf '  [*] L Y N X   [Codename: Deity]' ;;
            spoof_warning) printf '  [!] WARNING: SoC spoofer detected! (%s / %s)' "$2" "$3" ;;
            real_mtk) printf '  [*] Verified hardware: MediaTek Dimensity/Helio' ;;
            real_qcom) printf '  [*] Verified hardware: Qualcomm Snapdragon' ;;
            lock_mtk) printf '  [+] Lynx will use the MediaTek engine for safety.' ;;
            lock_qcom) printf '  [+] Lynx will use the Qualcomm engine for safety.' ;;
            architecture) printf '  [*] Detected architecture: %s' "$2" ;;
            confirm_chipset) printf '  [?] Is the detected chipset correct?' ;;
            volume_yes) printf '     [Vol +]  YES, continue with %s' "$2" ;;
            volume_no) printf '     [Vol -]  NO, choose manually' ;;
            select_architecture) printf '  [*] Select SoC architecture manually:' ;;
            qcom_option) printf '     [1] Qualcomm Snapdragon' ;;
            mtk_option) printf '     [2] MediaTek Dimensity / Helio' ;;
            generic_option) printf '     [3] Generic Linux' ;;
            inject_hal) printf '  [*] Injecting hardware abstraction layer (%s)…' "$2" ;;
            installed) printf '  [OK] Lynx Universal %s installed successfully!' "$2" ;;
            open_app) printf '  [*] Open Lynx Companion or the WebUI to select a profile.' ;;
            *) printf '%s' "$key" ;;
        esac
    else
        case "$key" in
            install_title) printf '  [*] L Y N X   [Codename: Deity]' ;;
            spoof_warning) printf '  [!] PERINGATAN: SoC Spoofer terdeteksi! (%s / %s)' "$2" "$3" ;;
            real_mtk) printf '  [*] Hardware terverifikasi: MediaTek Dimensity/Helio' ;;
            real_qcom) printf '  [*] Hardware terverifikasi: Qualcomm Snapdragon' ;;
            lock_mtk) printf '  [+] Lynx mengunci engine ke MediaTek demi keamanan.' ;;
            lock_qcom) printf '  [+] Lynx mengunci engine ke Qualcomm demi keamanan.' ;;
            architecture) printf '  [*] Arsitektur terdeteksi: %s' "$2" ;;
            confirm_chipset) printf '  [?] Apakah chipset yang terdeteksi benar?' ;;
            volume_yes) printf '     [Vol +]  YA, lanjutkan dengan %s' "$2" ;;
            volume_no) printf '     [Vol -]  TIDAK, pilih secara manual' ;;
            select_architecture) printf '  [*] Pilih arsitektur SoC secara manual:' ;;
            qcom_option) printf '     [1] Qualcomm Snapdragon' ;;
            mtk_option) printf '     [2] MediaTek Dimensity / Helio' ;;
            generic_option) printf '     [3] Generic Linux' ;;
            inject_hal) printf '  [*] Memasang Hardware Abstraction Layer (%s)…' "$2" ;;
            installed) printf '  [OK] Lynx Universal %s berhasil dipasang!' "$2" ;;
            open_app) printf '  [*] Buka Lynx Companion atau WebUI untuk memilih profil.' ;;
            *) printf '%s' "$key" ;;
        esac
    fi
}
