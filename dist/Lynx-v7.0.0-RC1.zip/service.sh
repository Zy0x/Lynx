#!/system/bin/sh
# ==============================================================================
# Lynx Universal - Late Start Service Router
# Hybrid Architecture: Qualcomm Snapdragon, MediaTek, & Generic Linux
# Clean, high-performance, hardened system boot manager with First-Boot Dormant Safety
# ==============================================================================

MODPATH=${0%/*}
[ -d "$MODPATH" ] || MODPATH="/data/adb/modules/Lynx"

# ── 0. Critical Safe Mode & Bootloop Protection Guard ───────────────
if [ -f "/data/adb/modules/.disable_magisk" ] || [ -f "/data/adb/apatch/.disable" ] || [ -f "$MODPATH/disable" ] || [ -f "/sdcard/Debug/SAFE_MODE" ]; then
    exit 0
fi

# Clean up any legacy or rogue service.d scripts that could cause bootloops
rm -f /data/adb/service.d/lynx* 2>/dev/null

# ── 1. Wait for boot completion (max 120s timeout) ──────────────────
boot_count=0
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do
    sleep 2
    boot_count=$((boot_count + 1))
    [ $boot_count -ge 60 ] && break
done

# ── 2. Wait for decrypted user storage (max 50s timeout for lockscreen FBE) ─
fbe_count=0
while [ ! -d "/sdcard/Android" ]; do
    sleep 2
    fbe_count=$((fbe_count + 1))
    [ $fbe_count -ge 25 ] && break
done

# Second safe mode check after storage decrypted
[ -f "/sdcard/Debug/SAFE_MODE" ] && exit 0

MODPROP="$MODPATH/module.prop"
CORE="$MODPATH/core"
LIB="$MODPATH/core/lib"
CONFIG_JSON="$MODPATH/config.json"
TARGET_SOC_FILE="$MODPATH/target_soc"

# Ensure log and storage directories exist
mkdir -p "/storage/emulated/0/Lynx" "$MODPATH/logs" "$MODPATH/logs/archive" 2>/dev/null
LOG_FILE="/storage/emulated/0/Lynx/Lynx.log"

# Log rotation if file exceeds max size (default 1 MB / 1048576 bytes)
rotate_log() {
    local target="$1"
    local max_size="${2:-1048576}"
    if [ -f "$target" ]; then
        local size
        size=$(wc -c < "$target" 2>/dev/null || echo 0)
        if [ "$size" -gt "$max_size" ] 2>/dev/null; then
            mkdir -p "$MODPATH/logs/archive" 2>/dev/null
            mv -f "$target" "$MODPATH/logs/archive/$(basename "$target").old" 2>/dev/null
        fi
    fi
}

# Boot Timeout Guard: executes command with a strict time limit to prevent boot hangs
run_with_timeout() {
    local max_time="$1"
    shift
    if command -v timeout >/dev/null 2>&1; then
        timeout "$max_time" "$@"
    else
        "$@" &
        local pid=$!
        local count=0
        while kill -0 "$pid" 2>/dev/null; do
            sleep 1
            count=$((count + 1))
            if [ "$count" -ge "$max_time" ]; then
                kill -9 "$pid" 2>/dev/null
                return 124
            fi
        done
        wait "$pid" 2>/dev/null
        return $?
    fi
}

rotate_log "$LOG_FILE" 524288

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE" 2>/dev/null
}

# ── 3. Target Architecture & Environment ────────────────────────────
TARGET_SOC="generic"
if [ -f "$TARGET_SOC_FILE" ]; then
    TARGET_SOC=$(cat "$TARGET_SOC_FILE" 2>/dev/null | tr -d '[:space:]')
fi
if [ -z "$TARGET_SOC" ] || [ "$TARGET_SOC" = "generic" ]; then
    if [ -f "$CONFIG_JSON" ]; then
        TARGET_SOC=$(awk -F'"' '/"soc_type"[ \t]*:/ {print $4}' "$CONFIG_JSON" 2>/dev/null)
    fi
fi
# Kernel ground-truth fallback (Immune to prop spoofing)
if [ -z "$TARGET_SOC" ] || [ "$TARGET_SOC" = "generic" ]; then
    if [ -f "$LIB/hw_probe.sh" ]; then
        . "$LIB/hw_probe.sh"
        detected_soc=$(detect_real_soc)
        [ "$detected_soc" != "generic" ] && TARGET_SOC="$detected_soc"
    fi
fi
[ -z "$TARGET_SOC" ] && TARGET_SOC="generic"

log_msg "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log_msg "Lynx Universal Service Initializing..."
log_msg "• Platform: $TARGET_SOC"
log_msg "• Device: $(getprop ro.product.brand) $(getprop ro.product.model)"
log_msg "• Kernel: $(uname -r)"

# ── 3a. Native Core Engine Verification (Phase 5A, 5C, & 5D Reliability Gate) ──
LYNXD_BIN="$MODPATH/system/bin/lynxd"
USE_NATIVE=0

# Read engine configuration
NATIVE_CONFIG_ENABLED=1
FAIL_THRESHOLD=3
CUR_FAILURES=0

if [ -f "$CONFIG_JSON" ]; then
    if grep -q '"native_enabled"[[:space:]]*:[[:space:]]*false' "$CONFIG_JSON" 2>/dev/null; then
        NATIVE_CONFIG_ENABLED=0
        log_msg "[*] Native Core Engine disabled via config.json (native_enabled: false). Operating in Pure Legacy Mode."
    fi
    cf=$(grep -o '"consecutive_failures"[[:space:]]*:[[:space:]]*[0-9]*' "$CONFIG_JSON" 2>/dev/null | awk -F: '{print $2}' | tr -d '[:space:]')
    [ -n "$cf" ] && CUR_FAILURES=$cf
    ft=$(grep -o '"failure_threshold"[[:space:]]*:[[:space:]]*[0-9]*' "$CONFIG_JSON" 2>/dev/null | awk -F: '{print $2}' | tr -d '[:space:]')
    [ -n "$ft" ] && FAIL_THRESHOLD=$ft
fi

record_failure() {
    local reason="$1"
    CUR_FAILURES=$((CUR_FAILURES + 1))
    log_msg "[!] Native Core Engine failure detected: $reason (Failure $CUR_FAILURES of $FAIL_THRESHOLD)"
    if [ "$CUR_FAILURES" -ge "$FAIL_THRESHOLD" ]; then
        log_msg "[CRITICAL] Native Core Engine reached failure threshold ($CUR_FAILURES >= $FAIL_THRESHOLD)!"
        log_msg "[CRITICAL] Automatically switching module to Pure Legacy Mode (native_enabled: false) for device safety."
        if [ -f "$CONFIG_JSON" ]; then
            sed -i 's/"native_enabled"[[:space:]]*:[[:space:]]*true/"native_enabled": false/' "$CONFIG_JSON" 2>/dev/null
        fi
        CUR_FAILURES=0
    fi
    if [ -f "$CONFIG_JSON" ]; then
        sed -Ei "s/\"consecutive_failures\"[[:space:]]*:[[:space:]]*[0-9]+/\"consecutive_failures\": $CUR_FAILURES/" "$CONFIG_JSON" 2>/dev/null
        safe_reason=$(echo "$reason" | sed 's/[/"&]/\\&/g')
        sed -Ei "s/\"last_failure_reason\"[[:space:]]*:[[:space:]]*\"[^\"]*\"/\"last_failure_reason\": \"$safe_reason\"/" "$CONFIG_JSON" 2>/dev/null
        now_ts=$(date +%s 2>/dev/null || echo 0)
        new_entry="{\"time\": $now_ts, \"reason\": \"$safe_reason\"}"
        if grep -q '"failure_history"[[:space:]]*:[[:space:]]*\[[[:space:]]*\]' "$CONFIG_JSON" 2>/dev/null; then
            sed -i "s/\"failure_history\"[[:space:]]*:[[:space:]]*\[[[:space:]]*\]/\"failure_history\": [ $new_entry ]/" "$CONFIG_JSON" 2>/dev/null
        elif grep -q '"failure_history"[[:space:]]*:[[:space:]]*\[' "$CONFIG_JSON" 2>/dev/null; then
            # Ring buffer cap: prune oldest entry if count >= 10
            num_entries=$(grep -o '{"time"' "$CONFIG_JSON" 2>/dev/null | wc -l)
            if [ "$num_entries" -ge 10 ] 2>/dev/null; then
                sed -Ei 's/("failure_history"[[:space:]]*:[[:space:]]*\[)[[:space:]]*\{[^}]*\}[[:space:]]*,[[:space:]]*/\1/' "$CONFIG_JSON" 2>/dev/null
            fi
            sed -Ei "s/\"failure_history\"[[:space:]]*:[[:space:]]*\[(.*)\]/\"failure_history\": [\1, $new_entry]/" "$CONFIG_JSON" 2>/dev/null
        fi
    fi
}

record_success() {
    if [ "$CUR_FAILURES" -gt 0 ] && [ -f "$CONFIG_JSON" ]; then
        sed -Ei 's/"consecutive_failures"[[:space:]]*:[[:space:]]*[0-9]+/"consecutive_failures": 0/' "$CONFIG_JSON" 2>/dev/null
    fi
}

if [ "$NATIVE_CONFIG_ENABLED" = "1" ] && [ -x "$LYNXD_BIN" ]; then
    if run_with_timeout 3 "$LYNXD_BIN" help >/dev/null 2>&1; then
        USE_NATIVE=1
        log_msg "[+] Native Core Engine verified ($LYNXD_BIN)"
    else
        record_failure "sanity_check_timeout_or_crash"
        log_msg "[!] Native Core Engine failed sanity execution check. Falling back to legacy shell."
    fi
elif [ "$NATIVE_CONFIG_ENABLED" = "1" ]; then
    record_failure "binary_missing_or_not_executable"
    log_msg "[*] Native Core Engine not found at $LYNXD_BIN. Using legacy shell fallback."
fi

# ── 3b. Boot Recovery Guard (Dirty State & Crash Resilience) ─────────
if [ "$USE_NATIVE" = "1" ]; then
    rotate_log "$MODPATH/logs/transaction.log" 1048576
    log_msg "[*] Executing lynxd boot recovery (5s timeout guard)..."
    if run_with_timeout 5 "$LYNXD_BIN" profile recover >> "$LOG_FILE" 2>&1; then
        log_msg "[+] lynxd boot recovery verified system state."
        record_success
    else
        record_failure "boot_recovery_timeout_or_error"
        log_msg "[!] lynxd boot recovery timed out or failed. Continuing boot."
    fi
fi

# ── 4. WebUI & Sync Watcher (Always active so UI can control module) ─
if [ -d "$MODPATH/webroot" ]; then
    pkill -f "httpd.*127.0.0.1:8080" 2>/dev/null
    if command -v busybox >/dev/null; then
        busybox httpd -p 127.0.0.1:8080 -h "$MODPATH/webroot" 2>/dev/null
    elif command -v toybox >/dev/null; then
        toybox httpd -p 127.0.0.1:8080 -h "$MODPATH/webroot" 2>/dev/null
    fi
    log_msg "[*] WebUI HTTP Server active on 127.0.0.1:8080"
fi

if command -v inotifyd >/dev/null && [ -f "$CONFIG_JSON" ] && [ -f "$LIB/state_watcher.sh" ]; then
    pkill -f "inotifyd.*state_watcher.sh" 2>/dev/null
    nohup inotifyd "$LIB/state_watcher.sh" "$CONFIG_JSON:w" >/dev/null 2>&1 &
    log_msg "[*] Inotifyd state watcher active"
fi

# ── 5. Profile Enforcement & First-Boot Dormant Safety Guard ────────
active_profile="dormant"
if [ -f "$CONFIG_JSON" ]; then
    active_profile=$(awk -F'"' '/"active_profile"[ \t]*:/ {print $4}' "$CONFIG_JSON" 2>/dev/null)
fi
[ -z "$active_profile" ] && active_profile="dormant"

log_msg "Active profile: $active_profile"

# FIRST-BOOT DORMANT SAFETY: If dormant, EXIT NOW without modifying any kernel hardware!
if [ "$active_profile" = "dormant" ]; then
    sed -Ei "s/^description=\[.*\]/description=[ Dormant (Pending Setup) ]/" "$MODPROP" 2>/dev/null
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Lynx - Deity' 'Lynx' 'Modul terpasang aman (Standby). Buka WebUI atau Aplikasi Lynx untuk konfigurasi awal.'" >/dev/null 2>&1
    log_msg "Lynx initialized safely in dormant standby mode. No hardware sysfs applied."
    exit 0
fi

# ── 6. Platform-Specific Hardware Initialization (Only when active) ─
if [ -f "$MODPATH/platforms/$TARGET_SOC/sysfs.sh" ]; then
    sh "$MODPATH/platforms/$TARGET_SOC/sysfs.sh" >/dev/null 2>&1
    log_msg "[*] Platform HAL ($TARGET_SOC) sysfs initialized"
fi

# ── 7. Universal Subsystem Optimization (Lxcore Modular Categories) ──
if [ -x "$MODPATH/system/bin/Lxcore" ]; then
    "$MODPATH/system/bin/Lxcore" -system apply >/dev/null 2>&1
    "$MODPATH/system/bin/Lxcore" -cpu apply >/dev/null 2>&1
    "$MODPATH/system/bin/Lxcore" -gpu apply >/dev/null 2>&1
    "$MODPATH/system/bin/Lxcore" -task apply >/dev/null 2>&1
    "$MODPATH/system/bin/Lxcore" -io apply >/dev/null 2>&1
    "$MODPATH/system/bin/Lxcore" -ram apply >/dev/null 2>&1
    "$MODPATH/system/bin/Lxcore" -network apply >/dev/null 2>&1
    log_msg "[+] Core modular subsystems optimized via Lxcore"
fi

# Touch & Compositor Phase Latency Offsets
settings put secure long_press_timeout 280 2>/dev/null
settings put secure multi_press_timeout 80 2>/dev/null

# ── 8. Start Background Services ────────────────────────────────────
if command -v crond >/dev/null && [ -d "$CORE/cron" ]; then
    crond -f -c "$CORE/cron" -l 5 -L "$MODPATH/logs/cron.log" &
fi

if [ -f "$CORE/Charging-Controller.sh" ]; then
    nohup sh "$CORE/Charging-Controller.sh" >/dev/null 2>&1 &
fi

[ -f "$CORE/CCleaner.sh" ] && sh "$CORE/CCleaner.sh" >/dev/null 2>&1

if [ -f "$LIB/lowend_shield.sh" ]; then
    . "$LIB/lowend_shield.sh"
    apply_lowend_shield
fi

# ── 9. Profile Action Execution ─────────────────────────────────────
case "$active_profile" in
    auto)
        sed -Ei "s/^description=\[.*\]/description=[ Auto (AI) Mode Active ]/" "$MODPROP" 2>/dev/null
        if [ "$USE_NATIVE" = "1" ]; then
            rotate_log "$MODPATH/logs/lynxd.log" 1048576
            pkill -f "lynxd daemon run" 2>/dev/null
            nohup "$LYNXD_BIN" daemon run >> "$MODPATH/logs/lynxd.log" 2>&1 &
            log_msg "[+] Native lynxd daemon launched with Autonomous Engine & Hysteresis"
        else
            nohup sh "$CORE/Smart-AI.sh" >/dev/null 2>&1 &
            log_msg "[*] Fallback: Smart-AI.sh daemon started"
        fi
        ;;
    powersave|balance|balanced|performance|extreme)
        case "$active_profile" in
            powersave) sed -Ei "s/^description=\[.*\]/description=[ Powersave Mode Active ]/" "$MODPROP" 2>/dev/null ;;
            balance|balanced) active_profile="balance"; sed -Ei "s/^description=\[.*\]/description=[ Balance Mode Active ]/" "$MODPROP" 2>/dev/null ;;
            performance) sed -Ei "s/^description=\[.*\]/description=[ Performance Mode Active ]/" "$MODPROP" 2>/dev/null ;;
            extreme) sed -Ei "s/^description=\[.*\]/description=[ Extreme Mode Active ]/" "$MODPROP" 2>/dev/null ;;
        esac
        applied_native=0
        if [ "$USE_NATIVE" = "1" ]; then
            if run_with_timeout 5 "$LYNXD_BIN" profile apply "$active_profile" >> "$LOG_FILE" 2>&1; then
                applied_native=1
                log_msg "[+] Applied profile '$active_profile' via lynxd transactional pipeline"
            else
                record_failure "profile_apply_timeout_5s"
                log_msg "[!] lynxd profile apply timed out. Invoking legacy shell fallback."
            fi
        fi
        if [ "$applied_native" = "0" ]; then
            if [ -f "$CORE/apply_profile.sh" ]; then
                sh "$CORE/apply_profile.sh" "$active_profile" >/dev/null 2>&1
            elif [ "$active_profile" = "extreme" ] && [ -f "$MODPATH/platforms/$TARGET_SOC/perf.sh" ]; then
                sh "$MODPATH/platforms/$TARGET_SOC/perf.sh" "extreme" >/dev/null 2>&1
            elif [ -f "$MODPATH/platforms/$TARGET_SOC/$active_profile.sh" ]; then
                sh "$MODPATH/platforms/$TARGET_SOC/$active_profile.sh" >/dev/null 2>&1
            elif [ "$active_profile" = "performance" ] && [ -f "$MODPATH/platforms/$TARGET_SOC/perf.sh" ]; then
                sh "$MODPATH/platforms/$TARGET_SOC/perf.sh" >/dev/null 2>&1
            fi
            log_msg "[*] Applied profile '$active_profile' via legacy shell fallback path"
        fi
        ;;
esac

[ -f "$LIB/updater.sh" ] && nohup sh "$LIB/updater.sh" >/dev/null 2>&1 &

# ── 9b. Lynx Thermal Framework Boot Mode Application ───────────────
THERMAL_BOOT_CFG="$MODPATH/thermal_boot_mode.json"
if [ -f "$THERMAL_BOOT_CFG" ]; then
    thermal_mode=$(awk -F'"' '/"mode"[ \t]*:/ {print $4}' "$THERMAL_BOOT_CFG" 2>/dev/null)
    if [ -n "$thermal_mode" ] && [ "$thermal_mode" != "default_oem" ]; then
        if [ -f "$MODPATH/platforms/$TARGET_SOC/thermal.sh" ]; then
            log_msg "[*] Applying boot thermal mode: $thermal_mode ($TARGET_SOC)"
            sh "$MODPATH/platforms/$TARGET_SOC/thermal.sh" "$thermal_mode" >/dev/null 2>&1
        fi
    fi
fi

# ── 10. Execute Custom User Rules & Deep Tunables ───────────────────
if [ -f "$CORE/custom_tunables.sh" ]; then
    log_msg "[*] Applying custom deep kernel tunables ($CORE/custom_tunables.sh)..."
    sh "$CORE/custom_tunables.sh" >> "$MODPATH/logs/custom_tunables.log" 2>&1
fi
if [ -f "$MODPATH/custom_rules.sh" ]; then
    log_msg "[*] Executing custom user boot rules ($MODPATH/custom_rules.sh)..."
    sh "$MODPATH/custom_rules.sh" >> "$MODPATH/logs/custom_rules.log" 2>&1
    log_msg "Custom rules execution finished."
fi

su -lp 2000 -c "cmd notification post -S bigtext -t 'Lynx - Deity' 'Lynx' '$active_profile Mode Applied...'" >/dev/null 2>&1
log_msg "Lynx service completed successfully."